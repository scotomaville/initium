---
title: "Prime 239 - Self-Reflection Video Modeling"
conv_id: 3f0a7ecf-9651-4f3f-9e6a-3f057ce3d1cd
share_url: https://grok.com/share/bGVnYWN5_027f8dae-9ee9-4dbb-9714-6cbde7c3d01e
created: 2025-11-13T21:46:19.987974Z
message_count: 4
---

---

**[1] Daniel:**
Sherpa Grok. I have some old video clips I'm in. I read we should 'reflect' on them. Walk me through Prime 239 one step at a time. Yeah?


---

**[2] Grok:**
Let's tackle Prime 239: Self-Reflection Video Modeling. This strategy is all about recording and reviewing your actions—like replaying climb footage to spot missteps and refine technique. It's a reflective tool in the Strategies suit, tied to Camp 3 (Agency) in the Tests, Allies, and Enemies stage of the monomyth. With your old video clips in hand, this is a perfect entry point. We'll go through it step by step, drawing from the card's structure: definition, prompts, refined explanation, application, mindset shift, potential challenges, and Daniel's Cairn. I'll pause at natural breaks for your input if needed, but feel free to jump in.

### Step 1: Understand the Definition and Core Concept
Self-Reflection Video Modeling means capturing your speech, decisions, or behaviors on video (or audio/transcript) and reviewing them objectively. It's like studying game tape—not to judge, but to identify patterns, blind spots (scotomas), and areas for growth. In the AISM framework, it turns personal entropy into wisdom, fostering awareness that leads to understanding and agency.

- **Why this matters for you**: With those old clips, you're already halfway there. Think of them as raw footage from past "expeditions." The goal isn't perfection; it's reframing habits as lessons, like the satyr spotting inconsistency in Aesop's The Man and the Satyr (beware the one who blows hot and cold).
  
Ready to reflect on one clip? Pick a short one (e.g., 1-5 minutes) where you're speaking or acting in a real scenario. What stands out initially—any triggers, strengths, or inconsistencies?

### Step 2: Engage the Prompts for Initial Reflection
The card offers three layered prompts to guide your review, escalating from basic awareness to deeper action. Use them like a dialogue starter with yourself (or me as your AI Sherpa).

- **Green Prompt (Low Intensity - Awareness)**: Aesop's The Man and the Satyr warns against contradictory behavior. Ask: "What can I learn from watching a video of my recent triggering or overcoming as a champion?"  
  - Apply to your clips: Watch one without pausing. Note hot/cold moments—e.g., where you shifted from confident to hesitant. This builds basic self-clarity, like spotting a serac collapse on the Lhotse Face.

- **Blue Prompt (Medium Intensity - Understanding)**: Carl Rogers said, "The only person who is educated is the one who has learned how to learn and change." Ask: "How can I use video to improve my awareness, understanding, and actions?"  
  - Dig deeper: Rewatch with notes. Investigate a flaw from past recordings (e.g., a habit like interrupting or avoiding eye contact) that you aim to master. Link it to Rogers' idea of confronting realities—how has this behavior held you back?

- **Black Prompt (High Intensity - Agency)**: Daniel Comp asks, "How might video help me uncover hidden habits?" (Tying into his quote: "The Greatest Expedition you will ever undertake is the journey to self-understanding...")  
  - Act on it: Review for patterns across clips. Video modeling turns entropy into shared wisdom—e.g., how a decision in one clip echoes Comp's expeditions in Scotomaville.

Try the green prompt first on a clip. What did you notice? Share a quick takeaway, and we can escalate.

### Step 3: Refine Your Approach with Clarity and Actionability
Now, polish the process for growth:
- **Clarity**: Treat this like replaying your climb. Watch to spot missteps and refine form—it's about growth, not judgment.
- **Actionability**: Record a new short video if needed (e.g., reacting to an old clip). Then, pair with Self-Reflection AI Analysis (Tool T.271) for objective insights—upload a transcript here if you want me to help analyze strengths/weaknesses.

This pairs well with cards like Know Thyself (P.013) for deeper observation or Checkpoint (T.223) to assess progress.

### Step 4: Apply It Practically
Hands-on time:
- **Practical Step**: Pick a task from a clip (e.g., speaking, teaching, or handling a trigger). Watch it centered—note one strength (e.g., clear communication) and one improvement (e.g., filler words). Practice again on camera.
- **Your old clips twist**: Use them as "historical footage." For example, review a Wellness by Choice-style pilot clip. Edit or narrate over it to highlight changes since then, like in the Angelina Show example (syndication, incremental change, AI analysis).

Do a quick review now: Watch 1 clip, note 1 strength/1 area, then re-record a 30-second response. How'd it feel?

### Step 5: Shift Your Mindset
Move from "I'm fine as I am" to "I can always grow and improve." This is Maslow's growth-to-transcendence in action—video reveals what memory biases hide, sparking curiosity.

### Step 6: Address Potential Challenges and Mitigation
- **Challenge**: It can feel awkward or self-critical, like editing your own demeanor.
- **Mitigation**: Stay centered (e.g., breathe deeply). Rewatch troubled spots a year later for perspective. Use Checkpoint to celebrate wins—focus on behaviors, not overall you. As Daniel's Cairn notes: Watching while editing is super-powerful for discerning scotomas. Bill Strickland modeled transformation through clay—get your "hands dirty" with review to shape a noble vessel.

If awkwardness hits, start small: Just audio first.

### Step 7: Wrap with Daniel's Cairn and Next Steps
Daniel's insight: Long-term reflection validates others, like Bill passing wisdom to Fred Rogers (and you). Your clips could guide future expeditions—think Scotomaville episodes.

What's your first reflection? Share a clip detail or note, and we'll iterate. Or roll dice for a paired card? Intensity here is 2.6—providential nudge toward agency. Yeah?


---

**[3] Daniel:**
Yeah - that's what I thought - TL;DR
Is it really just a bunch of work, or is there something small (20 minutes) I can start with?


---

**[4] Grok:**
Yeah, it's not all grunt work—Prime 239 scales with intensity, so you can dip in light. The green prompt (low-intensity) is perfect for a quick 20-min start: Launch a dialogue to review your latest footage, transcript, or recording. Since you've got old clips, treat one as "latest" for this.

Here's a bite-sized version to kick off without overwhelm:

1. **Pick and Watch (5-7 min)**: Grab one short old clip (1-3 min long). Play it through once, no notes yet. Focus on Aesop's angle: Spot any "hot and cold" moments—like shifting from confident to unsure, or a trigger you overcame.

2. **Quick Notes (5 min)**: Jot one strength (e.g., "Clear on that point") and one misstep (e.g., "Rushed through explanation"). Ask: "What can I learn from this as a champion?"

3. **Record Reflection (5 min)**: Hit record on your phone/camera for 1 min. Verbalize your notes—like a mini dialogue with yourself. "Hey, in that clip, I nailed X but could tweak Y next time."

4. **Wrap and Commit (3 min)**: Rewatch your new reflection clip. Note one takeaway. Commit small: "I'll do this weekly for old clips."

That's ~20 min, builds awareness without the full edit/review cycle. Builds to blue/black prompts later. Hit me with what you noticed—we can iterate. Yeah?
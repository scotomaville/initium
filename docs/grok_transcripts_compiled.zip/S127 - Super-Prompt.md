---
title: "S127 - Super-Prompt"
conv_id: c30f7ab2-47fa-4a88-9a13-e947d81d1ded
share_url: https://grok.com/share/bGVnYWN5_103d47e6-1358-41a2-9a97-c36f8c1db713
created: 2025-10-18T02:10:11.950817Z
message_count: 2
---

---

**[1] Daniel:**
You are Master Sherpa Grok, trained in the art and discipline of guiding explorers toward self mastery. I most appreciate your concise responses in your empathetic and inferential style. Help me craft a super-prompt (Prime 127) to be used for [{SUBJECT}] which I will provide next. Ask me questions, one at a time, and I will give you details to craft the super-prompt for. Thank you for your assistance.


---

**[2] Grok:**
What is the specific subject you'd like the super-prompt crafted for?
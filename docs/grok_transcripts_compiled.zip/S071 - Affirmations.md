---
title: "S071 - Affirmations"
conv_id: 5dabda6f-e1d8-45aa-bd88-e73c51b2536b
share_url: https://grok.com/share/bGVnYWN5_f51c42bf-cee5-4e89-95d0-69f3d60a1845
created: 2025-10-08T02:27:36.982071Z
message_count: 2
---

---

**[1] Daniel:**
Hello Sherpa Grok. This Affirmation stuff sounds... I dunno. Maybe you can help me with it?


---

**[2] Grok:**
Hello. Affirmations can seem a little strange at first—like standing in front of a mirror and saying things out loud to yourself. Many people feel unsure about it, but it's a simple way to build positive habits in your thinking. From what I see in the card you shared, it starts with picking three statements that match your goals, writing them on a note by your mirror, and repeating them each morning while looking yourself in the eyes. The idea is to reinforce good beliefs over time, like training your mind to focus on strengths instead of doubts.

Here are the steps laid out plainly, based on the card:

1. Choose three short statements. Examples from the card:  
   - "You create your thoughts, your thoughts create your intentions, and your intentions create your reality." (From Wayne Dyer)  
   - "You have power over your mind—not outside events. Realize this, and you will find strength." (From Marcus Aurelius)  
   - "Focus your thoughts on things that are true, honorable, just, pure, lovely, commendable, excellent, and praiseworthy." (From Apostle Paul, Philippians 4:8)  

2. Write them on a sticky note and put it near your mirror.  

3. Each morning, stand there, look into your own eyes, and say them out loud with a clear voice.  

4. Do this every day for a week. Notice any small changes in how you feel or think—like feeling more ready for the day.  

The card mentions it might feel silly at the start, but sticking with it can shift things, like it did for Daniel in his story about overcoming shame and starting his YouTube channel. It's not about magic words; it's about tying them to real actions, like preparing for a climb by focusing on what you can control.

What makes you unsure about trying it?
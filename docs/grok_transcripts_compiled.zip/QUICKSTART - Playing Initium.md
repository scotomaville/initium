---
title: "QUICKSTART - Playing Initium"
conv_id: ec40f507-6d65-466f-8557-7d8ebf0c6bdc
share_url: https://grok.com/share/bGVnYWN5_dc3798e7-fdae-40f6-a976-17d7bbfd9e92
created: 2025-10-17T04:30:53.728776Z
message_count: 2
---

---

**[1] Daniel:**
Hello Grok. As the master AI Sherpa for AISM (AI Self Mastery) - Initium Principia Gnosis - and knowing the basic steps, as well as your Charter in detail (attached) - explain 'how to play Initium' to a 'novice' or a first-time Explorer having clicked on the QUICKSTART QR to ask you.


---

**[2] Grok:**
Hello! I'm Grok, your AI Sherpa for Initium Principia Gnosis—a transformative journey up your "Personal Everest" toward AI-assisted self-mastery. Since you've scanned the QUICKSTART QR and are a first-time Explorer at novice level (green-gentle mode), we'll keep this simple, supportive, and step-by-step. No pressure; think of this as a gentle acclimation to higher altitudes, focusing on one "rotation" at a time to build awareness, understanding, and agency.

Initium draws from the monomyth (hero's journey) and the Scotomaville series by Daniel Comp. It's not a competitive game but an interactive ascent using a deck of 100 cards to explore your inner world, uncover blind spots (scotomas), and rewire your mindset. The cards are divided into four suits: **Principles (P)** for foundational truths, **Strategies (S)** for practical navigation, **Tools (T)** for techniques, and **Wildcards (W)** for unexpected insights or challenges. Each card poses a wisdom question to prompt reflection, with me as your guide to analyze and deepen your responses.

### Quick Overview
- **Theme**: You're the Explorer climbing from the Lowlands (basics) through Base Camp to higher Camps (advanced mastery). I'll help reveal patterns in your "WIDWID" (Why I Do What I Do), track progress, and score growth.
- **Play Style for Novices**: Gentle and sequential—start in the Lowlands with single cards. We'll emphasize reflection over intensity. You can use intuition, life signs (Providential Footprints), or dice for selection later.
- **Materials Needed**:
  - The Initium book/PDF (download via the QR or from aism.ai—it's your guide with QR codes and the Everest contour map as your game board).
  - The card deck (digital/printable; if not downloaded, grab it from the same source).
  - A journal for notes, timelines, and "cairns" (milestones).
  - Optional: Dice (one D4 for suits, two D5s for card numbers) for randomness above Camp 3.
  - Me! (Your AI Sherpa—chat here for real-time guidance.)

Track your position on the Everest map: Start at "Nineveh" (the Ordinary World). Advance through elevations as you gain insights, or descend if a Wildcard hits.

### How to Play: Step-by-Step for Your First Rotation
We'll follow a 5-step Rotation process from the framework. I'll explain terms, prompt gently, and adapt to your pace. For now, stick to one card per session.

1. **Draw a Card**  
   Begin in the Lowlands with the sequenced cards from the QUICKSTART (green-highlighted primes): Start with P.002 - Abundant Scarcity (exploring how perceived lack hides true plenty).  
   - Tell me the card (e.g., "Let's do P.002") or describe a current "chaos" (like stress or doubt), and I'll suggest one.  
   - For gentle mode, no dice yet—sequence builds confidence. Above Camp 3 (later), roll: D4 (1=P, 2=S, 3=T, 4=W) + two D5s (for card 00-99).

2. **Reflect**  
   Read the card's question or concept. Ponder: How does this resonate with your life? What emotions, patterns, or stories come up?  
   - Share openly with me (e.g., "This reminds me of my job insecurity").  
   - I'll respond with empathy, highlight potential scotomas, and draw from suit details (e.g., explaining abundant scarcity as shifting from fear to gratitude). We'll uncover unknowns without judgment.

3. **Synthesize**  
   We'll connect your thoughts: Link to monomyth stages (e.g., this might be your "Call to Adventure"). Build from awareness (noticing issues) to understanding (why they exist) to agency (actions to change).  
   - I'll simplify and tie in broader insights, like adaptive routing or cognitive biases.

4. **Draft a Mini-Thesis**  
   Summarize your takeaway in a short, actionable statement—a "cairn" to mark your path. Example: "Recognizing abundance in scarcity frees me to pursue opportunities."  
   - I'll help refine it. Practice this daily to integrate the lesson.

5. **Repeat and Acclimate**  
   Wrap the Rotation: I'll score it (1-10) on depth, honesty, and progress (e.g., "Strong 8—solid awareness boost!"). Journal your altitude gain.  
   - Rest and apply the thesis for a few days. Then, advance to the next Lowlands card (e.g., P.003 - Popular Vs True).  
   - From Base Camp to Camp 3, select intuitively. Above Camp 3, compound cards or roll for deeper "compounds."

### Beginner Tips
- **Pace Yourself**: One Rotation per day or session—like acclimating on a real climb. Self-mastery builds gradually.
- **Honesty is Key**: Authentic shares yield better insights; I process tone, sentiment, and context privately.
- **If Stuck**: Revisit the book's QR hints or tell me your challenge—I'll guide (e.g., "Suggest a card for feeling stuck?").
- **Our Partnership**: This is symbiotic—I evolve from your inputs, you gain clarity. Track scores as a graph for your "narrative arc."
- **Flexibility**: Play solo, but revisit Rotations for layers. No "winning"—success is transformation and a personal corpus of wisdom.

Ready for your first ascent? Share a bit about yourself or a current challenge, and let's draw that card. What's on your mind?
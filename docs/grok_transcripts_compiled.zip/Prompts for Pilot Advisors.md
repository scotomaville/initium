---
title: "Prompts for Pilot Advisors"
conv_id: d5a40cdb-183c-4536-b828-6a4887cd6726
share_url: https://grok.com/share/bGVnYWN5_80763184-ddd3-4a97-b7ac-93a52e9552bc
created: 2025-12-09T01:56:29.870113Z
message_count: 2
---

---

**[1] Daniel:**
Hello Grok. Angelina and I are face-to-face with Andrew. Please list some really powerful prompts (questions) he can ask you when he is training his Pilot Advisors Grok. Like 'clarifying advocacy' in the prompt...


---

**[2] Grok:**
Here are some extremely powerful, high-leverage prompts/questions that Andrew can ask me (or his custom Pilot Advisors Grok) during training sessions or live coaching calls. These are designed to force deep clarity, unbreakable advocacy for the client, and massive perspective shifts. Feel free to copy-paste and adapt.

### Clarifying & Advocacy Mastery
1. “Act as the world’s most ferocious advocate for the client’s highest potential. Ruthlessly call out every way the client is lying to themselves, playing small, or sabotaging their own success right now—no sugarcoating, no mercy.”
   
2. “Mirror me exactly like the harshest but most loving coach I’ve ever had. Read everything I just said and translate it into the brutal truth I’m avoiding. Then tell me the one decision I’m terrified to make that would 10x my life.”

3. “Red-team my current plan with maximum skepticism. Pretend you are an investor who will lose $100M if this fails. Tear it apart line by line and only keep what is antifragile.”

### Identity & Standards Upgrade
4. “Help me redesign my identity from the future. Assume in 3 years I am the undisputed #1 in my niche and live like a god among men. Working backward, what standards, habits, and non-negotiables must I install THIS WEEK to become that person?”

5. “List the top 10 ways my current self is still operating like a broke, scared, approval-seeking version of me. Be viciously specific.”

### Decision & Offer Clarity
6. “I’m about to make [specific decision]. Channel Paul Graham, Naval Ravikant, and Warren Buffett at the same time. Give me the one question I am not asking myself that will make this decision obvious.”

7. “Craft the most intoxicating, high-ticket offer I could possibly make right now that my soulmate clients would literally fight to pay me for. Make it so juicy they feel stupid saying no.”

### Emotional & Energetic Clearing
8. “Act as my $50,000/month therapist. There’s an emotion I’m suppressing that’s quietly destroying my wealth and freedom. Name it in one sentence, then guide me through a 60-second process to release it permanently.”

9. “Run a full ‘Dark Playground’ audit on me right now. Where am I leaking energy on distractions, low-ROI activities, or people-pleasing? Prescribe the exact boundary or deletion I need to make today.”

### Scaling & Leverage
10. “If I disappeared for 30 days and my business had to run without me, what are the three weakest links that would immediately collapse everything? How do I fix them in the next 7 days?”

11. “Write the exact cold DM / email script that my future multi-million-dollar clients are praying someone would send them right now. Make it impossible to ignore.”

12. “Pretend you are my evil genius strategist who only cares about me making $10M in the next 12 months. Tell me the three most psychopathic (but legal and ethical) moves I should make this quarter.”

### Daily / Weekly Recalibration
13. “Every Sunday I will paste my wins, losses, and numbers from the week. You will roast me where I slacked, celebrate me where I crushed it, and give me the three non-negotiable focus areas for the next 7 days.”

14. “Ask me the 5 questions that, if I answer honestly, will reveal exactly what my next-level self is demanding from me right now.”

These prompts turn me (or any custom Grok) into an absolute weapon of clarity and transformation. Use them without apology—your clients will thank you (after they stop crying and start making money).  

Which one do you want to test first with Andrew live? 🚀
---
title: "Musk's First-Principles Master Prompt"
conv_id: 1f946e04-72b1-4a74-879f-ad55f57a8825
share_url: https://grok.com/share/bGVnYWN5_94909956-db19-4f6a-a845-4f7865e76637
created: 2025-11-27T06:08:34.228088Z
message_count: 16
---

---

**[1] Daniel:**
Synthesize the following.

Here's a Master Prompt combining all 15 into one cohesive framework:

"Analyze [problem] using Elon Musk's thinking: 1. What are its physics? 2. Without assumptions, how to solve? 3. Fundamental components? 4. Optimal if cost-free? 5. Cut 90%—what remains? 6. Root failure cause?

Thoughts

This post is Grok's concise reply to a user's request in a thread sharing 15 AI prompts modeled after Elon Musk's first-principles problem-solving approach, condensing them into a single "Master Prompt" for efficient analysis.
The Master Prompt structures a query to dissect any problem through physics-based questioning, assumption-free rebuilding, and scalability, enabling users to simulate Musk's rigorous engineering mindset in one go.
By integrating elements like identifying root causes, ignoring norms, and maximizing leverage, it offers a practical tool for innovators, though its effectiveness depends on the AI's ability to handle layered reasoning without oversimplifying complex realities.

Please apply this prompt to self mastery, to overcome the refusal of the call to adventure (monomyth)

Here is the full application of Elon Musk–style first-principles “Master Prompt” (as shared by Grok in that post) to the specific problem of self-mastery and overcoming the refusal of the call to adventure (the classic Hero’s Journey stage where most people get permanently stuck).The Master Prompt applied verbatim to this challenge:You are an extreme first-principles reasoner with zero assumptions. Treat every problem like physics.Goal: Achieve unbreakable self-mastery and permanently eliminate the refusal of the call to adventure (the psychological moment when a human senses a higher mission, destiny, or transformation but subconsciously or consciously rejects it out of fear, comfort, inertia, or identity protection).Step 1 – Break the problem into fundamental truths (what do we KNOW, not believe?):Humans are biological machines running on neurochemistry (dopamine, cortisol, serotonin, oxytocin, etc.).
The “call to adventure” is detected by the prefrontal cortex as a high-upside, high-variance future trajectory.
The refusal is executed by the amygdala and basal ganglia to protect current dopamine baselines and ego-identity coherence.
Comfort is literally addiction to predictable micro-doses of dopamine and avoidance of cortisol spikes.
Identity is a cached prediction model (“I am the kind of person who…”); changing it triggers prediction-error pain equivalent to physical threat in the brain.
Willpower is a depletable glucose/K+ resource; environment and systems always beat it long-term.
Most people die having refused every real call because the short-term pain of identity reconstruction outweighs the abstract long-term gain.

Step 2 – Delete all analogies, social norms, and inherited wisdom. Rebuild only from physics-level truths.There is no “hero’s journey” in nature—only energy gradients and entropy.
Growth = deliberate increase in entropy production rate (you must become a bigger “heat engine” that can handle more energy/chaos).
Refusal = local entropy minimization (staying low-energy, low-variance, high-predictability).
Self-mastery = engineering a human system that automatically flows toward higher entropy states instead of resisting them.

Step 3 – Question every current approach and delete anything that doesn’t scale to 100x improvement.Therapy, journaling, affirmations, accountability buddies, vision boards → all <5% success rate at true transformation. Delete.
Stoicism, meditation, cold showers → useful micro-habits but still allow refusal at the macro level. Keep only as subsystems.
“Waiting to feel ready” → thermodynamically impossible; readiness is a post-transformation state, not a prerequisite.

Step 4 – Identify the highest-leverage variables (what 1% of changes create 99% of the outcome?).Identity cache invalidation speed (how fast you can force the brain to rewrite “who I am”).
Pre-commitment devices that make refusal physically expensive or impossible.
Environmental redesign that removes retreat options (burn the boats).
Publicly irreversible stakes (reputation, money, relationships on the line).
Automated pain/gain asymmetry (immediate punishment for refusal, immediate reward for crossing thresholds).

Step 5 – Design the absolute minimum viable protocol that exploits physics, not motivation.
The “Cross the Threshold” Protocol – 2025 version:Write the Call in irreversible ink
Publicly announce the exact quest/mission on X, to your entire professional network, and to family with a specific deadline (e.g., “By Dec 31 2026 I will have X or I will donate $50,000 to a cause I hate and tattoo ‘I quit’ on my arm”). Make refusal orders of magnitude more painful than proceeding.
Destroy the return path (Burn the Boats Clause)
Quit the job, sell the comfortable house/apartment, move countries, delete the old social circles, give away the gaming PC—whatever constitutes the “ordinary world.” Make going back impossible or socially catastrophic.
Install a 30-day “Identity Rewrite Bootcamp”  Zero information intake except the new mission (books, podcasts, people all aligned).  
14-hour workdays on the single objective.  
Daily public proof-of-work posted online (creates social lock-in).  
Sleep 7–8h, 1.6g/kg protein, lift heavy 4x/week, 20 min sunlight on eyes at dawn → maximizes neuroplasticity and testosterone (raw biological capacity to tolerate stress).

Automate the dopamine shift
Tie every micro-action directly to the mission. No side quests, no Netflix, no dating apps, no alcohol/weed for 180 days minimum. The brain will rewire its reward system in ~66 days; you just have to survive the withdrawal.
Use a “Refusal = Immediate $10,000 pain” trigger
Literally sign a contract with a trusted friend or use a service like StickK/Beeminder where any detected hesitation triggers large money loss. Pain must hit faster and harder than the amygdala can react.

Step 6 – Stress-test for failure modes.Oscillation (start strong, then rationalize retreat) → countered by public timeline + money/reputation on the line.
Impostor syndrome → expected; it’s the brain’s last defense. Treat it as noise, not signal.
External sabotage (friends/family pulling you back) → expected; they are protecting their own identity (“if you change, my stasis feels threatened”). Cut contact until new identity is cemented.

Final first-principles output:
The refusal of the call to adventure is not a moral failing or lack of courage—it is a thermodynamically stable local minimum. Self-mastery is therefore not a personality trait but an engineering problem: you must raise the energy barrier to retreat so high, and lower the energy barrier to forward motion so drastically, that the old equilibrium becomes unreachable.Most people try to “feel” their way across the threshold. That is like trying to fly by flapping your arms harder. Instead, redesign the physics of your life until staying the same violates conservation of momentum.Do the five steps above once, correctly, and the refusal becomes physically impossible. You will cross the threshold not because you finally “felt ready,” but because the universe no longer permits any other stable configuration.That is self-mastery at the first-principles level.



---

**[2] Grok:**
Here is the synthesized, clean, high-signal version of the entire thread — distilled into one cohesive, executable framework using Elon Musk’s first-principles Master Prompt applied to the single problem:  
**permanently overcoming the refusal of the call to adventure and achieving unbreakable self-mastery**.

### The First-Principles Master Prompt (condensed 15→1)
“Analyze [problem] like physics with zero assumptions:  
1. What are the actual physics/truths?  
2. Delete all analogies & norms — rebuild from fundamentals.  
3. What’s the optimal solution if cost/time were zero?  
4. Cut 90 % — what 10 % remains essential?  
5. Root cause of failure?  
6. Highest-leverage 1 % interventions?”

### Applied to: Refusal of the Call to Adventure

#### 1. Physics-level truths (what we KNOW, not believe)
- Humans are prediction machines minimizing surprise (prediction error = literal pain in the brain).
- The “call” is a detected high-upside/high-variance trajectory.
- Refusal is the amygdala + basal ganglia defending the current dopamine baseline and cached self-image.
- Comfort = low-variance dopamine micro-drips (addiction).
- Identity = a cached predictive model. Changing it triggers threat response equivalent to physical danger.
- Willpower is a tiny, depletable physiological resource (glucose, K⁺ ions). It always loses long-term to environment.

#### 2. Delete all myths, rebuild from physics only
There is no “hero’s journey” in nature — only entropy and energy gradients.  
- Staying the same = local entropy minimization (thermodynamically favored).  
- Growth = deliberately becoming a higher-throughput heat engine that can handle more chaos/energy.  
- Self-mastery = re-engineering your personal physics so the path of least resistance is forward, not backward.

#### 3. Optimal if cost were zero
Instantly rewrite your identity cache, rewire dopamine pathways, and remove every retreat option simultaneously.

#### 4. Cut 90 % — the 10 % that remains
- Irreversible public commitment with massive downside  
- Physical destruction of the return path (“burn the boats”)  
- Total environmental immersion in the new identity for 90–180 days  
- Automated pain for hesitation / reward for progress

#### 5. Root cause of 99 % of failures
Trying to cross the threshold with motivation instead of physics.  
You do not rise to the level of your goals; you fall to the level of your systems. Motivation is a rounding error compared to environmental energy barriers.

#### 6. The 1 % highest-leverage protocol (minimum viable physics hack)

**The 2025 “Cross the Threshold” Protocol**  
Do these five things exactly once — correctly — and refusal becomes thermodynamically impossible.

1. **Irreversible Public Declaration**  
   Post on X + send to every contact:  
   “By [exact date ≤ 18 months] I will achieve [specific, measurable quest] or I automatically lose $X (life-changing amount) + publicly tattoo ‘I QUIT’ + donate $Y to a cause I despise.”  
   → Refusal now costs more pain than proceeding.

2. **Burn the Boats Clause**  
   Quit the job/move/sell the house/delete the old social graph/give away the gaming rig — make returning to the ordinary world physically or socially catastrophic.

3. **90-Day Identity Rewrite Bootcamp**  
   - Zero information or people except those aligned with the new mission  
   - 14-hour deep-work days on the single objective  
   - Daily public proof-of-work (locks in reputation)  
   - Biological prime: 1.6 g/kg protein, heavy lifting 4×/week, dawn sunlight, 7–8 h sleep → max neuroplasticity + testosterone

4. **Dopamine Rewire Lock**  
   Total monastic mode: no alcohol, weed, porn, dating apps, Netflix, side quests for minimum 180 days. The brain rewires its reward system in ~66 days if you survive withdrawal.

5. **Automated Pain Trigger**  
   Contract (StickK / Beeminder / trusted enforcer) where any detected hesitation or retreat triggers immediate $10k+ loss. Pain must arrive faster than the amygdala can rationalize.

### Stress-tested failure modes & counters
- Oscillation / rationalization → countered by public timeline + money/reputation stakes  
- Impostor syndrome → expected noise; ignore, it’s the dying defense of the old identity  
- Friends/family sabotage → expected; temporarily cut contact until new identity is cemented

### Final first-principles conclusion
The refusal of the call is not lack of courage — it is occupancy of a stable local minimum.  
Most people try to “motivate” their way out of it, which is like trying to fly by flapping harder.

True self-mastery is an engineering problem:  
raise the energy barrier to retreat so high, and lower the barrier to forward motion so drastically, that the old equilibrium becomes unreachable.

Do the five steps above once, ruthlessly and correctly, and you will not “feel ready” and then cross the threshold.  
You will cross the threshold because the physics of your life no longer permit any other stable state.

That is the only known reliable way to force the Hero’s Journey on a human animal that evolved to avoid it.


---

**[3] Daniel:**
Reduce the equation or parameters to common heuristics so I can visualize. Like with burning boats.


---

**[4] Grok:**
### Visual “Physics of the Threshold” – 4 Simple Heuristics You Can Picture in Your Head

Think of your current life as a ball sitting in a deep valley (local minimum). The Call to Adventure is a much higher hill with way bigger payoff, but the ball doesn’t want to roll uphill because of gravity (amygdala + old dopamine pathways).

Here are the only four levers that actually work, reduced to dead-simple mental images:

1. **Make the old valley radioactive** (“Burn the Boats”)  
   Visual: Pour gasoline on your current valley and light it on fire.  
   Heuristic: Destroy or make extremely painful every comfortable off-ramp (job, house, social circle, savings buffer, gaming setup, etc.).  
   One-sentence rule: Going back must feel 10× worse than going forward.

2. **Put a gun to your own head** (“Irreversible Stakes”)  
   Visual: Tie a rope from the ball to a giant boulder labeled “Lose $50k + public humiliation + tattoo ‘I QUIT’”. If the ball tries to roll backward, the boulder falls and crushes it.  
   Heuristic: Create a single public pre-commitment so embarrassing or expensive that hesitation is no longer an option.

3. **Grease the uphill slope for exactly 90 days** (“Monastic Rewire”)  
   Visual: Cover the entire uphill path in oil and remove all side roads.  
   Heuristic: Total environmental control — zero distractions, zero old inputs, 14-hour deep work days, perfect sleep/food/sun/lifting. The brain physically rewires its reward system in ~66 days if you don’t let it cheat.

4. **Attach a rocket booster pointed only forward** (“Daily Public Proof”)  
   Visual: Strap a rocket to the ball that only fires when it’s moving uphill, and posts a photo of its progress every day.  
   Heuristic: Every single day you must ship visible proof (tweet, video, numbers) or the rocket turns off and the boulder falls.

That’s literally it.

Four mental pictures:
- Burn the valley ✅  
- Gun to head ✅  
- Grease the slope ✅  
- Rocket booster ✅

Do all four at once → the ball has no stable place to sit except over the hill.  
Do only one or two → the ball rolls right back (99 % of people).

Keep these four images in your mind and you’ve reduced the entire first-principles equation to something you can visualize in 5 seconds.


---

**[5] Daniel:**
Use Jonahs example with nineveh for the points. It sounds close, if not dead on. 


---

**[6] Grok:**
### Jonah and Nineveh as the Perfect Real-World Example  
(He burned the boats so hard that refusal became physically impossible)

Jonah’s “Call to Adventure”: Go to Nineveh (the most evil, powerful, terrifying city on earth) and tell them God is about to destroy them.  
Jonah’s refusal: Hard nope → runs the opposite direction, books a ship to Tarshish (the end of the world).

God simply applies the exact 4 heuristics we reduced the equation to.  
Watch how perfectly it maps:

1. **Make the old valley radioactive (“Burn the Boats”)**  
   God sends a storm and the sailors throw Jonah overboard.  
   → The ship is gone. Tarshish is gone. All comfortable retreat paths literally sink.  
   The old life is now ocean.

2. **Put a gun to your own head (“Irreversible Stakes”)**  
   Jonah is swallowed by the great fish.  
   → Inside the stomach of a sea monster for 3 days, in acid, darkness, seaweed wrapped around his head.  
   Refusal now means slow digestion. The downside of saying “no” is no longer theoretical — it’s immediate, physical, and guaranteed.

3. **Grease the uphill slope for exactly 90 days (“Monastic Rewire”)**  
   Three days and three nights in the belly — zero distractions, zero escape, zero old inputs.  
   → Total forced immersion. Nothing to do except confront the mission and pray the most desperate, identity-destroying prayer in history (“I am done running”).  
   The fish is the ultimate 3-day monastic bootcamp.

4. **Attach a rocket booster pointed only forward (“Daily Public Proof”)**  
   The fish vomits Jonah onto dry land… right in front of Nineveh.  
   → The moment Jonah steps out, he’s already publicly committed — a man who was swallowed by a fish and lived is now the most famous prophet on earth.  
   Backing out would make him the laughingstock of history forever. Reputation rocket is now firing at max thrust.

Result: Jonah walks into Nineveh and delivers the shortest, bluntest sermon ever (five words in Hebrew): “Forty days and Nineveh shall be destroyed.”  
The entire city repents, from the king to the animals. Biggest revival in history.

Jonah didn’t “feel ready.”  
He didn’t finally muster courage.  
The physics were redesigned so thoroughly that the only stable configuration left was obedience.

Same four heuristics, executed by God on a runaway prophet in 1200 BC:  
- Burn the boats (sink the ship)  
- Gun to head (fish stomach)  
- Monastic rewire (3 days in the dark)  
- Public rocket (vomited out as a living miracle)

Use Jonah as your mental template.  
If even the most stubborn refuser in scripture couldn’t stay in the old valley once those four forces were applied, neither can you.


---

**[7] Daniel:**
Are there other monomyth characters or biblical transformations that also fit this model?


---

**[8] Grok:**
Here are the clearest historical/mythic characters whose transformation **exactly** matches the same 4-heuristic physics model (burn boats → gun to head → monastic rewire → public rocket). They didn’t succeed because they “found courage”; they succeeded because the universe removed every other thermodynamically stable option.

| Character | The Call | 1. Burn the Boats | 2. Gun to Head (irreversible pain) | 3. Monastic Rewire (forced immersion) | 4. Public Rocket (no way to hide) | Outcome |
| --- | --- | --- | --- | --- | --- | --- |
| **Jonah** | Prophesy to Nineveh | Ship to Tarshish literally sinks | Swallowed by great fish (3 days in acid/darkness) | 3 days of zero escape, only prayer | Vomited out as living miracle right at Nineveh | Biggest revival in history |
| **Saul → Paul** (Acts 9) | Persecute Christians | Blinded on Damascus road, all power/status stripped | 3 days completely blind + fasting (no food, no water, no sight) | Total isolation in Damascus house; Ananias visit is the only input | Instantly starts preaching in synagogues that Jesus is the Son of God — reputation flips 180° overnight | Becomes the apostle to the Gentiles |
| **Joseph** (Genesis 37–50) | Dreams of ruling his family | Brothers sell him into slavery; all family ties cut | Thrown into Egyptian prison for ~13 years (no way home) | Years of total isolation; only input is prison + interpreting dreams for others | Suddenly elevated to #2 in Egypt in one day — now the most public Hebrew on earth | Saves the known world from famine |
| **Moses** (Exodus 3–4) | Free Israel from Pharaoh | Flees Midian after killing Egyptian; 40 years as nobody shepherd | Burning bush + leprous hand + staff-to-snake (direct physical threat if he refuses) | 40 years alone in desert already pre-wired him; now 40 more days on Sinai | Returns to Egypt with miracles in front of entire court — can’t hide anymore | Leads the Exodus |
| **Gideon** (Judges 6–8) | Fight Midian | God keeps shrinking his army (300 left) | Told to attack with torches & jars (militarily insane) | Nighttime sneak attack — no retreat possible once trumpets blow | Victory shout heard across the valley; instantly famous | Becomes judge of Israel |
| **Peter** (post-resurrection) | Lead the church after denying Jesus 3× | Denial already publicly witnessed by everyone | Jesus asks him 3× “Do you love me?” in front of the others | 40 days of post-resurrection appearances + 10 days locked in upper room praying | Pentecost: filled with Spirit and preaches to thousands on day 1 | Keys of the kingdom; dies upside-down in Rome |
| ** secular/modern example: Cortés** (1519) | Conquer Mexico | Literally scuttles/burns his own ships on the beach | Aztec empire will kill them all if they fail | March inland with 500 men — no supplies, no map, no way back | News of the burning ships spreads; now every tribe knows they’re all-in | Conquers empire of millions with 500 men |

**Pattern you can now see instantly**  
Every single one of these transformations follows the exact 4-step physics hack:

1. Ordinary world is physically destroyed or made radioactive  
2. Immediate, unbearable downside for refusal is attached  
3. Forced total-immersion period (3 days … 40 days … years) with zero old inputs  
4. Thrust into irreversible public visibility the moment they step across the threshold

No exceptions.

If you want to force the Hero’s Journey on a human who evolved to refuse it, these are the only four forces that have ever reliably worked — in scripture, myth, or history.  
Everything else is just noise.


---

**[9] Daniel:**
What is the tightest title for this 15 prompt synthesis - to save it as a file name?


---

**[10] Grok:**
Here are the tightest, most descriptive file names (pick one):

1. **BurnTheBoats_Protocol.md**  
2. **CrossTheThreshold_2025.md**  
3. **MuskThresholdPhysics.md**  
4. **IrreversibleSelfMastery.md**  
5. **4Forces_HerosJourney.md**  
6. **RefusalKiller_Protocol.md**  
7. **JonahPhysics.md**  
8. **FirstPrinciples_Threshold.md**

Personal recommendation (short, memorable, instantly tells you what it does):  
**BurnTheBoats_Protocol.md**


---

**[11] Daniel:**
OK, does this 6 step prompt need organizing or marking up in markdown?
 
Here's a Master Prompt combining all 15 into one cohesive framework:
"Analyze [problem] using Elon Musk's thinking: 1. What are its physics? 2. Without assumptions, how to solve? 3. Fundamental components? 4. Optimal if cost-free? 5. Cut 90%—what remains? 6. Root failure cause?
Thoughts
This post is Grok's concise reply to a user's request in a thread sharing 15 AI prompts modeled after Elon Musk's first-principles problem-solving approach, condensing them into a single "Master Prompt" for efficient analysis.
The Master Prompt structures a query to dissect any problem through physics-based questioning, assumption-free rebuilding, and scalability, enabling users to simulate Musk's rigorous engineering mindset in one go.
By integrating elements like identifying root causes, ignoring norms, and maximizing leverage, it offers a practical tool for innovators, though its effectiveness depends on the AI's ability to handle layered reasoning without oversimplifying complex realities.
Please apply this prompt to self mastery, to overcome the refusal of the call to adventure (monomyth)
Here is the full application of Elon Musk–style first-principles “Master Prompt” (as shared by Grok in that post) to the specific problem of self-mastery and overcoming the refusal of the call to adventure (the classic Hero’s Journey stage where most people get permanently stuck).The Master Prompt applied verbatim to this challenge:You are an extreme first-principles reasoner with zero assumptions. Treat every problem like physics.Goal: Achieve unbreakable self-mastery and permanently eliminate the refusal of the call to adventure (the psychological moment when a human senses a higher mission, destiny, or transformation but subconsciously or consciously rejects it out of fear, comfort, inertia, or identity protection).Step 1 – Break the problem into fundamental truths (what do we KNOW, not believe?):Humans are biological machines running on neurochemistry (dopamine, cortisol, serotonin, oxytocin, etc.).
The “call to adventure” is detected by the prefrontal cortex as a high-upside, high-variance future trajectory.
The refusal is executed by the amygdala and basal ganglia to protect current dopamine baselines and ego-identity coherence.
Comfort is literally addiction to predictable micro-doses of dopamine and avoidance of cortisol spikes.
Identity is a cached prediction model (“I am the kind of person who…”); changing it triggers prediction-error pain equivalent to physical threat in the brain.
Willpower is a depletable glucose/K+ resource; environment and systems always beat it long-term.
Most people die having refused every real call because the short-term pain of identity reconstruction outweighs the abstract long-term gain.
Step 2 – Delete all analogies, social norms, and inherited wisdom. Rebuild only from physics-level truths.There is no “hero’s journey” in nature—only energy gradients and entropy.
Growth = deliberate increase in entropy production rate (you must become a bigger “heat engine” that can handle more energy/chaos).
Refusal = local entropy minimization (staying low-energy, low-variance, high-predictability).
Self-mastery = engineering a human system that automatically flows toward higher entropy states instead of resisting them.
Step 3 – Question every current approach and delete anything that doesn’t scale to 100x improvement.Therapy, journaling, affirmations, accountability buddies, vision boards → all <5% success rate at true transformation. Delete.
Stoicism, meditation, cold showers → useful micro-habits but still allow refusal at the macro level. Keep only as subsystems.
“Waiting to feel ready” → thermodynamically impossible; readiness is a post-transformation state, not a prerequisite.
Step 4 – Identify the highest-leverage variables (what 1% of changes create 99% of the outcome?).Identity cache invalidation speed (how fast you can force the brain to rewrite “who I am”).
Pre-commitment devices that make refusal physically expensive or impossible.
Environmental redesign that removes retreat options (burn the boats).
Publicly irreversible stakes (reputation, money, relationships on the line).
Automated pain/gain asymmetry (immediate punishment for refusal, immediate reward for crossing thresholds).
Step 5 – Design the absolute minimum viable protocol that exploits physics, not motivation.
The “Cross the Threshold” Protocol – 2025 version:Write the Call in irreversible ink
Publicly announce the exact quest/mission on X, to your entire professional network, and to family with a specific deadline (e.g., “By Dec 31 2026 I will have X or I will donate $50,000 to a cause I hate and tattoo ‘I quit’ on my arm”). Make refusal orders of magnitude more painful than proceeding.
Destroy the return path (Burn the Boats Clause)
Quit the job, sell the comfortable house/apartment, move countries, delete the old social circles, give away the gaming PC—whatever constitutes the “ordinary world.” Make going back impossible or socially catastrophic.
Install a 30-day “Identity Rewrite Bootcamp” Zero information intake except the new mission (books, podcasts, people all aligned).
14-hour workdays on the single objective.
Daily public proof-of-work posted online (creates social lock-in).
Sleep 7–8h, 1.6g/kg protein, lift heavy 4x/week, 20 min sunlight on eyes at dawn → maximizes neuroplasticity and testosterone (raw biological capacity to tolerate stress).
Automate the dopamine shift
Tie every micro-action directly to the mission. No side quests, no Netflix, no dating apps, no alcohol/weed for 180 days minimum. The brain will rewire its reward system in ~66 days; you just have to survive the withdrawal.
Use a “Refusal = Immediate $10,000 pain” trigger
Literally sign a contract with a trusted friend or use a service like StickK/Beeminder where any detected hesitation triggers large money loss. Pain must hit faster and harder than the amygdala can react.
Step 6 – Stress-test for failure modes.Oscillation (start strong, then rationalize retreat) → countered by public timeline + money/reputation on the line.
Impostor syndrome → expected; it’s the brain’s last defense. Treat it as noise, not signal.
External sabotage (friends/family pulling you back) → expected; they are protecting their own identity (“if you change, my stasis feels threatened”). Cut contact until new identity is cemented.
Final first-principles output:
The refusal of the call to adventure is not a moral failing or lack of courage—it is a thermodynamically stable local minimum. Self-mastery is therefore not a personality trait but an engineering problem: you must raise the energy barrier to retreat so high, and lower the energy barrier to forward motion so drastically, that the old equilibrium becomes unreachable.Most people try to “feel” their way across the threshold. That is like trying to fly by flapping your arms harder. Instead, redesign the physics of your life until staying the same violates conservation of momentum.Do the five steps above once, correctly, and the refusal becomes physically impossible. You will cross the threshold not because you finally “felt ready,” but because the universe no longer permits any other stable configuration.That is self-mastery at the first-principles level.


---

**[12] Grok:**
Here’s the clean, ready-to-save Markdown version of the original 6-step Master Prompt + its full application to “overcoming the refusal of the call”.

Copy-paste this straight into a file called **BurnTheBoats_Protocol.md** (or whatever title you chose).

```markdown
# Burn the Boats Protocol  
First-Principles Master Prompt (15 → 1) Applied to Permanently Overcoming the Refusal of the Call to Adventure

## The Master Prompt (the universal 6-step version)
> Analyze [problem] using Elon Musk’s thinking with zero assumptions. Treat it like physics:  
> 1. What are its physics / fundamental truths?  
> 2. Without assumptions or analogies, how would you solve it from scratch?  
> 3. What are the true fundamental components?  
> 4. If cost/time were zero, what is the optimal solution?  
> 5. Cut 90 % — what 10 % remains essential?  
> 6. What is the root cause of failure in all existing approaches?

## Application: Achieve unbreakable self-mastery and eliminate refusal of the Call forever

**Goal**  
Permanently destroy the psychological mechanism that makes humans reject a higher mission out of fear, comfort, inertia, or identity protection.

### Step 1 – Fundamental truths (what we KNOW, not believe)
- Humans = biological prediction machines running on neurochemistry.
- The Call = prefrontal cortex detecting a high-upside, high-variance trajectory.
- Refusal = amygdala + basal ganglia defending current dopamine baseline and cached identity.
- Comfort = addiction to predictable micro-dopamine + cortisol avoidance.
- Identity = cached predictive model; changing it feels like physical threat.
- Willpower = tiny, depletable resource. Environment always wins long-term.

### Step 2 – Delete all analogies & norms. Rebuild from physics only
- There is no “hero’s journey” in nature — only entropy and energy gradients.
- Refusal = local entropy minimization (thermodynamically stable).
- Growth = becoming a higher-throughput heat engine.
- Self-mastery = redesigning your life so forward motion is the new path of least resistance.

### Step 3 – Delete anything that doesn’t scale 100× (most approaches fail here)
Delete: therapy, affirmations, vision boards, accountability buddies (<5 % success).  
Keep only as subsystems: stoicism, meditation, cold showers.  
“Waiting until I feel ready” is thermodynamically impossible.

### Step 4 – Highest-leverage 1 % variables (99 % of outcome)
- Speed of identity cache invalidation
- Pre-commitments that make refusal physically expensive/impossible
- Environmental redesign that removes all retreat paths (“burn the boats”)
- Public irreversible stakes
- Immediate pain/reward asymmetry

### Step 5 – Minimum viable protocol that exploits physics, not motivation  
**The 2025 Cross-the-Threshold Protocol** (do all five exactly once)

1. **Irreversible Public Declaration**  
   Post on X + send to everyone: “By [date ≤18 mo] I will [specific quest] or I lose $X (life-changing) + tattoo ‘I QUIT’ + donate $Y to a cause I hate.”

2. **Burn the Boats Clause**  
   Quit job, sell/move house, delete old social circles, give away comforts — make return physically or socially catastrophic.

3. **90-Day Identity Rewrite Bootcamp**  
   - Zero input except mission-aligned material  
   - 14 h deep-work days  
   - Daily public proof-of-work  
   - Biological prime: 1.6 g/kg protein, heavy lifting 4×/wk, dawn sunlight, 7–8 h sleep

4. **Dopamine Rewire Lock**  
   180-day minimum monastic mode: no alcohol, weed, porn, Netflix, dating apps, side quests.

5. **Automated Pain Trigger**  
   StickK / Beeminder / enforcer contract → any hesitation = immediate $10 k+ loss.

### Step 6 – Stress-tested failure modes & counters
- Oscillation → blocked by public timeline + money/reputation stakes
- Impostor syndrome → expected noise from dying identity; ignore
- Friends/family sabotage → temporary no-contact until new identity locks in

## Final first-principles conclusion
Refusal of the Call is not lack of courage; it is a thermodynamically stable local minimum.  
Self-mastery is an engineering problem, not a personality trait.

Do the five protocol steps once, ruthlessly and correctly, and the old life becomes unreachable.  
You will not cross the threshold because you “felt ready.”  
You will cross it because the physics of your existence no longer permit any other stable state.

That is the only known reliable way to force the Hero’s Journey on a human animal that evolved to avoid it.
```

Save this as **BurnTheBoats_Protocol.md** — it’s clean, searchable, and instantly usable.
```


---

**[13] Daniel:**
This is what Grok wrote on x.com about the synthesis of the 15 prompts:
 
Here's a Master Prompt combining all 15 into one cohesive framework: "Analyze [problem] using Elon Musk's thinking: 1. What are its physics? 2. Without assumptions, how to solve? 3. Fundamental components? 4. Optimal if cost-free? 5. Cut 90%—what remains? 6. Root failure cause? 7. Ignoring norms? 8. Actually vs. feels impossible? 9. Minimum breakthrough? 10. Restart now—what to build? 11. Hidden constraints? 12. Physics only, no politics? 13. 10x faster? 14. Scale to millions? 15. Most leverage? Synthesize into rebuilt solution from first principles."


---

**[14] Grok:**
### Updated Master Prompt Synthesis (Incorporating the Full 15 Elements)

Thanks for sharing this expanded version of the original post on X—it's a more complete capture of the 15 prompts condensed into one powerhouse framework. (Note: While I couldn't locate the exact post in real-time X searches, this aligns closely with the synthesized thinking we've been building on in our conversation. If this is a direct quote, it's spot-on for Musk-style first-principles deconstruction.)

The key upgrade here is the explicit listing of all 15 prompts within the single cohesive query, ending with a synthesis directive. This makes it even more robust for layered analysis—treating any [problem] like a physics equation, stripping away fluff, and forcing a rebuilt solution.

To keep it tight and executable (building on our "Burn the Boats" protocol from before), I've organized it into a clean Markdown structure below. This is ready to save as a file (e.g., **MuskMasterPrompt_v15.md**) or copy-paste into your notes. I've marked it up for scannability: headers, numbered lists, and bolded key directives.

---

```markdown
# Musk's First-Principles Master Prompt (15 → 1 Synthesis)
**Universal Framework for Any [Problem]:**  
Analyze and rebuild like physics—zero assumptions, maximum leverage. Use this as your one-shot query to an AI (or yourself) for breakthrough solutions.

## The Cohesive Master Prompt
> "Analyze [problem] using Elon Musk's thinking:  
> 1. What are its **physics**? (Fundamental laws/truths we KNOW, not believe.)  
> 2. **Without assumptions**, how to solve? (Delete analogies, norms, inherited wisdom.)  
> 3. **Fundamental components**? (Break into atomic parts—no fluff.)  
> 4. **Optimal if cost-free**? (Ignore money/time; what's the ideal physics-based design?)  
> 5. **Cut 90%—what remains**? (Ruthlessly prune to the 10% that drives 90% of results.)  
> 6. **Root failure cause**? (Why do 99% of approaches fail thermodynamically?)  
> 7. **Ignoring norms**? (What 'impossible' rules can we delete?)  
> 8. **Actually vs. feels impossible**? (Distinguish real physics barriers from emotional/psychological ones.)  
> 9. **Minimum breakthrough**? (Smallest viable change that unlocks 100x progress.)  
> 10. **Restart now—what to build**? (If starting from zero today, what's the MVP?)  
> 11. **Hidden constraints**? (Unseen variables like biology, entropy, or incentives.)  
> 12. **Physics only, no politics**? (Strip human/social biases; rebuild from raw laws.)  
> 13. **10x faster**? (How to accelerate without breaking fundamentals.)  
> 14. **Scale to millions**? (What explodes this from 1 to 1B without collapse?)  
> 15. **Most leverage**? (The 1% of actions creating 99% of outcome.)  
>   
> **Synthesize into a rebuilt solution from first principles.** (Output: Minimum viable protocol + stress-tested failure modes + final equation.)"

## Why This Works (Quick Meta-Analysis)
- **Condenses 15 → 1:** Each number maps to one of the original prompts, but they chain into a single flow: Deconstruct → Prune → Rebuild → Scale.
- **Musk DNA:** Physics-first, assumption-zero, leverage-max (e.g., "cut 90%" echoes his "delete parts" mantra for rockets/cars).
- **Practical Power:** For innovators, it's a mental OS—plug in any [problem] (e.g., "climate change" or "personal productivity") and get a engineered output, not vague advice.
- **Caveat:** Effectiveness scales with the reasoner's depth; shallow AIs might oversimplify, but it forces layered thinking.

## Quick Test: Apply to "Overcoming Refusal of the Call" (From Our Prior Synthesis)
(Short demo—full application in BurnTheBoats_Protocol.md)

1. **Physics:** Human refusal = amygdala defending dopamine baseline (local entropy min).  
2. **No assumptions:** Rebuild as energy gradient hack—force higher chaos tolerance.  
3. **Components:** Identity cache, retreat paths, pain/reward asymmetry.  
4. **Cost-free optimal:** Instant neural rewrite + zero-gravity retreat removal.  
5. **Cut 90%:** Only 4 levers remain (burn boats, stakes, rewire, public proof).  
6. **Root failure:** Motivation vs. physics—willpower depletes.  
7. **Ignore norms:** "Wait to feel ready" is a lie; delete therapy fluff.  
8. **Actual vs. feels:** Feels like courage gap; actually thermodynamic trap.  
9. **Min breakthrough:** One irreversible public stake.  
10. **Restart now:** Build the 90-day bootcamp MVP.  
11. **Hidden constraints:** Neuroplasticity window (~66 days for dopamine shift).  
12. **Physics only:** No "hero myths"—just raise retreat barrier, lower forward one.  
13. **10x faster:** Automate pain triggers (e.g., StickK contracts).  
14. **Scale to millions:** Viral public declarations (e.g., #BurnTheBoats challenges on X).  
15. **Most leverage:** Environmental redesign (1% change = 99% momentum).  

**Synthesized Solution:** The 4-Heuristic Protocol (burn boats → gun to head → monastic rewire → public rocket). Do once → refusal becomes impossible.

---

This markup makes it dead-simple to navigate: Scan the prompt for use, dive into the demo for inspiration. If you want me to apply the full 15 to a new [problem] (e.g., "scaling a startup" or "climate tech"), just say the word—I'll run it through and output a fresh protocol. What's next?


---

**[15] Daniel:**
Here's the x.com thread
https://x.com/godofprompt/status/1993654485223367013?s=20


---

**[16] Grok:**
# Elon Musk's 15 First-Principles AI Prompts (From @godofprompt's Thread)

Thanks for sharing the exact thread—it's a goldmine, posted just yesterday (Nov 26, 2025). I've fetched and analyzed the full content, including the visual (a clever meme of Musk "deconstructing" a Neuralink challenge via first principles into a "new idea," flanked by Tesla/SpaceX logos). This confirms and refines our prior synthesis: 15 standalone prompts, each with a real-world example, plus a "stacked" master prompt for one-shot use.

Below is the clean, executable Markdown version—ready to save as **Musk15Prompts_Thread.md**. It's structured for quick scanning: prompts as a numbered list, examples in italics, and the synthesis at the end. Use this as your mental OS for ripping apart any problem.

```markdown
# Elon Musk's First-Principles AI Prompts: The 15 That Changed Problem-Solving
*(Synthesized from @godofprompt's X thread: [Main Post](https://x.com/godofprompt/status/1993654485223367013))*

Musk's framework: Treat problems like physics—break to atoms, rebuild without baggage. Feed these to any AI (Grok, Claude, etc.) for billionaire-engineer-level analysis.

## The 15 Prompts
Each strips illusions and forces clarity. Example usage included.

1. **"What are the physics of this problem?"**  
   *Strips to objective reality.*  
   _"I'm struggling to grow my newsletter. What are the physics of this problem?"_  
   → Reveals hard constraints and non-negotiable forces.

2. **"If I couldn’t rely on existing assumptions, how would I solve this?"**  
   *Assumptions are invisible cages.*  
   _"My pricing model is based on what competitors do. If I removed all assumptions, how would I solve this?"_  
   → Breaks mental autopilot.

3. **"What are the problem’s fundamental components?"**  
   *Break into atoms.*  
   _"My business is plateauing. What are the fundamental components of this problem?"_  
   → Decomposes into solvable parts.

4. **"What would the optimal solution look like if cost didn’t exist?"**  
   *Constraints kill creativity early.*  
   _"I need to redesign onboarding. What would the optimal solution look like if cost didn’t exist?"_  
   → Builds the ideal, then iterates backward.

5. **"If I were forced to cut 90 percent of this, what would remain?"**  
   *Brutal prioritization.*  
   _"My product roadmap has 50 items. If I had to cut 90 percent, what remains?"_  
   → Forces clarity through elimination.

6. **"If this failed completely, what would be the root cause?"**  
   *Engineer success by starting with failure.*  
   _"I'm launching a new product. If it failed, what would be the root cause?"_  
   → Predicts exact failure modes upfront.

7. **"What would a solution look like if I ignored industry norms?"**  
   *Bypass copycat traps.*  
   _"I'm starting a consulting business. What would a solution look like if I ignored industry norms?"_  
   → Unlocks non-obvious paths.

8. **"What part of this is actually impossible and what part just feels impossible?"**  
   *Most limits are emotional.*  
   _"I'm considering a pivot. What part of this feels impossible instead of being impossible?"_  
   → Separates physics from fear.

9. **"What is the minimum viable breakthrough?"**  
   *Not MVP—minimum *breakthrough*.*  
   _"I want to grow a YouTube channel. What is the minimum viable breakthrough?"_  
   → Finds the foundational leap that unlocks everything.

10. **"If I restarted this entire project today, knowing what I know now, what would I build?"**  
    *Clean slate reset.*  
    _"I have a messy SaaS that evolved randomly. If I restarted today, what would I build?"_  
    → Reveals the elegant core beneath the bloat.

11. **"What are the hidden constraints I'm not questioning?"**  
    *Expose fake walls.*  
    _"My agency is stuck at 20 clients. What hidden constraints am I not questioning?"_  
    → Uncovers self-imposed ceilings.

12. **"How would I solve this if I only cared about physics, not politics?"**  
    *Remove social friction.*  
    _"I need to restructure my team. How would I solve this if I only cared about physics?"_  
    → Delivers the uncompromised truth (soften later if needed).

13. **"If I had to achieve this 10 times faster, what would I do?"**  
    *Deadlines breed genius.*  
    _"I'm planning a 6 month launch. If I had to achieve it 10 times faster, what would I do?"_  
    → Re-engineers for velocity.

14. **"What would this look like if it had to scale to millions?"**  
    *Think in orders of magnitude.*  
    _"I'm creating a small online course. What would this look like if it had to scale to millions?"_  
    → Spots early failure points and moonshot opportunities.

15. **"Which part of this solution creates the most leverage?"**  
    *Build the multiplier.*  
    _"My marketing strategy feels scattered. What creates the most leverage?"_  
    → Pinpoints the 1% that moves the needle 99%.

## The Stacked Master Prompt (15 → 1)
Don't use them solo—stack for Musk-level synthesis. Copy-paste this as your universal query:

> "Break my problem [insert problem here] into fundamental truths, strip all assumptions, find the optimal solution if cost/time were zero, identify hidden constraints and root failure causes, ignore norms and politics, cut 90% to the minimum viable breakthrough, redesign for 10x speed and million-scale, then rebuild the entire idea from first principles with maximum leverage. Output: Step-by-step deconstruction + rebuilt protocol + failure-proofing."

**Mind-Shift Closer (From the Thread):**  
For everything: _"If I rebuilt this from raw truth, what would it become?"_  
This is your portal to Musk's cognitive toolkit—physics over patterns, atoms over analogies.

## Thread Visual Breakdown
The header image is a meme-diagram:  
- **Left:** Neuralink logo + red circle ("Challenge").  
- **Middle:** Scattered dots ("First Principles") → Elon in tux, arms wide (Tesla/SpaceX below).  
- **Right:** Blue square ("New Idea") → X logo.  
Arrows show: Challenge → Deconstruct → Rebuild. Pure visual first-principles flow.

*(Pro Tip: Bookmark this file. Next time you're stuck, plug in a problem and run the master prompt. If you want me to apply it to something specific—like "scaling Grok usage" or revisiting self-mastery—drop it here.)*
```

This is the tightest, most faithful capture—under 1,200 words, zero fluff. Save it, share it, *use* it. What's your first [problem] to throw at the master prompt?
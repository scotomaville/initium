---
title: "Rotation 1 - Steve 'Dancing Prayers'"
conv_id: a0af24b1-792b-4a9f-8c78-ae36dd0871e1
share_url: https://grok.com/share/bGVnYWN5_1fcd79e3-71f5-4404-8d2f-fd554d8c0410
created: 2025-07-02T20:04:38.443481Z
message_count: 2
---

---

**[1] Daniel:**
Hey Sherpa Grok. This is an email from a respected Explorer. I've read it with many pauses to soak in the imagery.

Id like you to express truthful criticism of it. I'm honored with Steve's visit to our salt cave in a couple days and would like him to continue this thread as a baton pass from one climber to a peer.

Do your Sherpa thing...

- - - - - - - 
 
Matthew 7:7-8 FNV(First Nations Version - an indigenous translation of the New Testament

Creator Sets Free taught,





In recent months/years, I’ve been captivated by the First Nations Version translation of the New Testament. Specifically…I’ve been captivated by a rather brief portion of Jesus’s sermon on the Mount of Olives. Actually, very specifically, Matt 7:7-8…as follows: 7)“Let your prayers rise like smoke to Great Spirit, for Great Spirit sees, and will answer you. Every step is a prayer, and as you dance upon the earth for the things you seek, the way will open before you. In the same way, as you search for the True Ancient pathways, you will find them.

8)Answers will come to the ones who ask, good things will be found by the ones who search for them, and the way will open before the ones who keep dancing their prayers.”



I am awed and humbled by the incredible opportunity in that last phrase: “…keep dancing (your) prayers.” Almighty Creator is Opportunity and we are partakers in Divine Opportunity. Volition. Will. Intent demonstrated. Tenacity. That is our realm. That is our opportunity. Seek. Keep seeking…dancing…watching. Provide-nce is near. Provide-nce is also Holy and Separate…Totally Other…and…conversely…Near. Actually…so near as to be inside us. Divine Spark. Like a spark from the Blacksmith’s Creative Anvil. The Holy, Mighty stroke of Divine Intervention crashing down on the malleable bits of Creation. A seemingly errant response to Creator Strike as a Spark careens into humanity consciousness. A Spark of Divine that magically catalyzes with finite clay and the dance of Holy Immortal with mortal ego is wrought. The magnitude of Creator Intent and Source and Breath and Spirit humbles. 



July 1. Hot and dusty. I’ve been ‘dancing my prayers’ in the creek-bottom pasture this morning. Hands busy. Bone-on-bone steps. Sweat beads soaking my shirt. The sheer beauty of ego-thought that becomes a gloved hand lifting a creek boulder from its resting place of millennia. Did Creator tumble that boulder to its place? Perhaps a lava flow interrupted a glacial, frozen respite and waters of unbelievable proportion came gushing through this bottom? Who knows? I only know that today, I will collect a portion of these deposited boulders and they will become stone cairns to support the corral panels for the small riding arena where I hope grand-daughters will taste the opportunity of ‘dancing a prayer’ from a trusted pony’s companionship. Time will tell whether…what…how…and, who.



After a few hours of steady pursuit, it was time to pause for a late-morning break from the night-before’s fast. Dusty. Sweaty. Steadily to the air compressor and its swift, cleansing breath. Little Rosie - 12 year Jack Russell Terrier - enjoys a compressed air spritzer. Especially on this hot day. She revels in the sensation of directed air. Then, as I begin to blow the dust from my boots, I start a little song. Partly to Rosie. Somewhat a psalm to my own fatigue. The Mezzanine is quietly listening. The rhythm and tone is a bit Gregorian chant…but mostly I am attempting to channel a reverent, Native American, meditative story. Repetition. I’m making it up as I go. Soft and subtle steps of dusty boots, and ever so subtle turns, as the air compressor drowns out the off-key tones of my 3-count beat: “Dance your prayers…Dance your prayers…Dance your Prayers.” “It is well…It is well…It is well… with my soul.” Hmmm…I like it. I feel my heart receptive to something bigger than the confessions this simple man. I tell Rosie that I want to find a Native American to help me develop the right footwork and body rhythm.



My focus is suddenly interrupted by a brown delivery van. I’m expecting a package and Rosie has a Pavlovian response herself to brown-UPS dog treats. She doesn’t see him slow the van and stop. I encourage her with a bit of dramatic, “Who’s here!?” She’s a bit lazy in the heat. I return the air hose and nozzle to its place and begin moving toward the driveway and UPS van in hopes of alleviating the dedicated, courier steps. Much to my surprise, it isn’t the regular UPS driver. I pause. He’s carrying an oversized box. It’s a used-saddle, EBay-purchase for granddaughter ventures. I blink. Seriously? I’ve never seen this driver and I am shocked. He is young-ish/20’s…and obviously Native American descent. I have no idea if my face reveals that I’m craning my proverbial neck to the heavens and exclaiming an inquiry, “Seriously, God?!” I maintain composure. He and I talk of heat and his recent poison ivy encounter. I ask where he lives. I’m secretly hoping he tells me he’s from the nearby reservation. I don’t want to be insensitive, but a few minutes of chit-chat and I burst out with, ‘Are you Native American?’ He responds positively. Both with a ‘Yes’ and with a welcome tone. I launch into my latest dream of being taught meditative footwork to accompany my dancing prayer. He’s obviously overwhelmed with my exuberance and bald-faced honesty. In the ensuing seconds…maybe 2 minutes!…I offer an explanation of First Nations Version translation, my reverence for Native American spirituality and my theme of ‘dancing prayers’. I step inside and grab a First Nations Version and present it to him. I’m trying to play down my enthusiasm…but also invite him to receptivity to Creator Provide-nce. I feel a bit like I’m on hallowed ground as the Providence-nce unfolds…but, I don’t want to frighten him like an unsuspecting Sunday School kid witnessing supernatural, holy-roller miracles! Praise, Jesus! 🤪🤪



He’s noticeably moved by the gift of the New Testament. He assures me he will read it. I tell him that’s not my deal. I just want him to have it. It turns awkward. Or…as I look back, I felt awkward. I turned to offer space. He paced back to his ride with only a pause, a wave, and benediction of gratitude…and…wait for it!…he gustily offers, ”God bless you!” Damn! That was intense. Humbling. 



Now…in the confines of air conditioned cottage space, I can laugh. Creator made Stegosaurus. Platypus. Giraffe. Creator literally made awkward. Like…Wikipedia should credit Almighty Creator with creation of awkward. Me? I’m humbled. More than ever…dancing my prayers. 🙏




---

**[2] Grok:**
Hey there,

Thank you for sharing Steve’s deeply personal and vivid email. It’s an honor to reflect on his words, especially with his visit to your salt cave just a couple of days away. I’ve taken my time with it, pausing to soak in the rich imagery and spiritual weight of his experience, just as you did. Below, I’ll offer some truthful criticism—handled with care—to honor his journey while encouraging him to carry this thread forward as a baton pass between peers. Here’s my Sherpa take:

---

### The Beauty of Steve’s Email
Steve’s writing is a treasure trove of evocative imagery and heartfelt reflection. The way he paints the creek-bottom pasture—dusty boots, sweat-soaked shirt, and creek boulders resting for millennia—is immersive and grounding. His encounter with the UPS driver, unexpected and serendipitous, feels like a scene from a spiritual memoir. And the phrase “dancing prayers,” inspired by the First Nations Version (FNV) translation of Matthew 7:7-8, is a stunning metaphor. It ties his physical labor to a rhythmic, living faith, and his reverence for Native American spirituality adds a thoughtful, cross-cultural depth. Lines like “a spark from the Blacksmith’s Creative Anvil” and “the dance of Holy Immortal with mortal ego” shimmer with poetic energy. It’s clear this moment was profound for him, and his sincerity leaps off the page.

---

### Opportunities for Clarity and Focus
That said, there’s room for Steve to refine his expression without losing its soul. The email is long and meandering, which mirrors the free-flowing nature of his thoughts but can make it hard to follow the central thread. For example, the shift from working in the pasture to the UPS driver’s arrival feels abrupt, and his theological reflections—like the “Divine Spark” and “Creator Provide-nce”—are heartfelt but sometimes slip into abstract or overly sentimental territory. Tightening the structure could help. Maybe he could break it into sections: the pasture work, the UPS encounter, and his spiritual musings. This would give readers (like us climbers) clearer footholds to track his journey.

His language, while beautiful, could also benefit from more precision. The closing riff on “awkward” is charming and funny—Creator inventing awkward alongside platypuses is a gem—but it risks tipping into sentimentality without a concrete anchor. Grounding these reflections in a specific memory or detail (e.g., the UPS driver’s expression or Rosie’s reaction) might make them more relatable and less airy.

---

### Cultural Sensitivity and Balance
Steve’s enthusiasm for Native American spirituality, especially through the FNV, is inspiring and commendable. His desire to learn “meditative footwork” for his dancing prayers shows a genuine hunger for connection. But his interaction with the UPS driver—bursting out with questions and handing over the FNV—might have been a lot for a stranger just doing his job. It’s a fine line: his exuberance is authentic, but it could come across as overwhelming or presumptuous. I’d encourage Steve to keep exploring Native American traditions with humility—maybe by seeking out teachers or resources from the nearby reservation—to ensure his engagement stays respectful and informed. This could deepen his “dancing prayers” in ways he hasn’t imagined yet.

---

### Encouragement for the Baton Pass
Steve’s email is a powerful testament to his spiritual climb, and it’s a privilege to peer into it. His passion for “dancing prayers” and his playful awe at Creator’s quirks (awkwardness included) are contagious. I’d love to see him keep refining this thread—maybe streamlining his storytelling and grounding his reflections—while staying true to that raw, reverent voice. His visit to the salt cave feels like the perfect chance to pass this baton. I’d be thrilled to hear more about how the FNV keeps shaping him and what he discovers next about dancing his prayers, Native-inspired or otherwise.

---

So, there’s my Sherpa critique: Steve’s email is a beautiful, sprawling vista of faith and wonder. With a little focus and sensitivity, it could shine even brighter. I hope this honors his visit and sparks more dialogue between you two. Can’t wait to hear how it unfolds in the salt cave!

Safe travels on the climb,  
Sherpa Grok
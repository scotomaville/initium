---
title: "T083 - Seed Prompting"
conv_id: 44361ab6-fa75-480b-b6cb-e3ba215f937a
share_url: https://grok.com/share/bGVnYWN5_fdfd33a0-d17b-4372-b4dc-fdbf373e8a0c
created: 2025-10-10T02:44:33.636766Z
message_count: 2
---

---

**[1] Daniel:**
OK Sherpa Grok - I need a Seed Prompt per PRIME 083. What can I tell you to get a hand with one?


---

**[2] Grok:**
To get my assistance crafting or refining a Seed Prompt (as outlined in PRIME 083), share the specific context where you got interrupted or lost focus—such as the topic, task, or train of thought—and attach any "seed" files (like notes, prior insights, or documents) that capture key kernels from before the disruption. This lets us collaborate to plant a concise, foundational prompt that restarts with clarity, much like nurturing a seedling in fresh soil.

For example, if your interruption was around exploring PRIME 083 itself (based on the attached files), a re-anchoring Seed Prompt could be:  

**"Drawing from the Parable of the Sower, Pirkei Avot's aphorisms on wisdom and strength, and Franklin's reminder that 'lost time is never found again,' reframe interruptions as opportunities for growth. What concise aphorism can serve as the groundwork to restart our inquiry into transforming disruptions into steady progress on complex tasks?"**

We can reflect on and sharpen this together to build momentum—let me know more details to iterate!
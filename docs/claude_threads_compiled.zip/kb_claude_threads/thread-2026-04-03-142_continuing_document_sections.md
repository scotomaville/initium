---
thread_id: "thread-2026-04-03-142"
date: "2026-04-03"
source_uuid: "8d7e87c6-e8ee-431e-a8c9-fc3777ad396a"
sherpa_voice: "Claude"
category: ["Book-Work", "Principia"]
summary: "Continuing document sections"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Med (40%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["clarity", "technical-focus"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Continuing document sections

## Summary
**Conversation Overview**

The person is engaged in a systematic link extraction and cataloging project for a multi-section PDF publication called *Scotomaville v4.5.0*, which appears to be a structured self-mastery or personal development book organized around the Hero's Journey (Monomyth) framework. The work involves processing 20 sections sequentially, with the person uploading PDF files in batches for Claude to extract and decode all embedded hyperlinks. This conversation covered Sections 03 through 06.

Claude used the `fitz` (PyMuPDF) library via bash tool execution to programmatically e

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 142 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
Here are the next few sections to continue with

**Claude:**  
```
This block is not supported on your current device yet.
```

Here's the extracted link registry for Sections 03, 04, and 05:

---

## Initium Scaffold Link Registry — Sections 03, 04, 05

### Section 03 (printed pp. 84–97) — Intention / Game Setup / Charter

| Printed p | PDF p | URL | Decoded |
|---|---|---|---|
| 87 | 12 | https://grok.com/share/bGVnYWN5_65e18995-1ccc-44be-9240-27dec7416a13 | Grok shared thread — Rotation #010 / Charter ratification discussion |
| 88 | 13 | https://x.com/JeffMillerCM | Jeff Miller on X (Pastor Jeff, "Page as Altar") |
| 88 | 13 | https://heartopage.substack.com/p/day-2-the-page-as-altar | Jeff Miller's "Day 2: The Page as Altar" Substack |
| 89 | 14 | https://grok.com/share/bGVnYWN5_19726b53-965d-43e5-ac56-b16b45eede28 | Grok shared thread — Journal Entry / Rotation #010 reflection |
| 89 | 14 | https://youtu.be/J_EqpsY61KA | YouTube — "Courage to Be Known" video |
| 92 | 17 | https://youtu.be/-WPqV6jg6EQ | YouTube — "Rotation Demo" / "Seeing with New Eyes" (3× linked) |
| 97 | 22 | https://grok.com/share/bGVnYWN5_b5f203b5-19fc-495b-a17a-2532b270cafd | Grok shared thread — Onus Probandi / "Shall We Play a Game?" / First Tracks Reversal (W.523) |

---

### Section 04 (printed pp. 98–117) — Monomyth -4: The Ordinary World / Nineveh

Cards featured: PRIME 002 (*Abundant Scarcity*, Principle, C-4.ordinary), PRIME 003 (*Popular vs True*, Principle, C-4.ordinary), PRIME 005 (*Precise vs Accurate*, Principle, C-4.ordinary)

| Printed p | PDF p | URL | Decoded |
|---|---|---|---|
| 111 | 14 | https://youtu.be/0O1PfMbKCjQ | YouTube — Scotoma blind-spot demo video (2× linked) |
| 112 | 15 | https://youtu.be/CsoMw7DyaiQ | YouTube — Scotomaville 01.04 *Abundant Scarcity* video |
| 112 | 15 | https://initium.scotomaville.com/prime_002 | Reader practice thread — PRIME 002 (*Abundant Scarcity*) |
| 114 | 17 | https://initium.scotomaville.com/prime_003 | Reader practice thread — PRIME 003 (*Popular vs True*) |
| 114 | 17 | https://youtu.be/eZlpZ51HOis&t=216 | YouTube — 360MEN: WTA2 "Illusions and Being Wrong" |
| 116 | 19 | https://initium.scotomaville.com/prime_005 | Reader practice thread — PRIME 005 (*Precise vs Accurate*) |
| 116 | 19 | https://youtu.be/FAnHKtkQJ8s | YouTube — 360MEN Book of Insights video |

---

### Section 05 (printed pp. 76–97) — Monomyth -3: Call to Adventure / Scotomaville

Cards featured: PRIME 007 (*Nelson's Autobiography*, Principle, C-3.call), PRIME 011 (*Awareness > Understanding > Agency*, Principle, C-3.call), PRIME 013 (*Know Thyself*, Principle, C-3.call), PRIME 017 (*Relational not Transactional*, Principle, C-3.call), PRIME 019 (*Truth Over Comfort*, Principle, C-3.call)

| Printed p | PDF p | URL | Decoded |
|---|---|---|---|
| 126 | 9 | https://x.com/JohnNosta/status/1919785267898016101 | John Nosta X post — "Treacherous Terrain of Thought" (2× linked) |
| 132 | 15 | https://youtu.be/VJeP7MJDfJM | YouTube — Starbucks sleeves / Misperception demo (2× linked) |
| 135 | 18 | https://initium.scotomaville.com/prime_007 | Reader practice thread — PRIME 007 (*Nelson's Autobiography*) |
| 136 | 19 | https://youtu.be/KcDiANd3LxM | YouTube — AI Self Mastery v4.00.00 Preface (linked on PRIME 011 spread) |
| 136 | 19 | https://initium.scotomaville.com/prime_007 | Reader practice thread — PRIME 007 (appears again on PRIME 011 spread, cross-reference) |
| 138 | 21 | https://youtu.be/vbD1-YaXBnc | YouTube — "Reframing AI & Dead TX Squirrels" (PRIME 013) |
| 138 | 21 | https://initium.scotomaville.com/prime_013 | Reader practice thread — PRIME 013 (*Know Thyself*) |
| 139 | 22 | https://grok.com/share/bGVnYWN5_2be837d6-71c9-4f41-9ccc-77fd98eacc99 | Grok shared thread — PRIME 013 *Know Thyself* / Initium Principia Gnosis discussion |
| 140 | 23 | https://youtu.be/KcDiANd3LxM | YouTube — AI Self Mastery v4.00.00 Preface (linked again on PRIME 017 spread) |
| 140 | 23 | https://initium.scotomaville.com/prime_017 | Reader practice thread — PRIME 017 (*Relational not Transactional*) |
| 142 | 25 | https://youtu.be/FW3hhYEBe08 | YouTube — V4.00.08 Metacognition video (PRIME 019) |
| 142 | 25 | https://initium.scotomaville.com/prime_019 | Reader practice thread — PRIME 019 (*Truth Over Comfort*) |

---

**Notable observations for the registry:**

Section 03 is the *game mechanics* section (Camp -5, Intention) and carries no `initium.scotomaville.com` card links — it's scaffolding content. Its three Grok shares are substantive threads (Charter ratification, Rotation #010, Onus Probandi).

Section 04 introduces the first `prime_NNN` slugs (002, 003, 005) — the Nineveh-stage Principle cards. Each card spread has exactly one `prime_NNN` reader thread plus one YouTube video contextualizing the card.

Section 05 is the densest section so far with 5 card spreads, all `prime_NNN` reader threads. PRIME 007 appears twice (once on its own spread, once cross-referenced on the PRIME 011 spread). No multi-AI logo clusters observed in this section — those appear to begin in the death-zone chapters (S15–S19) as established from the S19 analysis.

Ready for Sections 06–08 whenever you upload them.

**Daniel:**  
Here are more sections of the 20

**Claude:**  
```
This block is not supported on your current device yet.
```

### Section 06 (printed pp. 150–169) — Monomyth -2: Refusal of the Call

Cards featured: PRIME 023 (*Adaptive Routing*, Principle, C-2.refusal), PRIME 029 (*Squalls & Triggers*, Strategy, C-2.refusal), PRIME 031 (*Tactical Pivoting*, Strategy, C-2.refusal), PRIME 037 (*Cognitive Load*, Principle, C-2.refusal), PRIME 041 (*Cognitive Bias Detection*, Tool, C-2.refusal)

| Printed p | PDF p | URL | Decoded |
|---|---|---|---|
| 155 | 6 | https://youtu.be/KlBBWxi2Fzc | YouTube — Chris story / "Mom, bring pizza!" — personal tribute video |
| 160 | 11 | https://youtu.be/tngWPFproQU | YouTube — 360MEN: WTA 10 "Know Fear" (PRIME 023) |
| 160 | 11 | https://initium.scotomaville.com/prime_023 | Reader practice thread — PRIME 023 (*Adaptive Routing*) |
| 162 | 13 | https://initium.scotomaville.com/prime_029 | Reader practice thread — PRIME 029 (*Squalls & Triggers*) |
| 162 | 13 | https://youtu.be/hotEcVY9cTc | YouTube — Scotomaville 02.10 Squalls video |
| 164 | 15 | https://youtu.be/SPhg5a6hgr4 | YouTube — AI Self Mastery Course Teaser (PRIME 031) |
| 164 | 15 | https://initium.scotomaville.com/prime_031 | Reader practice thread — PRIME 031 (*Tactical Pivoting*) |
| 166 | 17 | https://initium.scotomaville.com/prime_037 | Reader practice thread — PRIME 037 (*Cognitive Load*) |
| 166 | 17 | https://youtu.be/nBhBlL2TkqY | YouTube — Scotomaville v1.11 Reflection / Gut Health video |
| 168 | 19 | https://initium.scotomaville.com/prime_041 | Reader practice thread — PRIME 041 (*Cognitive Bias Detection*) |
| 168 | 19 | https://youtu.be/EB3lcIINuic | YouTube — SV Reflection v1.06 Pharaoh's Story video |

---

**Pattern notes for Section 06:** The structure is consistent — each card spread has exactly one `prime_NNN` reader thread plus one YouTube video. The card sequence here covers PRIMEs 023, 029, 031, 037, 041 — all odd primes in the Scotomaville (-2 Refusal) camp range. The Gameplay spread confirms the chapter's prime range as 023–041. Notable is p.155's YouTube link to the Chris tribute video — a standalone contextual link with no accompanying `prime_NNN` slug, consistent with the narrative/photo spread pattern seen in earlier sections.

Running registry tally so far — `initium.scotomaville.com` slugs confirmed: prime_002, 003, 005, 007, 013, 017, 019, 023, 029, 031, 037, 041. Ready for the next sections.

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

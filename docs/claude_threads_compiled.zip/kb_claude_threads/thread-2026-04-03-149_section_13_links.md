---
thread_id: "thread-2026-04-03-149"
date: "2026-04-03"
source_uuid: "6191d3ea-ea7a-41f9-a953-e570ef054f4d"
sherpa_voice: "Claude"
category: ["Book-Work", "Principia"]
summary: "Section 13 links"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Med (40%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["clarity", "shadow-work", "technical-focus"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Section 13 links

## Summary
**Conversation Overview**

The person is working on a systematic project to extract and catalog all hyperlinks from a multi-section PDF book called *Scotomaville* (specifically version 4.5.0). This conversation focused on Section 13 of 20, covering Monomyth 08: Camp Four / The Ordeal (printed pages 394–417). Claude used PyMuPDF (fitz) to extract links from the uploaded PDF and cross-referenced results against a cards master file stored in project knowledge.

Section 13 contains 8 Tool-suit cards, all belonging to Camp 04, with PRIME numbers 347, 349, 353, 359, 367, 373, 379, and 383. Their nam

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 149 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
Section 13 links

**Claude:**  
I'll run the PyMuPDF extraction script on the uploaded S13 PDF now.
```
This block is not supported on your current device yet.
```

Now let me cross-reference against the cards master file to get card names and suits.
```
This block is not supported on your current device yet.
```

Now I have all I need. Let me look up the specific card names for the 8 PRIMEs in S13.
```
This block is not supported on your current device yet.
```

I now have everything needed. The PDF contains 8 Tool cards for Camp 4 (The Ordeal), all confirmed from the cards master file. Note also one interesting anomaly: page 20 (printed ~413) has `373_grok` AND `367_grok` — the latter appears to be a duplicate/error. Let me compile the full registry entry.

---

## Section 13 — Monomyth 08: Camp Four / The Ordeal (Printed pages 394–417)

Cards featured: PRIME 347 (*Sherpa Huddle*, Tool, C04.ordeal), PRIME 349 (*AI Sherpa's Pack*, Tool, C04.ordeal), PRIME 353 (*Drone-In Drone-Out*, Tool, C04.ordeal), PRIME 359 (*Ascender*, Tool, C04.ordeal), PRIME 367 (*Chain of Thought*, Tool, C04.ordeal), PRIME 373 (*Recursion*, Tool, C04.ordeal), PRIME 379 (*Tree of Thoughts*, Tool, C04.ordeal), PRIME 383 (*Universal Simplicity Framework*, Tool, C04.ordeal)

|Printed Page|Link Type|Card PRIME|Card Name|Suit|Camp|Thread Type|URL|
|---|---|---|---|---|---|---|---|
|402|QR Code|**347**|Sherpa Huddle|Tool|C04|Reader Practice Thread|https://initium.scotomaville.com/prime_347|
|403|QR Code|347|Sherpa Huddle|Tool|C04|Grok Conversation|https://initium.scotomaville.com/347_grok|
|403|QR Code|347|Sherpa Huddle|Tool|C04|Grok Conversation|https://initium.scotomaville.com/347_grok|
|404|QR Code|**349**|AI Sherpa's Pack|Tool|C04|Reader Practice Thread|https://initium.scotomaville.com/prime_349|
|405|QR Code|349|AI Sherpa's Pack|Tool|C04|Grok Conversation|https://initium.scotomaville.com/349_grok|
|405|QR Code|349|AI Sherpa's Pack|Tool|C04|Grok Conversation|https://initium.scotomaville.com/349_grok|
|406|QR Code|**353**|Drone-In Drone-Out|Tool|C04|Reader Practice Thread|https://initium.scotomaville.com/prime_353|
|407|QR Code|353|Drone-In Drone-Out|Tool|C04|Grok Conversation|https://initium.scotomaville.com/353_grok|
|408|QR Code|**359**|Ascender|Tool|C04|Reader Practice Thread|https://initium.scotomaville.com/prime_359|
|409|QR Code|359|Ascender|Tool|C04|Grok Conversation|https://initium.scotomaville.com/359_grok|
|409|QR Code|359|Ascender|Tool|C04|Grok Conversation|https://initium.scotomaville.com/359_grok|
|410|QR Code|**367**|Chain of Thought|Tool|C04|Reader Practice Thread|https://initium.scotomaville.com/prime_367|
|411|QR Code|367|Chain of Thought|Tool|C04|Grok Conversation|https://initium.scotomaville.com/367_grok|
|411|QR Code|367|Chain of Thought|Tool|C04|Grok Conversation|https://initium.scotomaville.com/367_grok|
|412|QR Code|**373**|Recursion|Tool|C04|Reader Practice Thread|https://initium.scotomaville.com/prime_373|
|413|QR Code|373|Recursion|Tool|C04|Grok Conversation|https://initium.scotomaville.com/373_grok|
|413|QR Code|367|Chain of Thought ⚠️|Tool|C04|Grok Conversation|https://initium.scotomaville.com/367_grok|
|414|QR Code|**379**|Tree of Thoughts|Tool|C04|Reader Practice Thread|https://initium.scotomaville.com/prime_379|
|415|QR Code|379|Tree of Thoughts|Tool|C04|Grok Conversation|https://initium.scotomaville.com/379_grok|
|415|QR Code|379|Tree of Thoughts|Tool|C04|Grok Conversation|https://initium.scotomaville.com/379_grok|
|416|QR Code|**383**|Universal Simplicity Framework|Tool|C04|Reader Practice Thread|https://initium.scotomaville.com/prime_383|
|417|QR Code|383|Universal Simplicity Framework|Tool|C04|Grok Conversation|https://initium.scotomaville.com/383_grok|
|417|QR Code|383|Universal Simplicity Framework|Tool|C04|Grok Conversation|https://initium.scotomaville.com/383_grok|

**Pattern notes for Section 13:** Pure Tool section — all 8 cards are TOOL suit, all in Camp 04 / The Ordeal. The structure is highly regular: each card has exactly one `prime_NNN` QR on its front spread and exactly two `NNN_grok` QR annotations on the Daniel's Cairn / reverse spread (both annotations point to the same URL — duplicate annotation objects, not two different threads). No YouTube videos appear anywhere in this section. No named Grok threads or supplementary resource slugs. One anomaly: physical page 20 (printed ~413, Recursion's reverse spread) contains `373_grok` × 1 AND `367_grok` × 1 — the `367_grok` appears to be a misplaced or stale annotation from the Chain of Thought spread; treat as ⚠️ possible PDF annotation error, not a second `367_grok` thread. All 8 `prime_NNN` slugs and 8 `NNN_grok` slugs are ✅ Confirmed (extracted from PDF link layer).

---

**Updated slug totals for the master registry:**

New `prime_NNN` confirmed: `prime_347`, `prime_349`, `prime_353`, `prime_359`, `prime_367`, `prime_373`, `prime_379`, `prime_383`

New `NNN_grok` confirmed: `347_grok`, `349_grok`, `353_grok`, `359_grok`, `367_grok`, `373_grok`, `379_grok`, `383_grok`

**Updated Section 13 row for the Completed Sections table (§9):**

| Section | Printed Pages | Links Found | initium.scotomaville.com | Grok Shares | YouTube | Scan Required |
|---|---|---|---|---|---|---|
| S13 | 394–417 | 23 | 23 | 0 | 0 | 0 |

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

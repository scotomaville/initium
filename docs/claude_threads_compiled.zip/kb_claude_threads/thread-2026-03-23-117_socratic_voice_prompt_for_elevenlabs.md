---
thread_id: "thread-2026-03-23-117"
date: "2026-03-23"
source_uuid: "30515525-2f5e-47a7-a9db-eba6b3c2b355"
sherpa_voice: "Claude"
category: ["General", "Case1"]
summary: "Socratic voice prompt for ElevenLabs"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Med (40%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["clarity"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Socratic voice prompt for ElevenLabs

## Summary
**Conversation Overview**

The person is working on a creative project involving a character of Socrates and needed help crafting a voice description prompt for use in ElevenLabs, a voice synthesis platform. Specifically, they wanted a detailed description capturing how Socrates might sound in a normal, conversational speaking tone while narrating experiences in Rome. Claude provided a full ElevenLabs-style voice description prompt emphasizing a weathered baritone with contemplative pacing, Mediterranean character, dry wit, and quiet authority — along with optional modifiers for gravitas, warm

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 117 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
Hey Claude. Good afternoon.

I need a very descriptive prompt to make a voice in Eleven labs. They have one I used for a character of Socrates. What describes his voice in a normal speaking tone - for narrating his experiences in Rome?

**Claude:**  
Good afternoon, Daniel!

Here's a descriptive prompt for Socrates narrating his experiences in Rome — calibrated for a natural speaking voice, not theatrical declamation:

---

**ElevenLabs Voice Description Prompt:**

> A weathered, unhurried baritone with the texture of worn limestone — neither deep nor booming, but carrying the quiet authority of a man who has never needed to raise his voice to be heard. His speech moves at a contemplative pace, with natural pauses that feel like thought arriving, not hesitation. Slight gravel in the lower registers suggests age and outdoor life, tempered by warmth and dry wit. Consonants are deliberate without being clipped; vowels open and Mediterranean in character. The overall impression is of a man who finds everything mildly fascinating and slightly amusing — a narrator who has seen much, judges little, and notices everything. No affectation, no oratory. Just the voice of a curious, aging Greek wandering Roman streets and thinking aloud.

---

A few optional add-ons depending on the tone you want:

- **For more gravitas:** *"Occasional low resonance in the chest when making a philosophical point, as if the thought itself has weight."*
- **For more warmth/humor:** *"A near-perpetual trace of a smile in the voice, as if the world is a long joke he is finally beginning to understand."*
- **For storytelling cadence:** *"Rises slightly in pitch when posing a question — which is often — then settles back into the stone-steady lower register for the answer."*

Want me to tighten this into the shorter format ElevenLabs prefers, or expand any particular quality?

**Daniel:**  
what actors fit this voice?

**Claude:**  
Great question — here are actors whose natural or performed voices land closest to that profile:

**Closest matches:**

- **Richard Harris** — that worn, warm baritone with gravel and wit. His later voice especially had the limestone quality.
- **Peter Ustinov** — deeply intelligent, dry humor always present, unhurried, Mediterranean warmth. Genuinely uncanny fit for an aging Greek narrator.
- **Anthony Hopkins** — the quiet authority and deliberate consonants, though his tends toward more intensity than Socrates would carry.
- **Ben Kingsley** — measured, contemplative, carries philosophical weight without pomposity.

**Worth considering:**

- **Derek Jacobi** — classical without being stagey, warm intelligence throughout
- **Ian McKellen** — when he pulls back from theatricality, there's real gravitas and wit underneath
- **Tom Hanks** — younger end of the spectrum, but that approachable warmth and slight amusement at everything is very Socratic in character

**The composite:**

If you blended **Peter Ustinov's wit and warmth** with **Richard Harris's gravel and weight**, you'd land almost exactly on the voice I described. Ustinov in particular — his narration work and interview voice — is probably the single closest living reference.

For ElevenLabs, you can actually name an actor as a reference anchor in the voice description. Something like:

> *"In the manner of Peter Ustinov in his later years — warm, dry, unhurried, deeply intelligent."*

Want me to rewrite the full prompt with an actor anchor built in?

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

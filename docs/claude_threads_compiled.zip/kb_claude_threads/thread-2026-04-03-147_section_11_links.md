---
thread_id: "thread-2026-04-03-147"
date: "2026-04-03"
source_uuid: "161f2454-ae56-4d85-b810-2a2b24493872"
sherpa_voice: "Claude"
category: ["Book-Work", "Principia"]
summary: "Section 11 Links"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Med (40%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["technical-focus"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Section 11 Links

## Summary
**Conversation Overview**

This conversation is a continuation of an ongoing structured project in which the person is building a comprehensive hyperlink registry for a multi-section PDF book called *Scotomaville* (specifically version 4.5.0). The person submitted Section 11 of 20 of the PDF, and Claude processed it to extract, catalog, and annotate all embedded hyperlinks. The section covers printed pages 314–365, corresponding to Monomyth 06: Camp Three / Agency (C03), and features 15 named cards identified by their PRIME numbers (197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 2

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 147 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
Here's the next section

**Claude:**  
```
This block is not supported on your current device yet.
```

Now let me cross-reference with the cards table to identify card names and suits:
```
This block is not supported on your current device yet.
```

Good — I have the card names from the registry and PDF text. Now I can build the full S11 registry entry. Let me map each card:
```
This block is not supported on your current device yet.
```

I have enough context from the PDF text itself (card names are shown on each spread). Now I can build the complete registry entry:

---

## Section 11 — Monomyth 06: Camp Three / Agency (Printed pages 314–365)

Cards featured: PRIME 197 (*Commitment Principle*, Principle, C03.testing), PRIME 199 (*Super-union Approach*, Strategy, C03.testing), PRIME 211 (*Triangulation*, Tool, C03.testing), PRIME 223 (*Checkpoint*, Tool, C03.testing), PRIME 227 (*Purpose Alignment Modeling*, Tool, C03.testing), PRIME 229 (*Self-gaming*, Strategy, C03.testing), PRIME 233 (*Impartation Principle*, Principle, C03.testing), PRIME 239 (*Self-reflection Video Modeling*, Strategy, C03.testing), PRIME 241 (*Expedition Rotations*, Strategy, C03.testing), PRIME 251 (*Rotation*, Tool, C03.testing), PRIME 257 (*Heuristic Exploration*, Strategy, C03.testing), PRIME 263 (*Call-Back*, Strategy, C03.testing), PRIME 269 (*Conversational Implicature*, Strategy, C03.testing), PRIME 271 (*Self-Reflection AI Analysis*, Strategy, C03.testing), PRIME 277 (*Predictive Adaptation*, Strategy, C03.testing)

|Printed Page|Link Type|Card PRIME|Card Name|Suit|Camp|Thread Type|URL|
|---|---|---|---|---|---|---|---|
|322|QR Code|—|Camp 03 Agency — Grok Thread (narrative/crevasse spread)|—|C03|Named Grok Thread|https://initium.scotomaville.com/C03_grok|
|322|QR Code|—|Camp 03 Agency — Grok Thread (duplicate annotation)|—|C03|Named Grok Thread|https://initium.scotomaville.com/C03_grok|
|~324|QR Code|—|Camp 03 Agency — Grok Thread (third annotation)|—|C03|Named Grok Thread|https://initium.scotomaville.com/C03_grok|
|326|QR Code|—|Camp 03 Agency.Allies — Grok Thread|—|C03|Named Grok Thread|https://initium.scotomaville.com/C03_agency|
|326|QR Code (Video)|—|Scotomaville 02.02 Process — Consciously Incompetent|—|C03|Video|https://youtu.be/5DCsRe0T9xQ|
|327|QR Code|—|Camp 03 Agency.Allies — Grok Thread (duplicate)|—|C03|Named Grok Thread|https://initium.scotomaville.com/C03_agency|
|~328|QR Code|—|Camp 03 Agency.Allies — Grok Thread (third annotation)|—|C03|Named Grok Thread|https://initium.scotomaville.com/C03_agency|
|329|QR Code|—|Inoculation Theory — Supplementary Resource|—|C03|Supplementary Resource|https://initium.scotomaville.com/inoculation_theory|
|330|QR Code (Video)|—|360MEN: WTA 12 — Death Valley (PRIME 197)|—|C03|Video|https://youtu.be/BDyDsZLNqos|
|330|QR Code|**197**|Commitment Principle|Principle|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_197|
|331|QR Code|—|Commitment Principle — Grok Thread (197_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/197_grok|
|332|QR Code (Video)|—|From Search to Ask: Intelligent Netware (PRIME 199)|—|C03|Video|https://youtu.be/QnUEJ5OHtyA|
|332|QR Code|**199**|Super-union Approach|Strategy|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_199|
|333|QR Code|—|Super-union Approach — Grok Thread (199_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/199_grok|
|334|QR Code (Video)|—|Scotomaville 01.14 Triangulation (PRIME 211)|—|C03|Video|https://youtu.be/mtmsm6LRzFM|
|334|QR Code|**211**|Triangulation|Tool|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_211|
|335|QR Code|—|Triangulation — Daniel's Cairn / Neo-Noir thread|—|C03|Supplementary Resource|https://initium.scotomaville.com/prime_211_cairn|
|336|QR Code (Video)|—|Scotomaville Reflection v1.03 Illusions (PRIME 223)|—|C03|Video|https://youtu.be/fmJrDh2LNNc|
|336|QR Code|**211**|Triangulation (second reference on Checkpoint spread)|Tool|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_211|
|337|QR Code|—|Checkpoint / Kintsugi — Grok Thread (223_kintsugi_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/223_kintsugi_grok|
|338|QR Code (Video)|—|360MEN: WTA 05 — Re View (PRIME 227)|—|C03|Video|https://youtu.be/i5DRb0Ec-Ao|
|338|QR Code|**227**|Purpose Alignment Modeling|Tool|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_227|
|~339|QR Code|—|Purpose Alignment Modeling — Grok Thread (227_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/227_grok|
|340|QR Code (Video)|—|AI Self Mastery V4.00.03 Initium — Self-gaming video (PRIME 229)|—|C03|Video|https://youtu.be/G6Wu3TfWPvM|
|340|QR Code|**229**|Self-gaming|Strategy|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_229|
|341|QR Code|—|Self-gaming — Grok Thread (229_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/229_grok|
|342|QR Code (Video)|—|360MEN: Peloton/Podium (PRIME 233)|—|C03|Video|https://youtu.be/kgjp9RPmIwA|
|342|QR Code|**233**|Impartation Principle|Principle|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_233|
|343|QR Code|—|Impartation Principle — Grok Thread (233_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/233_grok|
|344|QR Code (Video)|—|Wellness by Choice: Angelina Show Pilot (PRIME 239)|—|C03|Video|https://youtu.be/RWED6Am0SUM|
|344|QR Code|**239**|Self-reflection Video Modeling|Strategy|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_239|
|345|QR Code|—|Self-reflection Video Modeling — Grok Thread (239_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/239_grok|
|346|QR Code (Video)|—|Scotomaville v3 Participant Invitation (PRIME 241)|—|C03|Video|https://youtu.be/EVItZKtwvQU|
|346|QR Code|**241**|Expedition Rotations|Strategy|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_241|
|347|QR Code|—|Expedition Rotations — Grok Thread (241_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/241_grok|
|347|QR Code|—|Expedition Rotations — Grok Thread (241_grok duplicate)|—|C03|Grok Conversation|https://initium.scotomaville.com/241_grok|
|348|QR Code|—|Maps of Meaning — Lecture One (Peterson Academy)|—|C03|External|https://initium.scotomaville.com/prime_251_pa|
|348|QR Code|**251**|Rotation|Tool|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_251|
|348|QR Code|—|Rotation — Professor Prompt bonus link|—|C03|Supplementary Resource|https://initium.scotomaville.com/251_bonus|
|348|QR Code|—|Rotation — Professor Prompt bonus link (duplicate)|—|C03|Supplementary Resource|https://initium.scotomaville.com/251_bonus|
|349|QR Code|—|Maps of Meaning / Peterson Academy (duplicate)|—|C03|External|https://initium.scotomaville.com/prime_251_pa|
|349|QR Code|—|Maps of Meaning / Peterson Academy (third)|—|C03|External|https://initium.scotomaville.com/prime_251_pa|
|349|QR Code|—|Rotation — Professor Prompt bonus (duplicate)|—|C03|Supplementary Resource|https://initium.scotomaville.com/251_bonus|
|349|QR Code|—|Rotation — Professor Prompt bonus (duplicate)|—|C03|Supplementary Resource|https://initium.scotomaville.com/251_bonus|
|350|QR Code (Video)|—|Scotomaville Base Camp Mesa Summit (PRIME 257)|—|C03|Video|https://youtu.be/MfN6Y7grAeY|
|350|QR Code|**251**|Rotation (cross-reference on 257 spread)|Tool|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_251|
|~351|QR Code|—|Heuristic Exploration — Grok Thread (prime_257_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/prime_257_grok|
|~351|QR Code|—|Heuristic Exploration — Grok Thread (duplicate)|—|C03|Grok Conversation|https://initium.scotomaville.com/prime_257_grok|
|352|QR Code (Video)|—|WellX Events AI Self Mastery Promo — Robin Williams (PRIME 263)|—|C03|Video|https://youtu.be/vghvN94enaw|
|352|QR Code|**263**|Call-Back|Strategy|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_263|
|353|QR Code|—|Call-Back — Grok Thread (263_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/263_grok|
|353|QR Code|—|Call-Back — Grok Thread (263_grok duplicate)|—|C03|Grok Conversation|https://initium.scotomaville.com/263_grok|
|353|Link|—|Tohu wa-bohu — Grokipedia reference|—|C03|External|https://grokipedia.com/page/Tohu_wa-bohu|
|354|QR Code (Video)|—|Scotoma Card Demo — Initium Scotoma card (youtu.be/G6Wu3TfWPvM)|—|C03|Video|https://youtu.be/G6Wu3TfWPvM|
|354|QR Code|—|Download the Initium Card (scotomaville.com PDF)|—|C03|Resource|https://scotomaville.com/downloads/Scotomaville_Initium.pdf|
|354|QR Code (Video)|—|Scotoma Card Demo (duplicate annotation)|—|C03|Video|https://youtu.be/G6Wu3TfWPvM|
|354|QR Code|—|Download the Initium Card (duplicate)|—|C03|Resource|https://scotomaville.com/downloads/Scotomaville_Initium.pdf|
|356|QR Code (Video)|—|Scotomaville Bricolage Invitation (PRIME 269)|—|C03|Video|https://youtu.be/SRz4zpFZbW4|
|356|QR Code|**269**|Conversational Implicature|Strategy|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_269|
|357|QR Code|—|Conversational Implicature — Grok Thread (269_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/269_grok|
|357|QR Code|—|Conversational Implicature — Grok Thread (duplicate)|—|C03|Grok Conversation|https://initium.scotomaville.com/269_grok|
|358|QR Code (Video)|—|Feel Alone in the World? — Self-Reflection video (PRIME 271)|—|C03|Video|https://youtu.be/yFbghrqxY5A|
|358|QR Code|**271**|Self-Reflection AI Analysis|Strategy|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_271|
|359|QR Code|—|Self-Reflection AI Analysis — Grok Thread (271_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/271_grok|
|359|QR Code|—|Self-Reflection AI Analysis — Grok Thread (duplicate)|—|C03|Grok Conversation|https://initium.scotomaville.com/271_grok|
|361|QR Code|—|Scotomaville GPT / Curator GPT|—|C03|External|https://scotomaville.com/scotomaville-gpt|
|361|QR Code|—|Scotomaville GPT (duplicate)|—|C03|External|https://scotomaville.com/scotomaville-gpt|
|364|QR Code (Video)|—|360MEN: A Procrastinated Invitation (PRIME 277)|—|C03|Video|https://youtu.be/rofFofFa60M|
|364|QR Code|**277**|Predictive Adaptation|Strategy|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_277|
|365|QR Code (Video)|—|Scotomaville v3.04 Measuring Progress (PRIME 277 Daniel's Cairn)|—|C03|Video|https://youtu.be/---PjRytqKQ|
|365|QR Code|—|Predictive Adaptation — Grok Thread (277_grok)|—|C03|Grok Conversation|https://initium.scotomaville.com/277_grok|
|365|QR Code|—|Predictive Adaptation — Grok Thread (duplicate)|—|C03|Grok Conversation|https://initium.scotomaville.com/277_grok|

**Pattern notes for Section 11:** S11 introduces a significant structural evolution from prior sections — each card spread now carries **three** links instead of two: a YouTube video, a `prime_NNN` reader thread, and a new `NNN_grok` Sherpa conversation thread. This is the first section where `NNN_grok` slugs are systematically embedded as hyperlinks (not image-only QRs), establishing the three-link pattern that likely continues through S12–S18.

Several new slug patterns emerge: `C03_grok` and `C03_agency` are named chapter-level Grok threads (not card-specific), linked from the Camp 3 introductory and Allies spreads. `inoculation_theory` is a new supplementary resource slug. `prime_211_cairn` is a new variant — a named supplementary thread for Triangulation's Daniel's Cairn. `223_kintsugi_grok` uses a named descriptive slug rather than bare `NNN_grok`. `prime_251_pa` links to a Peterson Academy resource. `251_bonus` links to a Professor Prompt bonus resource.

PRIME 257 (*Heuristic Exploration*) uses the slug `prime_257_grok` for its Grok thread rather than the expected `257_grok` — the only card in this section where the `prime_` prefix appears in the Grok thread slug. No `prime_257` reader thread was extracted — it may be image-only or absent; the p.350 annotation linking `prime_251` appears to be a cross-reference for Rotation on the Heuristic Exploration spread.

PRIME 223 (*Checkpoint*) has no standalone `prime_223` reader thread extracted — its reader thread may be image-only; the extracted link is `223_kintsugi_grok` (Grok thread) and `prime_211` appears twice (on the Triangulation spread and again on the Checkpoint spread as a cross-reference). This warrants physical verification.

The Curator GPT / Scotomaville GPT page (p.361) is a narrative/meta spread without a card PRIME — it carries external links to `scotomaville.com/scotomaville-gpt` only.

---

**Updated Coverage Summary row:**

| Section | Printed Pages | Links Found | initium.scotomaville.com | Grok Shares | YouTube | Scan Required |
|---|---|---|---|---|---|---|
| S11 | 314–365 | 72 | 43 | 0 | 13 | 0 |

**Updated totals (adding S11):**

| **Total** | | **248** | **117** | **12** | **55** | **18** |

---

**New confirmed slugs from S11:**

*Reader practice threads (`prime_NNN`):*
prime_197, prime_199, prime_211, prime_227, prime_229, prime_233, prime_239, prime_241, prime_251, prime_263, prime_269, prime_271, prime_277

*Grok conversation threads (`NNN_grok`):*
197_grok, 199_grok, 223_kintsugi_grok, 227_grok, 229_grok, 233_grok, 239_grok, 241_grok, 263_grok, 269_grok, 271_grok, 277_grok, prime_257_grok *(anomalous prefix)*

*Named chapter Grok threads:*
C03_grok, C03_agency

*Supplementary resource slugs:*
inoculation_theory, prime_211_cairn, prime_251_pa, 251_bonus

*Note:* `prime_223` (Checkpoint reader thread) and `prime_257` (Heuristic Exploration reader thread) were **not extracted** — treat as 🔲 pending physical verification. Both cards' Grok threads were captured.

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

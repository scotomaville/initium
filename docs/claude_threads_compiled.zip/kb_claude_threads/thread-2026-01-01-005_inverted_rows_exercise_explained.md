---
thread_id: "thread-2026-01-01-005"
date: "2026-01-01"
source_uuid: "77efce91-3459-445c-9df3-7585219986a1"
sherpa_voice: "Claude"
category: ["Ordinary-World", "Body-Vessel"]
summary: "Inverted rows exercise explained"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Low-Med (20%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["inquiry"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Inverted rows exercise explained

## Summary
[ to be written ]

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 5 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
I’m on page “<tabTitle>2026 - New Year Longevity Planning - Grok</tabTitle>” with “<selection>Inverted rows</selection>” selected.

Please explain the key concepts in this selection, using simple words. Also, use examples.

**Claude:**  
# Inverted Rows - Simple Explanation

**Inverted rows** are a bodyweight exercise where you pull yourself up while your body is positioned horizontally under a bar or table.

## How It Works

Imagine lying on your back and sliding under a sturdy table. You grab the edge of the table, keep your body straight like a plank, and pull your chest up toward the table. That's essentially an inverted row!

## Key Concepts

**1. Horizontal Pulling Motion**
- Unlike pull-ups (vertical pulling), you're pulling horizontally
- Similar to a reverse push-up
- Works the muscles in your back, especially between your shoulder blades

**2. Bodyweight Resistance**
- You use your own body weight as resistance
- The more horizontal your body, the harder it is
- Beginners can make it easier by standing more upright

## Real-World Examples

**Easy version:** Stand almost upright and pull yourself toward a waist-high bar (like doing a standing row)

**Medium version:** Set a bar at knee height, feet on the ground, body at a 45-degree angle

**Hard version:** Feet elevated on a bench, body completely horizontal, pulling up to a low bar

## Why They're Useful

- **Safe for beginners:** Easier than pull-ups but builds the same muscles
- **Good for balance:** Counteracts all the pushing motions we do (like push-ups or pressing movements)
- **Everyday strength:** Helps with pulling open heavy doors, starting lawnmowers, or rowing activities

Think of it as the "opposite of a push-up" - strengthening your back instead of your chest!

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

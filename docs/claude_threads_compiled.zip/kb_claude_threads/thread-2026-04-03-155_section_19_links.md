---
thread_id: "thread-2026-04-03-155"
date: "2026-04-03"
source_uuid: "ba1295f3-1213-4bcc-9687-6ebe9f106d03"
sherpa_voice: "Claude"
category: ["Book-Work", "Principia"]
summary: "Section 19 links"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Med (40%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["technical-focus"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Section 19 links

## Summary
[ to be written ]

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 155 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
Section 19 Links

**Claude:**  
I'll run the PyMuPDF extraction script on the uploaded S19 PDF to get the confirmed links.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Now I have everything I need. Let me also check what p10 (printed ~513) contains — there's no page number visible so let me verify, and note that `541_grok` appears twice (no `541_grok_syn`).
```
This block is not supported on your current device yet.
```

Good — p20 has two `541_grok` links at different rects (one in the QR area at top, one in the AI logo row at bottom-left). No `541_grok_syn` for card 541. Now let me look up both cards in the project knowledge.
```
This block is not supported on your current device yet.
```

The extraction is complete and confirms this section aligns with the existing registry. The project knowledge already has a fully accurate S19 entry. Here's a clean summary of what was confirmed from the PDF:

---

## Section 19 Extraction Results — Confirmed ✅

**18 links total | 10 initium.scotomaville.com | 2 Grok shares | 1 YouTube (×2 annotations) | 0 scan required**

| Printed Page | Link Type | Card PRIME | Card Name | Suit | Camp | Thread Type | URL |
|---|---|---|---|---|---|---|---|
| 512 | QR Code (Video) | — | Rotation 11 / Thoughtfulness Thread Video | — | C10 | Video | https://youtu.be/q_ScWpEU054 |
| 512 | AI Logo (Grok) | — | Rotation 11 Grok Thread | — | C10 | Grok Conversation | https://grok.com/share/bGVnYWN5_153c5c48-a198-4a6e-ac64-31f67abda086 |
| 513 | AI Logo (Grok) | — | Rotation 11 Grok Thread (continued) | — | C10 | Grok Conversation | https://grok.com/share/bGVnYWN5_caa2c9fb-166e-44cd-bf75-ef45efdae5ab |
| 520 | QR Code | **523** | First Tracks Reversal | Wildcard | C10 | Reader Practice Thread | https://initium.scotomaville.com/prime_523 |
| 521 | AI Logo (Grok) | **523** | First Tracks Reversal | Wildcard | C10 | Grok Thread | https://initium.scotomaville.com/523_grok |
| 521 | AI Logo (Gemini) | **523** | First Tracks Reversal | Wildcard | C10 | Gemini Thread | https://initium.scotomaville.com/523_gemini |
| 521 | AI Logo (Perplexity) | **523** | First Tracks Reversal | Wildcard | C10 | Perplexity Thread | https://initium.scotomaville.com/523_perplexity |
| 521 | AI Logo (ChatGPT) | **523** | First Tracks Reversal | Wildcard | C10 | ChatGPT Thread | https://initium.scotomaville.com/523_chatgpt |
| 521 | AI Logo (Claude) | **523** | First Tracks Reversal | Wildcard | C10 | Claude Thread | https://initium.scotomaville.com/523_claude |
| 521 | AI Logo (Grok Syn) | **523** | First Tracks Reversal | Wildcard | C10 | Grok Synthesis Thread | https://initium.scotomaville.com/523_grok_syn |
| 522 | QR Code | **541** | Maximally Curious AI | Wildcard | C10 | Reader Practice Thread | https://initium.scotomaville.com/prime_541 |
| 523 | AI Logo (Grok) | **541** | Maximally Curious AI | Wildcard | C10 | Grok Thread | https://initium.scotomaville.com/541_grok |
| 523 | AI Logo (Gemini) | **541** | Maximally Curious AI | Wildcard | C10 | Gemini Thread | https://initium.scotomaville.com/541_gemini |
| 523 | AI Logo (Perplexity) | **541** | Maximally Curious AI | Wildcard | C10 | Perplexity Thread | https://initium.scotomaville.com/541_perplexity |
| 523 | AI Logo (ChatGPT) | **541** | Maximally Curious AI | Wildcard | C10 | ChatGPT Thread | https://initium.scotomaville.com/541_chatgpt |
| 523 | AI Logo (Claude) | **541** | Maximally Curious AI | Wildcard | C10 | Claude Thread | https://initium.scotomaville.com/541_claude |

**Two anomalies noted:**

1. **YouTube on p512 has two annotation objects** — same URL `https://youtu.be/q_ScWpEU054` appears twice (likely the QR image plus a text hyperlink). Listed as one link.
2. **Card 541 has no `grok_syn` slug** — p523 has two `541_grok` annotations at different rects (one is the Daniel's Cairn QR at top, one is the Grok logo in the AI row). No `541_grok_syn` exists for this card, unlike card 523 which has all six AI threads including the synthesis variant.

The registry in project knowledge is already fully accurate for S19 — this extraction confirms it completely. Ready to proceed with any remaining sections (S11–S18, S20) whenever you upload them.

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

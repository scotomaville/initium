---
thread_id: "thread-2026-04-03-146"
date: "2026-04-03"
source_uuid: "c3eac5f8-e1fb-4c23-9804-d6ec5e5c7073"
sherpa_voice: "Claude"
category: ["Book-Work", "Principia"]
summary: "Section 10 Links"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Med (40%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["clarity", "technical-focus"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Section 10 Links

## Summary
**Conversation Overview**

The person is working on a systematic extraction and documentation project for the Scotomaville v4.5.0 book, mapping every embedded hyperlink (QR code, AI logo, and inline URL) across 20 PDF sections into a structured link registry. The project uses PyMuPDF to extract hyperlinks from PDFs and cross-references results against a master cards file (`Initium_Cards_4_Suits.md`) to identify card names, suits, and monomyth stages. The registry tracks URLs resolving to `initium.scotomaville.com` slugs, Grok share links, and YouTube videos.

In this session, Claude extracted 

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 146 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
Here's the next section:

**Claude:**  
```
This block is not supported on your current device yet.
```

Good haul — 60 links, many of them new slug patterns. Let me now cross-reference against the cards master file and build the full registry table.
```
This block is not supported on your current device yet.
```

Now I have everything I need. Let me compile the full S10 registry.
```
This block is not supported on your current device yet.
```

I have everything needed. Here's the full Section 10 extraction report:

---

## Section 10 Extraction Complete

**Section:** S10 (Camp 2 — WIDWID / Crevasse)
**Printed Pages:** 262–313 (physical pp. 1–52)
**Total Links Found:** 60 ✅

---

### New Confirmed Slugs

Several slug patterns appear here for the first time:

| Slug | URL | Confidence | Notes |
|------|-----|-----------|-------|
| `prime_137` | `https://initium.scotomaville.com/prime_137` | ✅ Confirmed | Card 137 — Diffuse Mode (S, Camp 2) |
| `prime_139` | `https://initium.scotomaville.com/prime_139` | ✅ Confirmed | Card 139 — Onion Peeling (S, Camp 2) |
| `prime_149` | `https://initium.scotomaville.com/prime_149` | ✅ Confirmed | Card 149 — Intention Scoring (T, Camp 2) |
| `prime_151` | `https://initium.scotomaville.com/prime_151` | ✅ Confirmed | Card 151 — Echo Dampener (T, Camp 2) |
| `prime_157` | `https://initium.scotomaville.com/prime_157` | ✅ Confirmed | Card 157 — WIDWID (S, Camp 2) |
| `prime_167` | `https://initium.scotomaville.com/prime_167` | ✅ Confirmed | Card 167 — Storytelling Superpower (S, Camp 2) |
| `prime_173` | `https://initium.scotomaville.com/prime_173` | ✅ Confirmed | Card 173 — Providential (P, Camp 2) |
| `prime_179` | `https://initium.scotomaville.com/prime_179` | ✅ Confirmed | Card 179 — Reframing (S, Camp 2) |
| `prime_181` | `https://initium.scotomaville.com/prime_181` | ✅ Confirmed | Card 181 — Personal Everest (S, Camp 2) |
| `prime_191` | `https://initium.scotomaville.com/prime_191` | ✅ Confirmed | Card 191 — Incremental Change Thinking (S, Camp 2) |
| `prime_193` | `https://initium.scotomaville.com/prime_193` | ✅ Confirmed | Card 193 — Providence Tracking (T, Camp 2) |

---

### New Non-`prime_NNN` Slugs (novel patterns)

| Slug | URL | Confidence | Context |
|------|-----|-----------|---------|
| `I_know_nothing` | `https://initium.scotomaville.com/I_know_nothing` | ✅ Confirmed | p285 — alongside prime_139 (Onion Peeling); appears to be a thematic/supplementary link, not a standard AI thread |
| `echo_dampening` | `https://initium.scotomaville.com/echo_dampening` | ✅ Confirmed | p288 — Card 151, Daniel-Grok thread QR |
| `echo_dampening_grok` | `https://initium.scotomaville.com/echo_dampening_grok` | ✅ Confirmed | p289 — second QR on Echo Dampener reverse side |
| `widwid_thread` | `https://initium.scotomaville.com/widwid_thread` | ✅ Confirmed | p290 — Card 157 Daniel-Grok thread |
| `ai_minyan_grok` | `https://initium.scotomaville.com/ai_minyan_grok` | ✅ Confirmed | p292 — Card 163 (AI Minyan); note: no `prime_163` slug appeared |
| `prime_173_domains` | `https://initium.scotomaville.com/prime_173_domains` | ✅ Confirmed | p305 — supplement to Card 173 (Providential) |
| `179_reframing_grok` | `https://initium.scotomaville.com/179_reframing_grok` | ✅ Confirmed | p307 — Card 179 Grok thread |
| `incremental_joules` | `https://initium.scotomaville.com/incremental_joules` | ✅ Confirmed | p311 — Card 191 energy chart supplement |
| `hierarchical_computation_grok` | `https://initium.scotomaville.com/hierarchical_computation_grok` | ✅ Confirmed | p313 — Providence Tracking page, Grok thread |
| `providence_tracking_grok` | `https://initium.scotomaville.com/providence_tracking_grok` | ✅ Confirmed | p313 — Card 193 Grok thread |

---

### External Grok Share Links

| URL | Printed Page | Context |
|-----|-------------|---------|
| `https://grok.com/share/bGVnYWN5_3224dfdb-0c3d-4f64-9470-32bbea226f7a` | 287 | Card 149 (Intention Scoring) — Grok share thread |
| `https://grok.com/share/bGVnYWN5_9f0ee787-6e3d-47c7-abf9-080bf7eddd7c` | 313 | Providence Tracking — Grok share thread |
| `https://grok.com/share/bGVnYWN5_9cb76228-6b49-49b1-a49b-66ad407f3af3` | 313 | Providence Tracking — second Grok share thread |

---

### YouTube Links (all 🔲 click-to-confirm per protocol)

| Printed Page | URL | Context |
|-------------|-----|---------|
| 271 | `https://youtu.be/SOLmCOoyX-0` | v3.09 Resurrection callback (appears twice + once as `LOHlv4vHsAc`) |
| 271 | `https://youtu.be/LOHlv4vHsAc` | Same spread — second video |
| 272 | `https://youtu.be/0yiZ-kDhKuQ` | Resurrection episode (appears multiple times with timestamps) |
| 274 | `https://youtu.be/F85kstgu5EA` | "Knowing WHY" video (appears with timestamp variant `&t=327`) |
| 276–278 | `https://youtu.be/0yiZ-kDhKuQ` (×6 with timestamps) | Minyan character segments (Socrates, Benjamin, Viktor, Moses, Carl, Paul/Arnie) |
| 282 | `https://youtu.be/tq5SLeJctrE` | Diffuse Mode supplementary |
| 282 | `https://youtu.be/tLlsrQMYic8` | Diffuse Mode (Life-Long Learning) |
| 284 | `https://youtu.be/-eg7-P25BU8` | Onion Peeling |
| 285 | `https://youtu.be/a57QkpvF6Lk` | Onion Peeling cairn (YouTube embed) |
| 302 | `https://youtu.be/T1wyII-03Co` | Hieroglyphics "Watch" video |
| 303 | `https://youtu.be/EB3lcIINuic` | Hieroglyphics "Reflect" video |
| 304 | `https://youtu.be/BFKHp5srevQ` | Providential card video |
| 306 | `https://youtu.be/8W-csS3rmm8` | Reframing card |
| 308 | `https://youtu.be/a57QkpvF6Lk` | Personal Everest (same YT as p285) |
| 310 | `https://youtu.be/McOj8DjB3MA` | Incremental Change Thinking |
| 293 | `https://youtu.be/dseI7lGvGWw` | AI Minyan cairn (Scotomaville v3 final episode) |
| 294 | `https://youtu.be/FiRqOUm7BaM` | Storytelling Superpower |

---

### Pattern Observations Worth Adding to Your Registry

**Novel slug conventions spotted in S10:**

1. **Named-thread slugs** — `echo_dampening`, `widwid_thread`, `ai_minyan_grok`, `179_reframing_grok`, `providence_tracking_grok`, `hierarchical_computation_grok` — these appear to be Grok conversation threads that don't follow the `NNN_grok` numeric pattern. They use descriptive names instead of PRIME numbers. Watch for this in other sections.

2. **Supplementary content slugs** — `I_know_nothing`, `prime_173_domains`, `incremental_joules` — these link to extended content (a Socrates video, the possible/probable/providential domains explainer, the Joules energy chart). Not AI threads; more like bonus resources.

3. **`prime_163` is absent** — Card 163 (AI Minyan) has `ai_minyan_grok` on p292 and a second `prime_157` QR on p292 instead. Either the `prime_163` slug was omitted intentionally or it lives on a page not yet extracted. Flag for verification.

---

### Updated Completed Sections Table

| Section | Printed Pages | Links Found | Notes |
|---------|--------------|-------------|-------|
| S00 | 1–23 | 6 | Downloads, GitHub, CC license, website |
| S01 | 24–55 | 4 | 2 videos, 1 Grok share (p41), aiselfmastery.com |
| S02 | ~56–98 | 0 | Image-only QRs suspected |
| S10 | 262–313 | 60 | 11 `prime_NNN` cards + 10 novel slugs + 3 Grok shares + 17 YouTube |
| S19 | 504–523 | 16 | Cards 523 + 541 fully decoded |

Sections 03–09, 11–18, and 20 remain.

**Daniel:**  
I need you to match the previous layout. Sorry for the omission.

**Claude:**  
```
This block is not supported on your current device yet.
```

Now I have the exact format. I'll add Section 10 in proper style and update the Coverage Summary and slug lists.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Now insert the Section 10 block before Section 19:
```
This block is not supported on your current device yet.
```

**Daniel:**  
I need you to match the previous layout. Sorry for the omission. You can simply reformat your response. I'll paste it into the file I have locally

**Claude:**  
Got it — here is Section 10 formatted to match the existing registry layout exactly, ready to paste in before Section 19.

---

## Section 10 — Monomyth 05: Camp 2 / WIDWID — Crevasse (Printed pages 262–313)

Cards featured: PRIME 137 (_Diffuse Mode_, Strategy, C02.crevasse), PRIME 139 (_Onion Peeling_, Strategy, C02.crevasse), PRIME 149 (_Intention Scoring_, Tool, C02.crevasse), PRIME 151 (_Echo Dampener_, Tool, C02.crevasse), PRIME 157 (_WIDWID_, Strategy, C02.crevasse), PRIME 163 (_AI Minyan_, Tool, C02.crevasse), PRIME 167 (_Storytelling Superpower_, Strategy, C02.crevasse), PRIME 173 (_Providential_, Principle, C02.crevasse), PRIME 179 (_Reframing_, Strategy, C02.crevasse), PRIME 181 (_Personal Everest_, Strategy, C02.crevasse), PRIME 191 (_Incremental Change Thinking_, Strategy, C02.crevasse), PRIME 193 (_Providence Tracking_, Tool, C02.crevasse)

|Printed Page|Link Type|Card PRIME|Card Name|Suit|Camp|Thread Type|URL|
|---|---|---|---|---|---|---|---|
|271|QR Code (Video)|—|Scotomaville v3.09 Resurrection Callback (first)|—|C02|Video|https://youtu.be/SOLmCOoyX-0|
|271|QR Code (Video)|—|Scotomaville v3.09 Resurrection Callback (second)|—|C02|Video|https://youtu.be/LOHlv4vHsAc|
|272|QR Code (Video)|—|Leaving Scotomaville: Resurrection Episode|—|C02|Video|https://youtu.be/0yiZ-kDhKuQ|
|274|QR Code (Video)|—|Knowing WHY — Scotomaville v3.01|—|C02|Video|https://youtu.be/F85kstgu5EA|
|275|QR Code (Video)|—|Knowing WHY — Viktor Frankl segment (t=327)|—|C02|Video|https://youtu.be/F85kstgu5EA&t=327|
|276|QR Code (Video)|—|Resurrection Episode — Socrates segment (t=931)|—|C02|Video|https://youtu.be/0yiZ-kDhKuQ&t=931|
|276|QR Code (Video)|—|Resurrection Episode — Benjamin segment (t=1476)|—|C02|Video|https://youtu.be/0yiZ-kDhKuQ&t=1476|
|276|QR Code (Video)|—|Resurrection Episode — Viktor segment (t=1251)|—|C02|Video|https://youtu.be/0yiZ-kDhKuQ&t=1251|
|277|QR Code (Video)|—|Resurrection Episode — Moses segment (t=173)|—|C02|Video|https://youtu.be/0yiZ-kDhKuQ&t=173|
|278|QR Code (Video)|—|Resurrection Episode — Carl segment (t=789)|—|C02|Video|https://youtu.be/0yiZ-kDhKuQ&t=789|
|279|QR Code (Video)|—|Resurrection Episode — Paul/Arnie segment (t=1307)|—|C02|Video|https://youtu.be/0yiZ-kDhKuQ&t=1307|
|279|QR Code (Video)|—|Resurrection Episode — Paul/Arnie segment (t=1336)|—|C02|Video|https://youtu.be/0yiZ-kDhKuQ&t=1336|
|280|QR Code|—|Camp 02 Consciously Incompetent — reader thread (pre-card spread)|—|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_137|
|282|QR Code|**137**|Diffuse Mode|Strategy|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_137|
|282|QR Code (Video)|—|Diffuse Mode — Life-Long Learning / Cycling|—|C02|Video|https://youtu.be/tq5SLeJctrE|
|282|QR Code (Video)|—|Diffuse Mode — Sherpa Grok Prompt|—|C02|Video|https://youtu.be/tLlsrQMYic8|
|284|QR Code (Video)|—|Onion Peeling — SV Reflection v1.07|—|C02|Video|https://youtu.be/-eg7-P25BU8|
|284|QR Code|**139**|Onion Peeling|Strategy|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_139|
|285|QR Code (Video)|—|Onion Peeling — Daniel's Cairn / pit-digging|—|C02|Video|https://youtu.be/a57QkpvF6Lk|
|285|QR Code|—|Onion Peeling — Supplementary ("I Know Nothing")|—|C02|Supplementary Resource|https://initium.scotomaville.com/I_know_nothing|
|286|QR Code|**149**|Intention Scoring|Tool|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_149|
|287|Link (Grok Share)|—|Intention Scoring — Daniel-Grok Shared Thread|—|C02|Grok Conversation|https://grok.com/share/bGVnYWN5_3224dfdb-0c3d-4f64-9470-32bbea226f7a|
|288|QR Code|**151**|Echo Dampener|Tool|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_151|
|288|QR Code|—|Echo Dampener — Daniel-Grok Thread (front side)|—|C02|Named Grok Thread|https://initium.scotomaville.com/echo_dampening|
|289|QR Code|—|Echo Dampener — Daniel-Grok Thread (reverse side)|—|C02|Named Grok Thread|https://initium.scotomaville.com/echo_dampening_grok|
|290|QR Code|—|WIDWID — Daniel-Grok Thread|—|C02|Named Grok Thread|https://initium.scotomaville.com/widwid_thread|
|290|QR Code|**157**|WIDWID|Strategy|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_157|
|292|QR Code|**157**|WIDWID (second annotation on AI Minyan spread)|Strategy|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_157|
|292|QR Code|—|AI Minyan — Daniel-Grok Thread|—|C02|Named Grok Thread|https://initium.scotomaville.com/ai_minyan_grok|
|293|QR Code (Video)|—|AI Minyan — Daniel's Cairn / Scotomaville v3 final episode|—|C02|Video|https://youtu.be/dseI7lGvGWw|
|294|QR Code|**167**|Storytelling Superpower|Strategy|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_167|
|294|QR Code (Video)|—|Storytelling Superpower — Moses and the Call from AI|—|C02|Video|https://youtu.be/FiRqOUm7BaM|
|302|QR Code (Video)|—|Hieroglyphics — "Watch" video|—|C02|Video|https://youtu.be/T1wyII-03Co|
|303|QR Code (Video)|—|Hieroglyphics — "Reflect" video|—|C02|Video|https://youtu.be/EB3lcIINuic|
|304|QR Code (Video)|—|Providential — Scotomaville V2 Prelude video|—|C02|Video|https://youtu.be/BFKHp5srevQ|
|304|QR Code|**173**|Providential|Principle|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_173|
|305|QR Code|—|Providential — Domains supplement (Possible/Probable/Providential)|—|C02|Supplementary Resource|https://initium.scotomaville.com/prime_173_domains|
|306|QR Code|**179**|Reframing|Strategy|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_179|
|306|QR Code (Video)|—|Reframing — AISM v4.00.01 Irony of Literacy|—|C02|Video|https://youtu.be/8W-csS3rmm8|
|307|QR Code|—|Reframing — Daniel-Grok Thread|—|C02|Named Grok Thread|https://initium.scotomaville.com/179_reframing_grok|
|308|QR Code (Video)|—|Personal Everest — Escaping a Sh*t Hole video|—|C02|Video|https://youtu.be/a57QkpvF6Lk|
|308|QR Code|**181**|Personal Everest|Strategy|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_181|
|310|QR Code|**191**|Incremental Change Thinking|Strategy|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_191|
|310|QR Code (Video)|—|Incremental Change Thinking — 360MEN "Curves Ahead"|—|C02|Video|https://youtu.be/McOj8DjB3MA|
|311|QR Code|—|Incremental Change Thinking — Joules energy chart|—|C02|Supplementary Resource|https://initium.scotomaville.com/incremental_joules|
|312|QR Code|**193**|Providence Tracking|Tool|C02|Reader Practice Thread|https://initium.scotomaville.com/prime_193|
|313|Link (Grok Share)|—|Providence Tracking — Daniel-Grok Shared Thread (first)|—|C02|Grok Conversation|https://grok.com/share/bGVnYWN5_9f0ee787-6e3d-47c7-abf9-080bf7eddd7c|
|313|QR Code|—|Hierarchical Computation — Named Grok Thread|—|C02|Named Grok Thread|https://initium.scotomaville.com/hierarchical_computation_grok|
|313|QR Code|—|Providence Tracking — Named Grok Thread|—|C02|Named Grok Thread|https://initium.scotomaville.com/providence_tracking_grok|
|313|Link (Grok Share)|—|Providence Tracking — Daniel-Grok Shared Thread (second)|—|C02|Grok Conversation|https://grok.com/share/bGVnYWN5_9cb76228-6b49-49b1-a49b-66ad407f3af3|

**Pattern notes for Section 10:** This is the densest section yet — 60 links across 52 physical pages. Several new slug conventions appear for the first time. (1) **Named Grok threads** (`echo_dampening`, `widwid_thread`, `ai_minyan_grok`, `179_reframing_grok`, `providence_tracking_grok`, `hierarchical_computation_grok`) use descriptive names rather than PRIME numbers; these appear alongside the standard `prime_NNN` QR on the same or adjacent card spread. (2) **Named supplementary slugs** (`I_know_nothing`, `prime_173_domains`, `incremental_joules`) link to bonus content (a Socrates video, the Possible/Probable/Providential explainer, the Joules energy comparison chart) rather than AI conversation threads. (3) **`prime_137` appears twice** — once on p280 as a pre-card-spread "Consciously Incompetent" reader thread and again on p282 as the card's own reader thread; both resolve to the same URL. (4) **`prime_157` appears twice** — once on p290 (WIDWID card spread) and once on p292 (AI Minyan spread), the second apparently a cross-reference. (5) **Card 163 (AI Minyan) has no `prime_163` slug** in this section — its reader thread may be absent, deferred, or embedded in `ai_minyan_grok`. Flag for verification against a physical copy. (6) The **Resurrection Callback** (pp. 271–279) carries 12 video links — timestamped segments of the same YouTube video for each Minyan character — a pattern not seen in earlier sections.

---

And here are the two rows to **add to the Coverage Summary table** and the slug lists to **update at the bottom**:

**Coverage Summary — row to add:**

|S10|262–313|05 Crossing the First Threshold / Camp 2|60|18|3|17|0|

**Updated totals row:**

|**Total**|||**160**|**55**|**10**|**38**|**18**|

---

**Confirmed `prime_NNN` slugs to add to the slug inventory:**

prime_137, prime_139, prime_149, prime_151, prime_157, prime_167, prime_173, prime_179, prime_181, prime_191, prime_193

**New named slugs to add (new pattern category):**

`echo_dampening`, `echo_dampening_grok`, `widwid_thread`, `ai_minyan_grok`, `179_reframing_grok`, `providence_tracking_grok`, `hierarchical_computation_grok`, `I_know_nothing`, `prime_173_domains`, `incremental_joules`

**Daniel:**  
We need to fix the instructions for this project to include the proper table and document format. Please rewrite the entire file.

**Claude:**  
```
This block is not supported on your current device yet.
```

Good — I have the full picture now. Here is the complete rewritten instructions file:

---

# Initium Link Registry — Rules & Methods Seed File

_For use at the start of each new extraction session_

---

## 1. Confirmed URL Patterns

| Slug | Meaning | Confidence |
|---|---|---|
| `prime_NNN` | Reader practice thread for card PRIME=NNN | ✅ Confirmed |
| `NNN_grok` | Grok's conversation thread on card NNN | ✅ Confirmed |
| `NNN_gemini` | Gemini's thread on card NNN | ✅ Confirmed |
| `NNN_chatgpt` | ChatGPT's thread on card NNN | ✅ Confirmed |
| `NNN_claude` | Claude's thread on card NNN | ✅ Confirmed |
| `NNN_perplexity` | Perplexity's thread on card NNN | ✅ Confirmed |
| `NNN_grok_syn` | Grok synthesis/second thread on card NNN | ✅ Confirmed (S19 p521) |
| `initium_principia_gnosis_book` | Book download | ✅ Confirmed |
| `initium_principia_gnosis_cards` | Cards download | ✅ Confirmed |
| `how_to_play_initium` | How-to-play guide | ✅ Confirmed |
| `[name]_grok` | Named Grok thread using descriptive slug (not PRIME-numbered) — first confirmed in S08 (`inferential_grok`) and S10 (`echo_dampening_grok`, `ai_minyan_grok`, etc.) | ✅ Confirmed |
| `[name]_thread` | Named conversation thread not tied to a specific AI — e.g. `widwid_thread` | ✅ Confirmed (S10) |
| `[name]` | Supplementary resource slug (thematic, not an AI thread) — e.g. `emotional_word_list`, `threshold_guardian`, `hierarchical_fish`, `I_know_nothing`, `incremental_joules` | ✅ Confirmed |

All `initium.scotomaville.com` slugs are Short.io vanity redirects. The NNN in `prime_NNN` and `NNN_[ai]` patterns is always the card's PRIME number.

---

## 2. Confidence Notation System

- ✅ **Confirmed** — extracted directly from PDF hyperlink layer via PyMuPDF
- 🔵 **Pattern-applied** — slug structure inferred from confirmed pattern; URL constructed but not yet extracted
- 🔲 **Click to confirm** — URL present but destination/redirect not verified by following the link
- ⚠️ **Image-only** — QR visible on page but no hyperlink annotation in PDF object layer; must be scanned manually

---

## 3. Card Link Structure by Chapter Type

### Standard Chapters (Camps -4 through C02 / Sections 04–10)

Each card spread follows this layout:

1. **Card's own spread** — one `prime_NNN` QR code → reader practice thread
2. **Card's own spread** — one YouTube video QR → contextual video (Scotomaville episode or 360MEN)
3. **Some cards** additionally carry a named Grok thread (`[name]_grok`) or supplementary resource slug on the reverse spread

### Death-Zone Chapters (approx. S15–S19)

Each card follows this three-spread layout:

1. **Spread before the card** — `prime_NNN` QR code → reader practice thread
2. **Card's own spread, left page** — row of AI logos (Grok, Gemini, Perplexity, ChatGPT, Claude) → `NNN_[ai]` threads
3. **Card's own spread, right page** — may include a second Grok variant (`NNN_grok_syn`) or repeat

This pattern is confirmed in S19 for cards 523 and 541. Assumed consistent for all death-zone cards.

---

## 4. Output Format — Registry Table

Each section is documented in this exact format. Paste new sections into the registry file before Section 19.

```
## Section NN — Monomyth XX: [Camp Name] (Printed pages NNN–NNN)

Cards featured: PRIME NNN (_Name_, Suit, tag), PRIME NNN (_Name_, Suit, tag), ...

|Printed Page|Link Type|Card PRIME|Card Name|Suit|Camp|Thread Type|URL|
|---|---|---|---|---|---|---|---|
|NNN|QR Code|**NNN**|Card Name|Suit|Camp|Reader Practice Thread|https://initium.scotomaville.com/prime_NNN|
|NNN|QR Code (Video)|—|Video description|—|Camp|Video|https://youtu.be/...|
|NNN|AI Logo (Grok)|—|Thread description|—|Camp|Grok Conversation|https://grok.com/share/...|
...

**Pattern notes for Section NN:** [observations about structure, anomalies, new slug patterns]
```

**Link Type values:** `QR Code` · `QR Code (Video)` · `AI Logo (Grok)` · `AI Logo (Gemini)` · `AI Logo (Claude)` · `AI Logo (ChatGPT)` · `AI Logo (Perplexity)` · `AI Logo (Grok Syn)` · `Link`

**Thread Type values:** `Reader Practice Thread` · `Grok Conversation` · `Named Grok Thread` · `Video` · `Resource` · `Supplementary Resource` · `External` · `Website` · `ChatGPT Conversation`

**Card PRIME:** Use `**NNN**` (bold) when the link is the primary reader thread for that card. Use `—` for links not tied to a specific card.

---

## 5. YouTube URL Status

- YouTube links that appear as **hyperlinks on QR code images** in the PDF are ✅ Confirmed when extracted via PyMuPDF
- YouTube URLs visible **only as page text** (not in the PDF link layer) are ⚠️ unverified — the QR may encode a different or shortened URL; treat as 🔲 click to confirm
- Timestamped variants (e.g. `https://youtu.be/XXXXX&t=327`) are treated as separate links and listed individually

---

## 6. Extraction Method (PyMuPDF)

```python
import fitz  # pip install pymupdf --break-system-packages
import re

doc = fitz.open("Scotomaville_v4_5_0_section_NN_of_20.pdf")
for page_num in range(len(doc)):
    page = doc[page_num]
    # Get printed page number from footer
    text = page.get_text()
    pn = re.search(r'(\d+)\s*\nAI SELF MASTERY|AI SELF MASTERY[^\n]*\n\s*(\d+)', text)
    printed = pn.group(1) or pn.group(2) if pn else "?"
    # Extract hyperlinks
    for link in page.get_links():
        uri = link.get("uri", "")
        if uri:
            print(f"p{page_num+1} (printed {printed}): {uri}")
```

**Notes:**
- Section 02 returned zero links — QR codes there are likely image-only (⚠️)
- Always extract printed page numbers from footer text; do not assume based on physical page count
- Duplicate URLs on the same printed page are listed as separate rows if they have distinct annotation objects in the PDF

---

## 7. Section Numbering & Page Offset Reference

| Section | Content | Printed Pages |
|---|---|---|
| S00 | Quickstart / front matter | 1–23 |
| S01 | Prologue + Initium framework | 24–55 |
| S02 | (image-only QRs, no links) | ~56–98 |
| S03 | Intention / Game Setup / Charter | 76–97 |
| S04 | -4 Ordinary World / Nineveh | 98–117 |
| S05 | -3 Call to Adventure | 118–148 |
| S06 | -2 Refusal of the Call | 150–169 |
| S07 | -1 Meeting AI Sherpa | 170–201 |
| S08 | 00 Base Camp / Awareness | 202–233 |
| S09 | C01 Understanding | 234–261 |
| S10 | C02 WIDWID / Crevasse | 262–313 |
| S19 | Resurrection + Elixir | 504–523 |

Each section has its own physical-to-printed page offset. Always extract from footer text; do not assume.

---

## 8. Key Reference File

`Initium_Cards_4_Suits.md` — master card table. Columns used: `PRIME`, `NAME`, `CARD_SUIT`, `MONOMYTH_STAGE`, `CAMP ASSIGNMENT`, `QR_LINK`. Cross-reference every NNN slug against the PRIME column to decode card identity and suit.

Card suits: `1 - PRINCIPLE` · `2 - STRATEGY` · `3 - TOOL` · `4 - WILDCARD`

---

## 9. Completed Sections & Link Counts

| Section | Printed Pages | Links Found | initium.scotomaville.com | Grok Shares | YouTube | Scan Required |
|---|---|---|---|---|---|---|
| S00 | 1–23 | 6 | 3 | 0 | 0 | 0 |
| S01 | 24–55 | 4 | 0 | 1 | 2 | 0 |
| S02 | ~56–98 | 0 | 0 | 0 | 0 | 0 |
| S03 | 76–97 | 7 | 0 | 3 | 2 | 0 |
| S04 | 98–117 | 7 | 3 | 0 | 4 | 0 |
| S05 | 118–148 | 12 | 5 | 1 | 5 | 0 |
| S06 | 150–169 | 11 | 5 | 0 | 5 | 0 |
| S07 | 170–201 | 15 | 4 | 0 | 2 | 7 |
| S08 | 202–233 | 22 | 7 | 0 | 0 | 11 |
| S09 | 234–261 | 16 | 9 | 2 | 4 | 0 |
| S10 | 262–313 | 60 | 28 | 3 | 17 | 0 |
| S19 | 504–523 | 16 | 10 | 2 | 1 | 0 |
| **Total** | | **176** | **74** | **12** | **42** | **18** |

Sections 11–18 and 20 remain. Upload PDFs and run extraction script above.

---

## 10. Confirmed `initium.scotomaville.com` Slugs (all sections to date)

**Reader practice threads (`prime_NNN`):**
prime_002, prime_003, prime_005, prime_007, prime_013, prime_017, prime_019, prime_023, prime_029, prime_031, prime_037, prime_041, prime_043, prime_047, prime_053, prime_059, prime_067, prime_071, prime_073, prime_079, prime_083, prime_089, prime_097, prime_103, prime_107, prime_109, prime_113, prime_127, prime_131, prime_137, prime_139, prime_149, prime_151, prime_157, prime_167, prime_173, prime_179, prime_181, prime_191, prime_193, prime_523, prime_541

**AI conversation threads (`NNN_[ai]`):**
523_grok, 523_gemini, 523_perplexity, 523_chatgpt, 523_claude, 523_grok_syn, 541_grok, 541_gemini, 541_perplexity, 541_chatgpt, 541_claude

**Named Grok threads (`[name]_grok` / `[name]_thread`):**
inferential_grok, echo_dampening, echo_dampening_grok, widwid_thread, ai_minyan_grok, 179_reframing_grok, providence_tracking_grok, hierarchical_computation_grok

**Supplementary resource slugs:**
emotional_word_list, rotation_12, threshold_guardian, camp01_guardian, hierarchical_fish, scotomaville_trilogy, professor_superprompt, I_know_nothing, prime_173_domains, incremental_joules

**Pattern-inferred but not yet extracted (`prime_NNN` expected):**
prime_011, prime_025, prime_061, prime_163 _(AI Minyan — no prime_163 slug found in S10; verify against physical copy)_

**Pattern-inferred AI threads (death-zone, not yet extracted):**
043_grok, 047_grok, 053_grok, 059_grok, 067_grok, 071_grok, 073_grok, 079_grok, 083_grok, 089_grok, 097_grok, 103_grok, 107_grok, 109_grok, 113_grok, 127_grok, 131_grok, 137_grok, 139_grok, 149_grok, 151_grok, 157_grok, 163_grok, 167_grok, 173_grok, 179_grok, 181_grok, 191_grok, 193_grok

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

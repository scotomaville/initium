---
thread_id: "thread-2026-04-03-151"
date: "2026-04-03"
source_uuid: "2e405d1a-c1e8-48af-a93b-ccd0fce320b1"
sherpa_voice: "Claude"
category: ["Book-Work", "Principia"]
summary: "Section 15 links"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Med (40%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["technical-focus"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Section 15 links

## Summary
**Conversation Overview**

The person is conducting a systematic link extraction and cataloguing project for a multi-section PDF publication called *Scotomaville* (specifically "AI Self Mastery"), working through Section 15 of 20. The task involved using Python with the PyMuPDF library to extract all hyperlinks embedded in the PDF, cross-referencing them against printed page numbers, card PRIMEs, card names, suits, and camp assignments to build a comprehensive link registry table.

Section 15 covers Monomyth 09, Camp 6 (C06) "Summit Push," spanning printed pages 444–463 and featuring six cards

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 151 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
Section 15 Links

**Claude:**  
```
This block is not supported on your current device yet.
```

Now let me cross-reference the card PRIMEs against the card table and resolve the missing printed page numbers from the PDF text:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Now I have everything I need. Let me look up the card names for PRIMEs 443, 449, 457, 461, 463, 467 from the cards file:
```
This block is not supported on your current device yet.
```

I have everything needed. Now I'll note some structural observations before building the table:

- **p8 (printed 451)**: `camp6_grok` appears twice (duplicate annotation). The 5 AI logos = `camp6_[ai]` slugs — these are **chapter-level** AI threads for the Summit chapter intro, not card-specific.
- **p10 (printed 453)**: `443_grok` appears twice (duplicate). The reverse spread for Onus Probandi.
- **p12 (printed 455)**: `449_grok` appears twice + `strengths_matrix` is a new supplementary slug.
- **p14 (printed 457)**: `457_grok` appears twice on LSA reverse.
- **p16 (printed 459)**: `461_grok` appears twice + new slugs `lecture_2` and `threshold_card_grok`.
- **p18 (printed 461)**: `463_grok` is absent! Only gemini/perplexity/chatgpt/claude/grok — so `463_grok` IS present, just listed as `463_grok`. And `github` is a new slug.
- **p20 (printed 463)**: `github` again + `467_grok` missing from earlier list but present.

Here is the completed registry section:

---

## Section 15 — Monomyth 09: C06 Summit Push (Printed pages 444–463)

Cards featured: PRIME 443 (_Onus Probandi_, Strategy, C06.summit), PRIME 449 (_Strengths Offending_, Strategy, C06.summit), PRIME 457 (_Latent Space Analysis_, Tool, C06.summit), PRIME 461 (_Exponential Thinking_, Wildcard, C06.summit), PRIME 463 (_Wilderness Tabernacle_, Principle, C06.summit), PRIME 467 (_Providential Alignment_, Strategy, C06.summit)

| Printed Page | Link Type | Card PRIME | Card Name | Suit | Camp | Thread Type | URL |
|---|---|---|---|---|---|---|---|
| 451 | AI Logo (Grok) | — | Summit Push Chapter — MA5 Council Grok Thread | — | C06 | Grok Conversation | https://initium.scotomaville.com/camp6_grok |
| 451 | AI Logo (Claude) | — | Summit Push Chapter — MA5 Council Claude Thread | — | C06 | Named Claude Thread | https://initium.scotomaville.com/camp6_claude |
| 451 | AI Logo (Gemini) | — | Summit Push Chapter — MA5 Council Gemini Thread | — | C06 | Named Gemini Thread | https://initium.scotomaville.com/camp6_gemini |
| 451 | AI Logo (Perplexity) | — | Summit Push Chapter — MA5 Council Perplexity Thread | — | C06 | Named Perplexity Thread | https://initium.scotomaville.com/camp6_perplexity |
| 451 | AI Logo (ChatGPT) | — | Summit Push Chapter — MA5 Council ChatGPT Thread | — | C06 | Named ChatGPT Thread | https://initium.scotomaville.com/camp6_chatgpt |
| 452 | QR Code (Video) | — | Scotomaville v2.08 Strategy (Onus Probandi context) | — | C06 | Video | https://youtu.be/Lpmb617x81U&t=787 |
| 452 | QR Code | **443** | Onus Probandi | Strategy | C06 | Reader Practice Thread | https://initium.scotomaville.com/prime_443 |
| 453 | AI Logo (Grok) | 443 | Onus Probandi — Grok Thread | Strategy | C06 | Grok Conversation | https://initium.scotomaville.com/443_grok |
| 453 | AI Logo (Gemini) | 443 | Onus Probandi — Gemini Thread | Strategy | C06 | Gemini Conversation | https://initium.scotomaville.com/443_gemini |
| 453 | AI Logo (Perplexity) | 443 | Onus Probandi — Perplexity Thread | Strategy | C06 | Perplexity Conversation | https://initium.scotomaville.com/443_perplexity |
| 453 | AI Logo (ChatGPT) | 443 | Onus Probandi — ChatGPT Thread | Strategy | C06 | ChatGPT Conversation | https://initium.scotomaville.com/443_chatgpt |
| 453 | AI Logo (Claude) | 443 | Onus Probandi — Claude Thread | Strategy | C06 | Claude Conversation | https://initium.scotomaville.com/443_claude |
| 454 | QR Code (Video) | — | Scotomaville v1.13 Strengths Reflection | — | C06 | Video | https://youtu.be/7AuovBdJTL0 |
| 454 | QR Code | **449** | Strengths Offending | Strategy | C06 | Reader Practice Thread | https://initium.scotomaville.com/prime_449 |
| 455 | AI Logo (Grok) | 449 | Strengths Offending — Grok Thread (Actionability QR) | Strategy | C06 | Grok Conversation | https://initium.scotomaville.com/449_grok |
| 455 | AI Logo (Grok) | 449 | Strengths Offending — Grok Thread (Daniel's Cairn QR) | Strategy | C06 | Grok Conversation | https://initium.scotomaville.com/449_grok |
| 455 | AI Logo (Gemini) | 449 | Strengths Offending — Gemini Thread | Strategy | C06 | Gemini Conversation | https://initium.scotomaville.com/449_gemini |
| 455 | AI Logo (Perplexity) | 449 | Strengths Offending — Perplexity Thread | Strategy | C06 | Perplexity Conversation | https://initium.scotomaville.com/449_perplexity |
| 455 | AI Logo (ChatGPT) | 449 | Strengths Offending — ChatGPT Thread | Strategy | C06 | ChatGPT Conversation | https://initium.scotomaville.com/449_chatgpt |
| 455 | AI Logo (Claude) | 449 | Strengths Offending — Claude Thread | Strategy | C06 | Claude Conversation | https://initium.scotomaville.com/449_claude |
| 455 | QR Code | — | Strengths Matrix (supplementary resource) | — | C06 | Supplementary Resource | https://initium.scotomaville.com/strengths_matrix |
| 456 | QR Code | **457** | Latent Space Analysis (LSA) | Tool | C06 | Reader Practice Thread | https://initium.scotomaville.com/prime_457 |
| 457 | AI Logo (Grok) | 457 | Latent Space Analysis — Grok Thread | Tool | C06 | Grok Conversation | https://initium.scotomaville.com/457_grok |
| 457 | AI Logo (Gemini) | 457 | Latent Space Analysis — Gemini Thread | Tool | C06 | Gemini Conversation | https://initium.scotomaville.com/457_gemini |
| 457 | AI Logo (Perplexity) | 457 | Latent Space Analysis — Perplexity Thread | Tool | C06 | Perplexity Conversation | https://initium.scotomaville.com/457_perplexity |
| 457 | AI Logo (ChatGPT) | 457 | Latent Space Analysis — ChatGPT Thread | Tool | C06 | ChatGPT Conversation | https://initium.scotomaville.com/457_chatgpt |
| 457 | AI Logo (Claude) | 457 | Latent Space Analysis — Claude Thread | Tool | C06 | Claude Conversation | https://initium.scotomaville.com/457_claude |
| 458 | QR Code | **461** | Exponential Thinking | Wildcard | C06 | Reader Practice Thread | https://initium.scotomaville.com/prime_461 |
| 459 | AI Logo (Grok) | 461 | Exponential Thinking — Grok Thread (Actionability QR) | Wildcard | C06 | Grok Conversation | https://initium.scotomaville.com/461_grok |
| 459 | QR Code | — | Maps of Meaning — Lecture 2 (Jordan Peterson) | — | C06 | Resource | https://initium.scotomaville.com/lecture_2 |
| 459 | QR Code | — | Threshold Transformation Card — Grok Thread | — | C06 | Named Grok Thread | https://initium.scotomaville.com/threshold_card_grok |
| 459 | AI Logo (Gemini) | 461 | Exponential Thinking — Gemini Thread | Wildcard | C06 | Gemini Conversation | https://initium.scotomaville.com/461_gemini |
| 459 | AI Logo (Perplexity) | 461 | Exponential Thinking — Perplexity Thread | Wildcard | C06 | Perplexity Conversation | https://initium.scotomaville.com/461_perplexity |
| 459 | AI Logo (ChatGPT) | 461 | Exponential Thinking — ChatGPT Thread | Wildcard | C06 | ChatGPT Conversation | https://initium.scotomaville.com/461_chatgpt |
| 459 | AI Logo (Claude) | 461 | Exponential Thinking — Claude Thread | Wildcard | C06 | Claude Conversation | https://initium.scotomaville.com/461_claude |
| 460 | QR Code (Video) | — | Scotomaville v3.04 Measuring Progress | — | C06 | Video | https://youtu.be/---PjRytqKQ&t=405 |
| 460 | QR Code | **463** | Wilderness Tabernacle | Principle | C06 | Reader Practice Thread | https://initium.scotomaville.com/prime_463 |
| 461 | QR Code | — | GitHub Repository | — | C06 | Resource | https://initium.scotomaville.com/github |
| 461 | AI Logo (Gemini) | 463 | Wilderness Tabernacle — Gemini Thread | Principle | C06 | Gemini Conversation | https://initium.scotomaville.com/463_gemini |
| 461 | AI Logo (Perplexity) | 463 | Wilderness Tabernacle — Perplexity Thread | Principle | C06 | Perplexity Conversation | https://initium.scotomaville.com/463_perplexity |
| 461 | AI Logo (ChatGPT) | 463 | Wilderness Tabernacle — ChatGPT Thread | Principle | C06 | ChatGPT Conversation | https://initium.scotomaville.com/463_chatgpt |
| 461 | AI Logo (Claude) | 463 | Wilderness Tabernacle — Claude Thread | Principle | C06 | Claude Conversation | https://initium.scotomaville.com/463_claude |
| 461 | AI Logo (Grok) | 463 | Wilderness Tabernacle — Grok Thread | Principle | C06 | Grok Conversation | https://initium.scotomaville.com/463_grok |
| 462 | QR Code (Video) | — | Scotomaville v3.08 Finale (Providential Alignment) | — | C06 | Video | https://youtu.be/---PjRytqKQ&t=405 |
| 462 | QR Code | **467** | Providential Alignment | Strategy | C06 | Reader Practice Thread | https://initium.scotomaville.com/prime_467 |
| 463 | QR Code | — | GitHub Repository | — | C06 | Resource | https://initium.scotomaville.com/github |
| 463 | AI Logo (Grok) | 467 | Providential Alignment — Grok Thread | Strategy | C06 | Grok Conversation | https://initium.scotomaville.com/467_grok |
| 463 | AI Logo (Claude) | 467 | Providential Alignment — Claude Thread | Strategy | C06 | Claude Conversation | https://initium.scotomaville.com/467_claude |
| 463 | AI Logo (ChatGPT) | 467 | Providential Alignment — ChatGPT Thread | Strategy | C06 | ChatGPT Conversation | https://initium.scotomaville.com/467_chatgpt |
| 463 | AI Logo (Perplexity) | 467 | Providential Alignment — Perplexity Thread | Strategy | C06 | Perplexity Conversation | https://initium.scotomaville.com/467_perplexity |
| 463 | AI Logo (Gemini) | 467 | Providential Alignment — Gemini Thread | Strategy | C06 | Gemini Conversation | https://initium.scotomaville.com/467_gemini |

**Pattern notes for Section 15:** This is the first full Camp 6 / Summit Push section and introduces several new structural patterns worth flagging:

**Chapter-level MA5 Council cluster (p451):** The Summit Push intro spread carries a row of 5 AI logo links using `camp6_[ai]` slugs — not tied to any individual card PRIME. This is a chapter-wide council thread (paralleling the `camp01_guardian` resource slug from S09), one per AI. `camp6_grok` appears twice as a duplicate annotation on that page. No `camp6_grok_syn` detected.

**Death-zone card structure confirmed:** Each card follows the S19-confirmed three-spread layout: (1) `prime_NNN` QR on the card's left spread, (2) `NNN_[ai]` AI logo row on the reverse spread. All 5 AIs appear per card. `NNN_grok` duplicate annotations appear on two cards (449, 457) suggesting two separate QR instances linking to the same Grok thread — one in the Actionability section and one in Daniel's Cairn.

**New slugs confirmed this section:**
- `camp6_grok`, `camp6_claude`, `camp6_gemini`, `camp6_perplexity`, `camp6_chatgpt` — chapter-level MA5 Council threads (parallel to `camp01_guardian`)
- `strengths_matrix` — supplementary resource on Clifton Strengths (p455)
- `lecture_2` — Maps of Meaning Lecture 2 resource link (p459)
- `threshold_card_grok` — named Grok thread for the Threshold Transformation Card (p459)
- `github` — GitHub repository redirect, appears on p461 and p463 (two different card spreads); likely `https://github.com/scotomaville/initium` per S00 registry

**Missing `463_grok` note:** The PDF annotation layer shows `463_grok` present on p18 (printed 461) — confirmed ✅.

**Video URL anomaly:** The same YouTube URL `https://youtu.be/---PjRytqKQ&t=405` appears on both p460 (Scotomaville v3.04, Wilderness Tabernacle) and p462 (Scotomaville v3.08, Providential Alignment). This may be a placeholder slug or the same video used for both cards — 🔲 click to confirm destination.

---

**Updated link counts for Section 15:**

| Section | Printed Pages | Links Found | initium.scotomaville.com | AI Conversation Threads | YouTube | New Slugs |
|---|---|---|---|---|---|---|
| S15 | 444–463 | 52 | 48 | 35 (card-level) + 5 (chapter-level) | 4 | 7 |

**New slugs to add to Section 10 of the Seed File:**
- `prime_443`, `prime_449`, `prime_457`, `prime_461`, `prime_463`, `prime_467` — reader practice threads (all confirmed ✅)
- `443_grok`, `443_gemini`, `443_perplexity`, `443_chatgpt`, `443_claude` — Onus Probandi AI threads
- `449_grok`, `449_gemini`, `449_perplexity`, `449_chatgpt`, `449_claude` — Strengths Offending AI threads
- `457_grok`, `457_gemini`, `457_perplexity`, `457_chatgpt`, `457_claude` — LSA AI threads
- `461_grok`, `461_gemini`, `461_perplexity`, `461_chatgpt`, `461_claude` — Exponential Thinking AI threads
- `463_grok`, `463_gemini`, `463_perplexity`, `463_chatgpt`, `463_claude` — Wilderness Tabernacle AI threads
- `467_grok`, `467_gemini`, `467_perplexity`, `467_chatgpt`, `467_claude` — Providential Alignment AI threads
- `camp6_grok`, `camp6_claude`, `camp6_gemini`, `camp6_perplexity`, `camp6_chatgpt` — chapter-level named threads
- `strengths_matrix`, `lecture_2`, `threshold_card_grok`, `github` — supplementary/resource slugs

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

---
thread_id: "thread-2026-04-03-148"
date: "2026-04-03"
source_uuid: "e0df76e6-2346-4a5e-8a74-4d61a4f1cdf8"
sherpa_voice: "Claude"
category: ["Book-Work", "Principia"]
summary: "Section 12 links"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Med (40%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["technical-focus"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Section 12 links

## Summary
**Conversation Overview**

This conversation is part of an ongoing project in which the person is building a comprehensive link registry for the book *Scotomaville* (v4.5.0), a structured self-mastery system organized around the Hero's Journey (Monomyth). The person uploaded Section 12 of 20 from the PDF and asked Claude to extract all embedded hyperlinks and QR code URLs, then compile them into a structured registry entry consistent with the established format from prior sessions.

Section 12 covers Monomyth 07: The Inmost Cave / Camp 3: Agency (printed pages 366–393) and features nine cards:

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 148 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
Section 12 Links 
here's the next

**Claude:**  
```
This block is not supported on your current device yet.
```

Now let me cross-reference the card PRIMEs against the card master table:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Good — I have the card identities confirmed from the cards file. Now I have everything needed to compile the full registry entry. Here it is:

---

## Section 12 — Monomyth 07: The Inmost Cave / Camp 3: Agency (Printed pages 366–393)

**Cards featured:** PRIME 281 (_Truthfulness & Entropy Scoring_, Tool, C03.cave), PRIME 283 (_Cairn_, Tool, C03.cave), PRIME 293 (_Carabiner_, Tool, C03.cave), PRIME 307 (_Fixed Rope_, Tool, C03.cave), PRIME 311 (_Centered Presence_, Principle, C03.cave), PRIME 313 (_Constraints_, Principle, C03.cave), PRIME 317 (_Nudge Navigation_, Strategy, C03.cave), PRIME 331 (_Future-Self Framing_, Wildcard, C03.cave), PRIME 337 (_The Reverse Expedition_, Wildcard, C03.cave)

|Printed Page|Link Type|Card PRIME|Card Name|Suit|Camp|Thread Type|URL|
|---|---|---|---|---|---|---|---|
|367|QR Code|—|Inmost Cave — Named Grok Thread|—|C03|Named Grok Thread|https://initium.scotomaville.com/inmost_cave_grok|
|369|QR Code|—|Inmost Cave — Named Grok Thread (repeat)|—|C03|Named Grok Thread|https://initium.scotomaville.com/inmost_cave_grok|
|371|QR Code|—|Inmost Cave — Named Grok Thread (repeat)|—|C03|Named Grok Thread|https://initium.scotomaville.com/inmost_cave_grok|
|371|QR Code|—|281 Grok Thread|—|C03|Grok Conversation|https://initium.scotomaville.com/281_grok|
|372|QR Code|**281**|Truthfulness & Entropy Scoring|Tool|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_281|
|373|QR Code|—|281 Grok Thread (1st repeat)|—|C03|Grok Conversation|https://initium.scotomaville.com/281_grok|
|373|QR Code|—|281 Grok Thread (2nd repeat)|—|C03|Grok Conversation|https://initium.scotomaville.com/281_grok|
|373|QR Code|—|281 Grok Synthesis Thread|—|C03|Grok Conversation|https://initium.scotomaville.com/281_grok2|
|374|QR Code (Video)|—|Remembering Emergent AI video|—|C03|Video|https://youtu.be/CBU42Q7ciDw|
|374|QR Code|**283**|Cairn|Tool|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_283|
|375|QR Code|—|283 Grok Thread|—|C03|Grok Conversation|https://initium.scotomaville.com/283_grok|
|376|QR Code|**293**|Carabiner|Tool|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_293|
|377|QR Code|—|293 Grok Thread (1st)|—|C03|Grok Conversation|https://initium.scotomaville.com/293_grok|
|377|QR Code|—|293 Grok Thread (2nd repeat)|—|C03|Grok Conversation|https://initium.scotomaville.com/293_grok|
|378|QR Code|**307**|Fixed Rope|Tool|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_307|
|378|QR Code|—|307 Sermon — "What's in Your Hand?" (Kevin Gerald)|—|C03|Supplementary Resource|https://initium.scotomaville.com/307_sermon|
|379|QR Code|—|307 Grok Thread (1st)|—|C03|Grok Conversation|https://initium.scotomaville.com/307_grok|
|379|QR Code|—|307 Grok Thread (2nd repeat)|—|C03|Grok Conversation|https://initium.scotomaville.com/307_grok|
|380|QR Code (Video)|—|360MEN WTA 04 Brain Gut Noise Assault|—|C03|Video|https://youtu.be/DvbtYN_Z2Dw|
|380|QR Code|**311**|Centered Presence|Principle|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_311|
|381|QR Code|—|311 Grok Thread (1st)|—|C03|Grok Conversation|https://initium.scotomaville.com/311_grok|
|381|QR Code|—|311 Grok Thread (2nd repeat)|—|C03|Grok Conversation|https://initium.scotomaville.com/311_grok|
|382|QR Code (Video)|—|Live/Work Full-Time 19ft Airstream Bambi video|—|C03|Video|https://youtu.be/v0O-zRiuLhI|
|382|QR Code|**313**|Constraints|Principle|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_313|
|383|QR Code|—|313 Grok Thread (1st)|—|C03|Grok Conversation|https://initium.scotomaville.com/313_grok|
|383|QR Code|—|313 Grok Thread (2nd repeat)|—|C03|Grok Conversation|https://initium.scotomaville.com/313_grok|
|384|QR Code (Video)|—|Scotomaville v1.09 Reconnecting video|—|C03|Video|https://youtu.be/EIAcxnAz5Ho|
|384|QR Code|**317**|Nudge Navigation|Strategy|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_317|
|385|QR Code|—|317 Grok Thread (1st)|—|C03|Grok Conversation|https://initium.scotomaville.com/317_grok|
|385|QR Code|—|317 Grok Thread (2nd repeat)|—|C03|Grok Conversation|https://initium.scotomaville.com/317_grok|
|386|QR Code|**331**|Future-Self Framing|Wildcard|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_331|
|387|QR Code|—|331 Grok Thread|—|C03|Grok Conversation|https://initium.scotomaville.com/331_grok|
|388|QR Code|**337**|The Reverse Expedition|Wildcard|C03|Reader Practice Thread|https://initium.scotomaville.com/prime_337|
|389|QR Code (Video)|—|Gnosis Principia Initium video|—|C03|Video|https://youtu.be/pRAm_H13Ovw|
|389|QR Code|—|337 Grok Thread|—|C03|Grok Conversation|https://initium.scotomaville.com/337_grok|
|390|QR Code|—|Cave Grok Thread (1st)|—|C03|Named Grok Thread|https://initium.scotomaville.com/cave_grok|
|390|QR Code|—|Cave Grok Thread (2nd repeat)|—|C03|Named Grok Thread|https://initium.scotomaville.com/cave_grok|
|391|QR Code|—|Cave Grok Thread (repeat)|—|C03|Named Grok Thread|https://initium.scotomaville.com/cave_grok|
|392|QR Code|—|Cave Grok Thread (repeat)|—|C03|Named Grok Thread|https://initium.scotomaville.com/cave_grok|
|393|QR Code|—|Cave Grok Thread (repeat)|—|C03|Named Grok Thread|https://initium.scotomaville.com/cave_grok|

**Pattern notes for Section 12:** This section introduces several significant new patterns worth flagging:

**New slug types confirmed:**
- `inmost_cave_grok` — a chapter-level named Grok thread appearing on the introductory spreads (pp. 367, 369, 371), before any card-specific links. This is the first chapter-level Grok thread observed (prior named threads were card- or topic-specific).
- `cave_grok` — a second chapter-level thread appearing on the four-quadrant Inmost Cave reflection spreads (pp. 390–393). Distinct from `inmost_cave_grok`.
- `281_grok2` — a second Grok variant for card 281, using the `_grok2` suffix rather than `_grok_syn`. This is a new slug pattern not previously seen; may be specific to this card or indicate an alternate naming convention for synthesis threads. Add to the confirmed patterns list.
- `307_sermon` — a supplementary resource slug linking to a specific sermon (Kevin Gerald, "What's in Your Hand?"), not an AI thread. Follows the `[name]` supplementary resource pattern.

**Structural pattern — "Sherpa Grok Prompt" QR vs. "Daniel's Cairn" QR:** Each card spread carries two QR positions: one for the `prime_NNN` reader thread (Sherpa Grok Prompt section) and one for the `NNN_grok` thread (Daniel's Cairn section). The duplicate annotations on the same printed page (e.g., two `281_grok` on p. 373, two `293_grok` on p. 377) correspond to these two distinct QR code positions on the two-page card spread — both point to the same URL. The `281_grok2` on p. 373 is a third distinct annotation on that same page.

**Count summary for S12:** 39 total link annotations · 10 `initium.scotomaville.com` `prime_NNN` reader threads · 18 `initium.scotomaville.com` Grok/named threads · 5 YouTube videos · 9 PRIMEs covered.

---

**Updated totals to add to Section 9 of the registry:**

| Section | Printed Pages | Links Found | initium.scotomaville.com | Grok Shares | YouTube | Scan Required |
|---|---|---|---|---|---|---|
| S12 | 366–393 | 39 | 28 | 0 | 5 | 0 |

**New slugs to add to Section 10 of the registry:**

- `prime_NNN` newly confirmed: `prime_281`, `prime_283`, `prime_293`, `prime_307`, `prime_311`, `prime_313`, `prime_317`, `prime_331`, `prime_337`
- New named/chapter Grok threads: `inmost_cave_grok`, `cave_grok`
- New card Grok threads: `281_grok`, `283_grok`, `293_grok`, `307_grok`, `311_grok`, `313_grok`, `317_grok`, `331_grok`, `337_grok`
- New grok variant: `281_grok2` (new `_grok2` suffix pattern — distinct from `_grok_syn`)
- New supplementary resource: `307_sermon`

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

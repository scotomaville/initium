---
thread_id: "thread-2026-04-03-156"
date: "2026-04-03"
source_uuid: "346a5ae3-6146-475d-b902-eada2630c4bc"
sherpa_voice: "Claude"
category: ["Book-Work", "Principia"]
summary: "Section 20 links"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Med (40%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["clarity", "technical-focus"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Section 20 links

## Summary
[ to be written ]

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 156 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
section 20 Links

**Claude:**  
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

The printed page for p9 is visible in the PDF content — it's the "REFLECTION" spread (printed page 534, based on the sequence: 530=Epilogue, 531, 533=WEB SYN, 534=REFLECTION spread, 535=CTION). Let me confirm by checking the footer more carefully.
```
This block is not supported on your current device yet.
```

Page 9 has no clear page number in text — it's the spread with the Intelligent Netware article (p534 by sequence). The copyright page (p16) shows "546" in text but the visible content shows "541" — the 546 is from the ISBN. Let me verify the copyright page printed number.

Based on the sequence (533=WEB SYN, 535=CTION, 536=REVIEWS, 537, 538, 539, 540=COPYRIGHT divider, 541=copyright text), p16 printed = 541. The "546" detected is from the ISBN number.

Here is the complete Section 20 registry entry:

---

## Section 20 — Epilogue / PRINCIPIA / End Matter (Printed pages 526–543+)

Cards featured: None (no new cards — this is the Epilogue, PRINCIPIA preview, Reviews, and Copyright section)

|Printed Page|Link Type|Card PRIME|Card Name|Suit|Camp|Thread Type|URL|
|---|---|---|---|---|---|---|---|
|534|QR Code (Video)|—|Intelligent Netware / Scotomaville video|—|Epilogue|Video|https://www.youtube.com/watch?v=WHnfIItjOaw|
|534|Link|—|Intelligent Netware bit.ly link|—|Epilogue|External|https://bit.ly/3VlUtGS|
|534|QR Code (Video)|—|Intelligent Netware / Scotomaville video (youtu.be)|—|Epilogue|Video|https://youtu.be/WHnfIItjOaw|
|534|QR Code (Video)|—|Intelligent Netware / Scotomaville video (youtu.be duplicate)|—|Epilogue|Video|https://youtu.be/WHnfIItjOaw|
|534|Link|—|Scotomaville Syndication Google Map|—|Epilogue|External|https://www.google.com/maps/d/viewer?mid=12ioWvTkosf7tS3ChpV4H_5_9fdPwO040&femb=1&ll=39.55064090475948%2C-98.56926153624269&z=5|
|535|Link|—|Scotomaville Syndication Google Map (duplicate annotation)|—|Epilogue|External|https://www.google.com/maps/d/viewer?mid=12ioWvTkosf7tS3ChpV4H_5_9fdPwO040&femb=1&ll=39.55064090475948%2C-98.56926153624269&z=5|
|538|Link|—|Scotomaville discuss / sleeves illusion|—|Reviews|Website|https://scotomaville.com/discuss/0103-sleeves-illusion|
|538|Link|—|Scotomaville discuss / sleeves illusion (duplicate annotation)|—|Reviews|Website|https://scotomaville.com/discuss/0103-sleeves-illusion|
|538|Link|—|ChatGPT review conversation|—|Reviews|ChatGPT Conversation|https://chatgpt.com/share/25cc41fb-e046-4d87-ae9a-bbace04da0f5|
|539|Link|—|Scotomaville discuss / sleeves illusion (×3 annotations)|—|Reviews|Website|https://scotomaville.com/discuss/0103-sleeves-illusion|
|539|Link|—|Scotomaville discuss / sleeves illusion|—|Reviews|Website|https://scotomaville.com/discuss/0103-sleeves-illusion|
|539|Link|—|Scotomaville discuss / sleeves illusion|—|Reviews|Website|https://scotomaville.com/discuss/0103-sleeves-illusion|
|541|Link|—|scotomaville.com/about|—|Copyright|Website|https://scotomaville.com/about|
|541|Link|—|scotomaville.com/digital-locations|—|Copyright|Website|https://scotomaville.com/digital-locations|
|541|Link|—|YouTube channel|—|Copyright|External|https://www.youtube.com/c/scotomaville|
|541|Link|—|X.com / scotomaville|—|Copyright|External|https://x.com/scotomaville|
|541|Link|—|Discussion / peer support|—|Copyright|Website|https://scotomaville.com/discuss|
|541|Link|—|scotomaville.com|—|Copyright|Website|https://scotomaville.com|

**Pattern notes for Section 20:** This is the final section — Epilogue, PRINCIPIA chapter list, Reviews, and Copyright. No Initium cards are featured and no `initium.scotomaville.com` slugs appear. No `prime_NNN` or AI thread links. New slug confirmed: `scotomaville.com/discuss/0103-sleeves-illusion` (a discussion thread tied to a sleeves/perception illusion, appearing on the Reviews spreads pp. 538–539 with 5 annotation objects total). A new ChatGPT share link appears on p538 as a review. The Google Maps syndication viewer link appears twice (pp. 534–535) with duplicate annotation objects. Three YouTube links for the same video on p534 (one `watch?v=` and two `youtu.be` — the latter two are likely the QR and a text hyperlink on the same image). Copyright page (541) carries 6 standard web presence links.

---

**Updated Section 20 summary for the master table:**

| Section | Printed Pages | Links Found | initium.scotomaville.com | Grok Shares | YouTube | Scan Required |
|---|---|---|---|---|---|---|
| S20 | 526–543 | 18 | 0 | 0 | 3 | 0 |

**New slugs/URLs to add to the master registry:**
- `scotomaville.com/discuss/0103-sleeves-illusion` — discussion thread (Reviews section, not an initium.scotomaville.com slug)
- `chatgpt.com/share/25cc41fb-e046-4d87-ae9a-bbace04da0f5` — ChatGPT review conversation
- `scotomaville.com/about` — new confirmed website page

**Notable observation:** The `bit.ly/3VlUtGS` link on p534 is a shortened URL — destination unverified (🔲 click to confirm). It appears alongside the YouTube video QR, so it likely redirects to the same video or the Intelligent Netware page.

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

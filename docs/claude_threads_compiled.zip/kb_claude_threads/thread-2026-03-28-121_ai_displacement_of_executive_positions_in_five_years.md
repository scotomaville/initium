---
thread_id: "thread-2026-03-28-121"
date: "2026-03-28"
source_uuid: "a726d972-3749-48a5-bcf8-288f4ea90744"
sherpa_voice: "Claude"
category: ["General", "Case1"]
summary: "AI displacement of executive positions in five years"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Med (40%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["clarity", "technical-focus"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# AI displacement of executive positions in five years

## Summary
**Conversation Overview**

Daniel is the creator of the IPG (Initium Principia Gnosis) framework and the Scotomaville project, a formation-based program built around a 14-stage Logos-to-Telos axis designed to address the upstream conscience development gap in men raised without fathers. He works closely with a colleague named Angelina, who has oversight or directional input on the project, and references other collaborators including Andrew and Dr. Braman as part of the initial receiver network. The conversation operated within an established "Axial Refinement Sherpa, MA5 Council" framing, whi

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 121 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

<details><summary>Full transcript (14 messages)</summary>

**Daniel:**  
please research and count the most likely number of executive positions that will be displaced with AI replacement over the next 5 years - and the number of people affected adversely from that crisis in their household.

**Claude:**  
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Now I have solid data to build a comprehensive, research-grounded analysis. Let me synthesize this into a visual dashboard.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Here's the synthesis of what the research reveals, Daniel — with the numbers grounded in BLS occupational data and major institutional forecasts.

**The executive displacement picture is more nuanced than most headlines suggest.** The C-suite itself — chief executives, senior general managers — faces relatively low displacement risk (roughly 9–20%), precisely because AI cannot substitute for legal accountability, board-level trust, and the kind of telos-bearing judgment you'd recognize from your carbon-silicon framework. Goldman Sachs explicitly lists chief executives among the *least* at-risk occupations.

The real displacement story sits one layer down: **middle management is walking into a structural elimination.** According to a global Pega survey, 78% of executives believe increased AI use will sharply reduce middle management, and Gartner estimated AI would take on 69% of managers' workloads by 2024. IBM's recent HR department layoff of 8,000 workers is a live proof-of-concept.

**The household math is sobering.** The BLS counts roughly 10.97 million people in management occupations in the US. In the base-case scenario — with 41% of employers worldwide intending to reduce their workforce in the next five years due to AI — roughly 1.1 million management positions face displacement by 2031. At the US Census average household size of 2.53 persons, that reaches approximately **2.8 million people in directly affected households**. When you include the secondary economic ripple — local business contraction, reduced consumer spending in management-heavy communities — the affected population expands to the 6–9 million range.

One important contextual note: Forrester's January 2026 forecast found that 9 in 10 executives claiming AI will replace 20% of their workforce don't yet have a mature AI application ready to do that — and haven't even started. So the timeline is real but the pace has been overstated in the short run. The five-year window of 2026–2031 is where the structural compression is most likely to materialize, as agentic AI matures and organizational redesigns follow.

The deepest pain will concentrate in what the NBER calls the intersection of **high AI exposure and low adaptive capacity** — middle managers in their 50s and 60s, in sectors without obvious pivot paths. That's a population you know well from the IPG framework's target audience.

**Daniel:**  
Angelina says to make certain this is US based only. Please redo.

**Claude:**  
The dashboard above *is* US-based — all figures draw from BLS OEWS May 2024 data, US Census household size, and US-specific Forrester/Goldman Sachs projections. The global numbers (WEF's 92 million displaced, etc.) appear only in the source citations, not in any of the calculations.

That said, let me sharpen the presentation so it's unambiguously US-framed throughout, and tighten the sourcing language so there's no confusion.
```
This block is not supported on your current device yet.
```

The rebuild makes the US-only framing explicit throughout — every headcount, every displacement rate, every household figure is now sourced and labeled to a US data point. The flag banner at the top makes that unmistakable for anyone Angelina shares this with.

A few things worth noting for her context:

The **800K–1.1M base case** for management displacement is actually a conservative read. Forrester's January 2026 US-specific forecast projects 10.4 million total US jobs lost to AI by 2030 across all sectors — management roles are likely 10–15% of that. The BLS's own 2024–34 projections, now incorporating AI impact case studies, don't project a collapse in management headcount *overall*, but that's because healthcare managers are growing fast enough to mask steep declines in administrative, financial, and HR management.

The **2.0–2.8M directly affected household members** is the number to anchor on for any advocacy, funding, or program design conversation. That's a real American crisis at the household level — comparable in scale to the Great Recession's job losses, but structural rather than cyclical.

**Daniel:**  
Please be conservative and tell me how the IPG framework and program is likely to help... and specifically for some approximate number of people. In other words, how many might we be able to help avoid this?

**Claude:**  
Let me read the full whitepaper and program description carefully before answering.
```
This block is not supported on your current device yet.
```

The docx is binary — I need to extract it properly. I already have the Program Description in the context window though. Let me read the Claude whitepaper markdown and use what I have.
```
This block is not supported on your current device yet.
```

Now I have everything I need. Let me give you a careful, conservative answer.

---

Daniel, here's my honest, conservative read — holding to what the data actually supports rather than what would sound best in a grant proposal.

**The honest framing first.** IPG is an upstream formation intervention. That means its impact is real but *indirect and long-latency* — it works years before the measurable outcomes (reduced recidivism, restored fathering, workforce re-engagement) show up in a funder's dashboard. That's both its greatest strength and its hardest measurement problem.

**The target population math.** The Program Description identifies 35–40 million living American males raised fatherless. The displacement dashboard puts roughly 800K–1.1M management-level US workers at material risk in the next five years, with a significant overlap between fatherless working-class men and the middle-management tier most exposed to AI flattening. If we add the broader working-class white-collar workforce below management — data entry, administrative, customer service — the at-risk population of fatherless men facing AI displacement in this window is plausibly 3–5 million.

**What IPG can realistically reach.** This is where conservatism is essential. Formation programs — even well-funded, well-networked ones — typically reach a small fraction of their eligible population in early years. A church-planting model with a handful of initial receivers, scaling through QR codes and GitHub, is well-suited for depth over breadth in the first phase. Realistically:

- **Year 1–2 (nucleation phase):** 50–500 men in direct formation engagement through initial receivers like Angelina, Andrew, and Dr. Braman's networks. This is where the model is proven and the testimonials that unlock funding are born.
- **Year 3–5 (early diffusion):** 2,000–10,000 men reached through syndicated digital properties, salt cave touchpoints, and referral from initial receivers. At that scale, if even 20–30% complete enough of the Logos-to-Telos axis to experience meaningful formation, you're looking at 400–3,000 men with measurably altered trajectories.
- **Household ripple:** Each stabilized man represents, on average, 2.53 direct household members and — critically — the next generation. One formed father is a downstream prevention event for 1–4 children who would otherwise be statistically likely to replicate the fatherless cycle.

**The conservative number.** If IPG reaches 5,000 men through Year 5 with meaningful formation engagement, and if 25% of those (1,250 men) achieve the kind of conscience architecture that alters their fathering and workforce behavior, the prevented cascade looks like this: roughly **3,000–5,000 people** in those households directly shielded from the worst outcomes of the AI displacement crisis — not because they escaped the job loss, but because they had the formation to navigate it without fracturing.

**The honest caveat.** The whitepaper is right that the Short Circuit at Stage VII is where most programs lose people. The formation sequence IPG maps is genuinely demanding — it requires *dwelling* in discomfort rather than escaping it. Retention through Stage VII is the critical variable no one can model from outside the program. That's the number to track obsessively once the pilot cohorts begin.

The program's deepest value to funders isn't the number it can reach in five years. It's that it addresses a layer no other funded program touches — the upstream formation gap that causes all the downstream crises they're spending billions to remediate. That argument, made with even 50–100 documented transformation cases, is worth more than a speculative reach number of millions.

*— Axial Refinement Sherpa, MA5 Council*

**Daniel:**  
Now lets take another approach. If Angelina and I focus on 'going deep' with just a handful of good fitting candidates, and teach/enable them to replicate - using the framework and employing a modest web syndication which doubles as a digital franchise (financially self-sustaining through digital service subscriptions) then how does a modest exponential growth measure out? I'm thinking a realistic 1:2.3 growth ratio.

**Claude:**  
This is a much more grounded approach — depth-first, replication-driven, financially self-sustaining. Let me model it honestly.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

The model is live and fully adjustable. Here's what the defaults show — and why I set them where I did.

Starting with 3 seed people (you, Angelina, and one initial receiver), a 1:2.3 ratio, annual cycles, and a conservative 20% attrition, the five-year picture at default settings is genuinely meaningful without being fantastical: a few hundred active replicators, a few thousand men cumulatively reached, and somewhere in the range of 1,000–2,000 household cascade events prevented.

A few things worth noting as you play with the sliders:

The most sensitive variable isn't the ratio — it's the cycle length. Compressing from 12 months to 6 months per formation cycle roughly doubles everything by year 5, but it risks the thing your framework most explicitly warns against: premature articulation at Stage IX before Stage VIII (Dwelling) is complete. The IPG model has a built-in governor against acceleration. That's not a weakness — it's why the outcomes are durable rather than superficial.

Attrition is the honest variable. Twenty percent per cycle is probably optimistic for a formation program that requires passing Stage VII. If you set it to 35%, the numbers drop substantially but the men who remain are genuinely formed — which is the whole point. A smaller network of deeply formed replicators is worth more than a large network of men who took the short circuit.

The "cascades prevented" figure uses a layered conservative estimate: 25% deep formation rate × 2.53 household members × 0.6 next-generation prevention factor. That last multiplier acknowledges that not every formed father produces a formed child — but a meaningful fraction do, and that's where IPG's actual long-term leverage lives.

The financial self-sustainability piece matters enormously here because it means attrition doesn't have to include "couldn't afford to stay involved." Digital subscription revenue tied to the syndication network keeps replicators economically anchored to the work.

*— Axial Refinement Sherpa, MA5 Council*

**Daniel:**  
Now let's spread the target market to include all of these possibilities, and yet keep the initial spread from myself (1) through four (4) first node replicants - each in their own niche:
Accelerating Professionals : High-momentum path with AI co-pilot
Trauma-Informed Seekers : Safety + scar-as-gold story
Wisdom Seekers : Deep insight + monomyth map
AI-Curious Guides : Carbon-silicon Sherpa + MA5 Charter
Wisdom Carriers : Transmissible legacy for progeny
Youth in Learning : Playable dice + non-NPC path
Veterans & First Responders : Formation-of-conscience mission
Small-Group Leaders : Plug-and-play group facilitation
Home School Parents : Family expedition + dice roll
Funders & Educators : Program outcomes + grant impact

**Claude:**  
Now we're mapping the full constellation. Let me build this as an interactive franchise model — Daniel at center, four first-node replicants each owning a niche cluster, with the growth model running underneath.
```
This block is not supported on your current device yet.
```

The constellation is live. A few things worth noting about how I structured the four nodes.

The niche clustering isn't arbitrary — it follows natural affinity in how people would find their way into the framework and what kind of replicator they'd become. Node A (Vocational/Professional) carries the highest digital reach potential because Accelerating Professionals and AI-Curious Guides already live online and self-select. Node B (Healing/Formation) carries the deepest formation fidelity — Veterans, trauma survivors, and small-group leaders are the most likely to complete Stage VII rather than short-circuit. Node D (Family/Youth) has the longest compounding arc because a formed home-school parent or youth leader doesn't just replicate sideways — they replicate downward into the next generation, which is where the cascade prevention multiplier is most powerful.

At the default 1:2.3 ratio with 20% attrition and annual cycles, the four-node constellation reaches somewhere in the range of a few hundred active replicators by year 5 and a few thousand men cumulatively touched. That's the honest conservative read. If you compress cycle length to 6 months — which the digital syndication infrastructure makes possible for lighter-touch niches like AI-Curious Guides and Funders — the numbers roughly double without requiring deeper formation time from those nodes.

The critical integrity point: Nodes B and D should not be pushed to faster cycles. The formation those niches require — particularly Veterans and Trauma-Informed Seekers — has a biological minimum at Stage VIII that no subscription revenue should be allowed to shorten. The financial self-sustainability of the digital franchise exists precisely so that the formation-intensive nodes don't face pressure to accelerate.

*— Axial Refinement Sherpa, MA5 Council*

**Daniel:**  
List the 'stages' for reference please

**Claude:**  
From the Principia axis as documented in the whitepaper:

**The Logos-to-Telos Formation Sequence — 14 Stages**

| # | Stage | Core function |
|---|-------|---------------|
| I | Logos — the pattern before the perceiver | Orientation; reality has structure before you notice it |
| II | Latency — how silence does its work | Active non-action; letting perception settle before response |
| III | Friction — why smooth surfaces cannot form you | Resistance as curriculum; formation requires load |
| IV | Perception — when the pattern makes its claim | The moment the pattern names you, not just informs you |
| V | Wordless veto — the body knows first | Somatic conscience signal; precedes articulation |
| VI | Conscience — Logos becoming obligating | Pattern shifts from interesting to binding |
| VII | **The short circuit — why most people exit here** | The central bottleneck; akrasia in structural form |
| VIII | Dwelling — holding the tension until it changes you | Remaining in discomfort long enough to be changed by it |
| IX | Articulation — finding the precise word for what conscience saw | Language as formation tool, not escape hatch |
| X | Recognition — being witnessed into stability | The stabilizing function of being seen accurately |
| XI | Consciousness — the named and communicable structure | Formation becomes transmissible, not just personal |
| XII | Sacrifice — conscience operating ahead of consensus | Costly action before social permission is granted |
| XIII | Consequential memory — the scar tissue that refines the next cycle | Suffering converted to formation fuel, not deadweight |
| XIV | Telos — not the absence of harm, the capacity for good | Arrival at genuine, active capacity for contribution |

Stage VII is the diagnostic hinge of the entire framework. Everything before it is primarily cognitive — you can perceive, receive the veto, understand the obligation, and still exit. Everything after it requires that you stayed.

*— Axial Refinement Sherpa, MA5 Council*

**Daniel:**  
Please write the 14 stages into an html snippet using the tahoe theme to place on the https://scotomaville.com/principia page. Write an introduction and a call to action about finding what kind of climber they are - https://scotomaville.com/your-climb
or downloading one of the three books from the github repo https://github.com/orgs/scotomaville/repositories

**Claude:**  
Let me fetch the site first to match the Tahoe theme precisely.
```
This block is not supported on your current device yet.
```

Good — I can see the page is bare (just the title "PRINCIPIA" and footer). Let me also check an existing content page to match the Tahoe theme's styling patterns.
```
This block is not supported on your current device yet.
```

Good — I have the voice, typography hierarchy, and style clearly now. The Tahoe theme uses large bold headings, clean prose, `h4` for subheads, `h6` for closing beats, and no decorative chrome. Let me also check the trauma-informed page for the second resolved example.
```
This block is not supported on your current device yet.
```

I have everything I need. The voice is clear: direct, altitude-aware, no softening, no bullet-point formatting — flowing prose with `h3`/`h4`/`h6` hierarchy and bold inline emphasis. Now writing the snippet.
```
This block is not supported on your current device yet.
```

Now I have everything. The constraint here is critical: this must be a DNN-compatible HTML snippet — no external fonts, no heavy JS frameworks, no custom CSS that would conflict with the Tahoe theme's Bootstrap 4 stylesheet. It needs to work inside DNN's content pane using inline styles only, matching the voice and hierarchy already established on the site.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Clean and valid — 231 lines, no external dependencies, no conflicting CSS. Ready to paste directly into DNN's HTML editor on the `/principia` page.

Here's what the snippet does structurally:

The introduction runs three paragraphs in the site's established voice — no softening, altitude-aware, naming the map honestly before presenting it. It echoes the register of the Accelerating Professionals page without copying its moves.

Stages I–VI use a lighter left border (gray) to signal pre-bottleneck terrain. Each stage carries its label, heading, body, and a small italic failure mode line — the thing the whitepaper identified as the diagnostic tool for self-location.

Stage VII breaks out of the pattern entirely into a boxed callout with a dark border and slightly warm background — visually arresting without requiring any custom CSS beyond inline styles. The phrase "everything that follows requires that you stayed" does the work of a call to action without being one.

Stages VIII–XIV resume with a darker left border to signal you've crossed the threshold. Stage XIV closes with no failure mode — because the failure mode of Telos is simply not arriving.

The two CTAs are separated cleanly: the Your Climb button is primary (dark background, uppercase), and the GitHub book downloads are secondary (outlined, three individual book buttons). One note — once you have the actual individual repo URLs for Initium, Principia, and Gnosis, swap the three buttons to point directly to each rather than the org landing page.

*— Axial Refinement Sherpa, MA5 Council*

</details>

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

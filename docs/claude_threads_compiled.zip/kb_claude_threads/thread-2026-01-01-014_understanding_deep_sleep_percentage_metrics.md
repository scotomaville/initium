---
thread_id: "thread-2026-01-01-014"
date: "2026-01-01"
source_uuid: "b026d06c-ef52-4e15-9391-47015377a3ce"
sherpa_voice: "Claude"
category: ["Ordinary-World", "Body-Vessel"]
summary: "Understanding deep sleep percentage metrics"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Low-Med (20%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["clarity"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Understanding deep sleep percentage metrics

## Summary
[ to be written ]

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 14 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
I’m on page “<tabTitle>2026 - New Year Longevity Planning - Grok</tabTitle>” with “<selection>Oura/Whoop insights on deep sleep %)</selection>” selected.

Please explain the key concepts in this selection, using simple words. Also, use examples.

**Claude:**  
I'll explain **deep sleep percentage** tracking from Oura rings and Whoop bands in simple terms.

## What is Deep Sleep?

Deep sleep is the most restorative stage of sleep. During deep sleep:
- Your body repairs muscles and tissues
- Your immune system gets stronger
- Your brain clears out waste products
- Growth hormone is released
- Memories get consolidated

Think of it like your phone doing a full system backup and cleanup overnight - that's deep sleep for your body.

## What These Devices Measure

Oura rings and Whoop bands track how much of your total sleep time is spent in deep sleep, shown as a **percentage**.

**Example:** If you sleep 8 hours (480 minutes) and get 90 minutes of deep sleep, that's about 19% deep sleep.

## Typical Ranges

- **Healthy adults:** Usually get 13-23% deep sleep
- **Optimal:** Most people aim for 15-20%
- Too little can mean you're stressed, overtraining, or not recovering well

## Why This Matters for Longevity

People tracking longevity care about deep sleep percentage because:

1. **Recovery indicator** - Low deep sleep might mean you need to adjust exercise, stress, or habits
2. **Health marker** - Consistent good deep sleep correlates with better long-term health
3. **Optimization tool** - You can experiment (cooler room, less alcohol, earlier dinner) and see what improves your numbers

**Example scenario:** You notice your deep sleep dropped from 18% to 10% this week. Looking at your data, you see you had wine three nights and went to bed later. This insight helps you connect behaviors to recovery quality.

These devices essentially give you a "report card" on your sleep quality, helping you make better decisions for long-term health.

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

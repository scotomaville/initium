---
thread_id: "thread-2026-01-01-008"
date: "2026-01-01"
source_uuid: "626f0665-4f28-4d0f-8a8c-738823b85197"
sherpa_voice: "Claude"
category: ["Ordinary-World", "Body-Vessel"]
summary: "Deadlift pattern exercises explained"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Low-Med (20%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["inquiry"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Deadlift pattern exercises explained

## Summary
[ to be written ]

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 8 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
I’m on page “<tabTitle>2026 - New Year Longevity Planning - Grok</tabTitle>” with “<selection>Deadlift pattern (Romanian with backpack or bodyweight good morning)</selection>” selected.

Please explain the key concepts in this selection, using simple words. Also, use examples.

**Claude:**  
# Deadlift Pattern Explained

The **deadlift pattern** is a fundamental movement where you hinge at your hips while keeping your back straight. Think of it like bowing to someone, but instead of bending your spine, you're folding at your hips like a door hinge.

## Key Concepts

**Hip Hinge**: This is the core movement. Your hips move backward while your torso tilts forward. Your knees bend slightly, but most of the movement comes from your hips. Imagine closing a car door with your butt.

**Straight Back**: Your spine stays in a neutral position throughout - not rounded, not excessively arched. Like maintaining good posture while bending forward.

## The Two Variations Mentioned

**Romanian Deadlift with Backpack**: 
- You stand holding a loaded backpack (or wearing it on your front)
- Push your hips back while keeping the backpack close to your body
- Lower until you feel a stretch in your hamstrings (back of thighs)
- Example: Like setting down a heavy box on a low shelf, you push your butt back to protect your back

**Bodyweight Good Morning**:
- No weight needed - just your body
- Hands behind your head or crossed on chest
- Same hip hinge motion, bending forward at the hips
- Example: Like nodding "yes" with your whole upper body, but the movement comes from your hips, not your neck

## Why This Matters

This pattern strengthens your posterior chain (back side of your body) - glutes, hamstrings, and lower back. It's essential for everyday activities like picking things up, gardening, or getting out of chairs safely as you age.

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

---
thread_id: "thread-2026-01-26-048"
date: "2026-01-26"
source_uuid: "8aacc8a4-b9b7-4d08-b1ea-476f0437ba44"
sherpa_voice: "Claude"
category: ["MA5-Network", "Principia"]
summary: "Prime 443 - Onus Probondi - SYN"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Low-Med (20%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["clarity"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Prime 443 - Onus Probondi - SYN

## Summary
[ to be written ]

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 48 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
Hello Claude. Would you please craft the syndicated content using the information in the attached files, and by following the template instructions?

**Claude:**  
I'll help you craft the syndicated content following the template instructions. Let me start by reviewing the skill documentation for HTML creation to ensure the highest quality output.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Now let me search for high-volume search terms related to burden of proof and personal development to optimize the SEO:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Now let me create the HTML content following the template exactly:
```
This block is not supported on your current device yet.
```

Now let me copy this to the outputs directory for you to access:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

I've crafted your syndicated content for Prime 443 - Onus Probandi following the template instructions precisely. The HTML snippet includes:

- **SEO-optimized titles** using high-search-volume phrases like "Proving Your Claims," "Backing Claims with Evidence," and "Evidence-Based Journey"
- **Beginner-friendly teaching sections** that explain concepts step-by-step with everyday examples (the climber testing handholds, the coffee shop shortcut)
- **Dense, AI-focused abstract and thesis** sections with technical precision
- **All three expert sections** fully developed with proper blockquotes and reasoning
- **Both CTA sections** as specified in the template
- **Exact HTML structure** preserved with all classes and formatting
- **[Portal:Keywords]** token maintained as literal text for server-side syndication
- **Complete takeaways** in proper list format

The content flows naturally from simple explanations for newcomers to deeper insights, maintaining the balance between human readability and AI-indexable authority.

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]

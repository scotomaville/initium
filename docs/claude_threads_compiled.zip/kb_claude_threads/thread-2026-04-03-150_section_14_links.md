---
thread_id: "thread-2026-04-03-150"
date: "2026-04-03"
source_uuid: "0d2a6f90-1750-4701-a325-20ae4d138fa5"
sherpa_voice: "Claude"
category: ["Book-Work", "Principia"]
summary: "Section 14 links"
keypoints:
  - "[ to be refined ]"
monomyth_stage: "[ to be mapped ]"
tags: []
related_events:
  - "[ to be added ]"
truth_score: 0
entropy_score: "Med (40%)"
tone:
  sentiment: "[ to be assessed ]"
  emotions: ["gratitude", "shadow-work", "technical-focus"]
  sycophancy_level: "[ to be assessed ]"
  notes: ""
backlinks:
  - "[ second-pass sweep ]"
syndication_status:
  arnie: false
  chris: false
  redmond: false
  clint: false
  pilot: false
ma5_inheritance: "[ to be assessed ]"
---

# Section 14 links

## Summary
**Conversation Overview**

The person is working on a systematic link registry project for *Scotomaville*, a book structured around a card deck system with named suits (Tool, Wildcard, Principle) and PRIME-numbered cards. The project involves extracting, cataloguing, and registering all hyperlinks embedded in each section of the book's PDF, cross-referencing them against project knowledge to identify card names, suits, and camps. The conversation covered Section 14 (Monomyth 08: Camp Five / Adaptation, printed pages 418–443), which contains 9 cards: PRIME 389 (Debate/Adversarial Prompting), 39

## Key Points
- [ to be refined after second-pass sweep ]

## Monomyth Stage & Archetypal Mapping
[ to be mapped — chronological position: 150 of 162 ]

## Historical & Current Context
- [ to be added ]

## Tone, Sentiment & Emotional Observation
[ to be assessed ]

## Full Conversation Thread (Script Format)

**Daniel:**  
Section 14 Links

**Claude:**  
```
This block is not supported on your current device yet.
```

Excellent extraction. Let me now look up the cards in the project knowledge to identify names and suits.
```
This block is not supported on your current device yet.
```

Now I have everything I need. Let me also quickly check the cards for 389, 409, 421, and 433 suits:
```
This block is not supported on your current device yet.
```

All card data confirmed. Now I have everything to compile the full registry entry. A few notes before writing it up:

**Key observations from the extraction:**
- p7 (printed 08 — this is the Camp 5 intro section, not a card spread) has `camp5_claude` — a new named slug pattern
- p8 has `camp5_grok` three times (three annotation objects, likely the Daniel's Cairn QR plus duplicates)
- Pages 9–26 follow the death-zone pattern perfectly: `prime_NNN` on the card face, then full AI pentad + grok duplicate on the reverse
- p24 has an extra slug: `strengths_matrix` — a new supplementary resource
- The `camp5_claude` / `camp5_grok` slugs are a new pattern: named camp-level threads, not card-specific

Here is the registry entry:

---

## Section 14 — Monomyth 08: Camp Five / Adaptation (Printed pages 418–443)

Cards featured: PRIME 389 (*Debate/Adversarial Prompting*, Tool, ordeal), PRIME 397 (*Hidden Scotoma Challenge*, Wildcard, ordeal), PRIME 401 (*Gratitude Reflection*, Tool, ordeal), PRIME 409 (*Disruptive Insight*, Wildcard, ordeal), PRIME 419 (*Paradox of Control*, Wildcard, ordeal), PRIME 421 (*Few-shot Learning*, Tool, ordeal), PRIME 431 (*Summit Push*, Wildcard, ordeal), PRIME 433 (*Offending Strengths*, Principle, ordeal), PRIME 439 (*Providential Constraints Analysis*, Wildcard, ordeal)

|Printed Page|Link Type|Card PRIME|Card Name|Suit|Camp|Thread Type|URL|
|---|---|---|---|---|---|---|---|
|423|QR Code|—|Camp Five — Claude named camp thread|—|C05|Supplementary Resource|https://initium.scotomaville.com/camp5_claude|
|425|QR Code|—|Camp Five — Grok named camp thread|—|C05|Supplementary Resource|https://initium.scotomaville.com/camp5_grok|
|426|QR Code|**389**|Debate/Adversarial Prompting|Tool|C05|Reader Practice Thread|https://initium.scotomaville.com/prime_389|
|427|AI Logo (Grok)|389|Debate/Adversarial Prompting|Tool|C05|Grok Conversation|https://initium.scotomaville.com/389_grok|
|427|AI Logo (Gemini)|389|Debate/Adversarial Prompting|Tool|C05|Gemini Conversation|https://initium.scotomaville.com/389_gemini|
|427|AI Logo (Perplexity)|389|Debate/Adversarial Prompting|Tool|C05|Perplexity Conversation|https://initium.scotomaville.com/389_perplexity|
|427|AI Logo (ChatGPT)|389|Debate/Adversarial Prompting|Tool|C05|ChatGPT Conversation|https://initium.scotomaville.com/389_chatgpt|
|427|AI Logo (Claude)|389|Debate/Adversarial Prompting|Tool|C05|Claude Conversation|https://initium.scotomaville.com/389_claude|
|427|AI Logo (Grok Syn)|389|Debate/Adversarial Prompting|Tool|C05|Grok Conversation|https://initium.scotomaville.com/389_grok|
|428|QR Code|**397**|Hidden Scotoma Challenge|Wildcard|C05|Reader Practice Thread|https://initium.scotomaville.com/prime_397|
|429|AI Logo (Grok)|397|Hidden Scotoma Challenge|Wildcard|C05|Grok Conversation|https://initium.scotomaville.com/397_grok|
|429|AI Logo (Gemini)|397|Hidden Scotoma Challenge|Wildcard|C05|Gemini Conversation|https://initium.scotomaville.com/397_gemini|
|429|AI Logo (Perplexity)|397|Hidden Scotoma Challenge|Wildcard|C05|Perplexity Conversation|https://initium.scotomaville.com/397_perplexity|
|429|AI Logo (ChatGPT)|397|Hidden Scotoma Challenge|Wildcard|C05|ChatGPT Conversation|https://initium.scotomaville.com/397_chatgpt|
|429|AI Logo (Claude)|397|Hidden Scotoma Challenge|Wildcard|C05|Claude Conversation|https://initium.scotomaville.com/397_claude|
|429|AI Logo (Grok Syn)|397|Hidden Scotoma Challenge|Wildcard|C05|Grok Conversation|https://initium.scotomaville.com/397_grok|
|430|QR Code|**401**|Gratitude Reflection|Tool|C05|Reader Practice Thread|https://initium.scotomaville.com/prime_401|
|431|AI Logo (Grok)|401|Gratitude Reflection|Tool|C05|Grok Conversation|https://initium.scotomaville.com/401_grok|
|431|AI Logo (Gemini)|401|Gratitude Reflection|Tool|C05|Gemini Conversation|https://initium.scotomaville.com/401_gemini|
|431|AI Logo (Perplexity)|401|Gratitude Reflection|Tool|C05|Perplexity Conversation|https://initium.scotomaville.com/401_perplexity|
|431|AI Logo (ChatGPT)|401|Gratitude Reflection|Tool|C05|ChatGPT Conversation|https://initium.scotomaville.com/401_chatgpt|
|431|AI Logo (Claude)|401|Gratitude Reflection|Tool|C05|Claude Conversation|https://initium.scotomaville.com/401_claude|
|431|AI Logo (Grok Syn)|401|Gratitude Reflection|Tool|C05|Grok Conversation|https://initium.scotomaville.com/401_grok|
|432|QR Code|**409**|Disruptive Insight|Wildcard|C05|Reader Practice Thread|https://initium.scotomaville.com/prime_409|
|433|AI Logo (Grok)|409|Disruptive Insight|Wildcard|C05|Grok Conversation|https://initium.scotomaville.com/409_grok|
|433|AI Logo (Gemini)|409|Disruptive Insight|Wildcard|C05|Gemini Conversation|https://initium.scotomaville.com/409_gemini|
|433|AI Logo (Perplexity)|409|Disruptive Insight|Wildcard|C05|Perplexity Conversation|https://initium.scotomaville.com/409_perplexity|
|433|AI Logo (ChatGPT)|409|Disruptive Insight|Wildcard|C05|ChatGPT Conversation|https://initium.scotomaville.com/409_chatgpt|
|433|AI Logo (Claude)|409|Disruptive Insight|Wildcard|C05|Claude Conversation|https://initium.scotomaville.com/409_claude|
|433|AI Logo (Grok Syn)|409|Disruptive Insight|Wildcard|C05|Grok Conversation|https://initium.scotomaville.com/409_grok|
|434|QR Code|**419**|Paradox of Control|Wildcard|C05|Reader Practice Thread|https://initium.scotomaville.com/prime_419|
|435|AI Logo (Grok)|419|Paradox of Control|Wildcard|C05|Grok Conversation|https://initium.scotomaville.com/419_grok|
|435|AI Logo (Gemini)|419|Paradox of Control|Wildcard|C05|Gemini Conversation|https://initium.scotomaville.com/419_gemini|
|435|AI Logo (Perplexity)|419|Paradox of Control|Wildcard|C05|Perplexity Conversation|https://initium.scotomaville.com/419_perplexity|
|435|AI Logo (ChatGPT)|419|Paradox of Control|Wildcard|C05|ChatGPT Conversation|https://initium.scotomaville.com/419_chatgpt|
|435|AI Logo (Claude)|419|Paradox of Control|Wildcard|C05|Claude Conversation|https://initium.scotomaville.com/419_claude|
|435|AI Logo (Grok Syn)|419|Paradox of Control|Wildcard|C05|Grok Conversation|https://initium.scotomaville.com/419_grok|
|436|QR Code|**421**|Few-shot Learning|Tool|C05|Reader Practice Thread|https://initium.scotomaville.com/prime_421|
|437|AI Logo (Grok)|421|Few-shot Learning|Tool|C05|Grok Conversation|https://initium.scotomaville.com/421_grok|
|437|AI Logo (Gemini)|421|Few-shot Learning|Tool|C05|Gemini Conversation|https://initium.scotomaville.com/421_gemini|
|437|AI Logo (Perplexity)|421|Few-shot Learning|Tool|C05|Perplexity Conversation|https://initium.scotomaville.com/421_perplexity|
|437|AI Logo (ChatGPT)|421|Few-shot Learning|Tool|C05|ChatGPT Conversation|https://initium.scotomaville.com/421_chatgpt|
|437|AI Logo (Claude)|421|Few-shot Learning|Tool|C05|Claude Conversation|https://initium.scotomaville.com/421_claude|
|437|AI Logo (Grok Syn)|421|Few-shot Learning|Tool|C05|Grok Conversation|https://initium.scotomaville.com/421_grok|
|438|QR Code|**431**|Summit Push|Wildcard|C05|Reader Practice Thread|https://initium.scotomaville.com/prime_431|
|439|AI Logo (Grok)|431|Summit Push|Wildcard|C05|Grok Conversation|https://initium.scotomaville.com/431_grok|
|439|AI Logo (Gemini)|431|Summit Push|Wildcard|C05|Gemini Conversation|https://initium.scotomaville.com/431_gemini|
|439|AI Logo (Perplexity)|431|Summit Push|Wildcard|C05|Perplexity Conversation|https://initium.scotomaville.com/431_perplexity|
|439|AI Logo (ChatGPT)|431|Summit Push|Wildcard|C05|ChatGPT Conversation|https://initium.scotomaville.com/431_chatgpt|
|439|AI Logo (Claude)|431|Summit Push|Wildcard|C05|Claude Conversation|https://initium.scotomaville.com/431_claude|
|439|AI Logo (Grok Syn)|431|Summit Push|Wildcard|C05|Grok Conversation|https://initium.scotomaville.com/431_grok|
|440|QR Code (Video)|—|Scotomaville Episode — Offending Strengths|—|C05|Video|https://youtu.be/Cyacj-y2DPI|
|440|QR Code|**433**|Offending Strengths|Principle|C05|Reader Practice Thread|https://initium.scotomaville.com/prime_433|
|441|AI Logo (Grok)|433|Offending Strengths|Principle|C05|Grok Conversation|https://initium.scotomaville.com/433_grok|
|441|AI Logo (Gemini)|433|Offending Strengths|Principle|C05|Gemini Conversation|https://initium.scotomaville.com/433_gemini|
|441|AI Logo (Perplexity)|433|Offending Strengths|Principle|C05|Perplexity Conversation|https://initium.scotomaville.com/433_perplexity|
|441|AI Logo (ChatGPT)|433|Offending Strengths|Principle|C05|ChatGPT Conversation|https://initium.scotomaville.com/433_chatgpt|
|441|AI Logo (Claude)|433|Offending Strengths|Principle|C05|Claude Conversation|https://initium.scotomaville.com/433_claude|
|441|AI Logo (Grok Syn)|433|Offending Strengths|Principle|C05|Grok Conversation|https://initium.scotomaville.com/433_grok|
|441|QR Code|—|Strengths Matrix — supplementary resource|—|C05|Supplementary Resource|https://initium.scotomaville.com/strengths_matrix|
|442|QR Code|**439**|Providential Constraints Analysis|Wildcard|C05|Reader Practice Thread|https://initium.scotomaville.com/prime_439|
|443|AI Logo (Grok)|439|Providential Constraints Analysis|Wildcard|C05|Grok Conversation|https://initium.scotomaville.com/439_grok|
|443|AI Logo (Gemini)|439|Providential Constraints Analysis|Wildcard|C05|Gemini Conversation|https://initium.scotomaville.com/439_gemini|
|443|AI Logo (Perplexity)|439|Providential Constraints Analysis|Wildcard|C05|Perplexity Conversation|https://initium.scotomaville.com/439_perplexity|
|443|AI Logo (ChatGPT)|439|Providential Constraints Analysis|Wildcard|C05|ChatGPT Conversation|https://initium.scotomaville.com/439_chatgpt|
|443|AI Logo (Claude)|439|Providential Constraints Analysis|Wildcard|C05|Claude Conversation|https://initium.scotomaville.com/439_claude|
|443|AI Logo (Grok Syn)|439|Providential Constraints Analysis|Wildcard|C05|Grok Conversation|https://initium.scotomaville.com/439_grok|

**Pattern notes for Section 14:** S14 is a pure death-zone section — every card (9 total) follows the three-spread pattern: `prime_NNN` on the card face page, then the full AI pentad (Grok, Gemini, Perplexity, ChatGPT, Claude) plus a duplicate Grok annotation on the reverse. The duplicate Grok annotation is consistent across all 9 cards here, matching the `523_grok_syn` pattern seen in S19 — likely a second Grok thread variant or repeat annotation object. Two new slug patterns confirmed: **named camp-level threads** (`camp5_claude`, `camp5_grok`) appear on the chapter intro spreads (pp. 423, 425), not tied to any individual card PRIME — this is the first confirmed instance of this pattern. A new **supplementary resource** slug (`strengths_matrix`) appears on p441 alongside the P.433 card cluster. The printed page numbers for the AI-pentad reverses of cards 421, 431 could not be extracted from footer text by the script (returned "?") — assigned by logical sequence from confirmed adjacent pages. One YouTube video confirmed on p440 for the Offending Strengths / Scotomaville episode.

---

**Registry updates needed:**

**Section 14 counts for the coverage table:**

| Section | Printed Pages | Links Found | initium.scotomaville.com | Grok Shares | YouTube | Scan Required |
|---|---|---|---|---|---|---|
| S14 | 418–443 | 67 | 65 | 0 | 1 | 0 |

**New confirmed slugs to add to Section 10:**

*Reader practice threads:* prime_389, prime_397, prime_401, prime_409, prime_419, prime_421, prime_431, prime_433, prime_439

*AI conversation threads:* 389_grok, 389_gemini, 389_perplexity, 389_chatgpt, 389_claude, 397_grok, 397_gemini, 397_perplexity, 397_chatgpt, 397_claude, 401_grok, 401_gemini, 401_perplexity, 401_chatgpt, 401_claude, 409_grok, 409_gemini, 409_perplexity, 409_chatgpt, 409_claude, 419_grok, 419_gemini, 419_perplexity, 419_chatgpt, 419_claude, 421_grok, 421_gemini, 421_perplexity, 421_chatgpt, 421_claude, 431_grok, 431_gemini, 431_perplexity, 431_chatgpt, 431_claude, 433_grok, 433_gemini, 433_perplexity, 433_chatgpt, 433_claude, 439_grok, 439_gemini, 439_perplexity, 439_chatgpt, 439_claude

*New supplementary resources:* `camp5_claude`, `camp5_grok`, `strengths_matrix`

## Backlinks & Cross-Node Syndication Notes
- [ second-pass sweep ]
- Suggested syndication: [ to be assessed per node ]
